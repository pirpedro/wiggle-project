﻿/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
using System;
using System.Collections.Generic;
using System.IO;

using Db4objects.Db4o;
using Db4objects.Db4o.Config;

namespace Db4odoc.ClientServer
{
	public class DeepExample
    {
		private const string Db4oFileName = "reference.db4o";

        public static void Main(string[] args)
        {
            File.Delete(Db4oFileName);
            IObjectContainer db = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), Db4oFileName);
            try
            {
                StoreCar(db);
                db.Close();
                IEmbeddedConfiguration configuration = ConfigureCascadeOnUpdate();
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
                TakeManySnapshots(db);
                db.Close();
                configuration = ConfigureCascadeOnUpdate();
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
                RetrieveAllSnapshots(db);
                db.Close();
                configuration = ConfigureCascadeOnUpdate();
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
                RetrieveSnapshotsSequentially(db);
                RetrieveSnapshotsSequentiallyImproved(db);
                db.Close();
                configuration = ConfigureActivationDepth();
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
                RetrieveSnapshotsSequentially(db);
            }
            finally
            {
                db.Close();
            }
        }
		// end Main
        
        private static void StoreCar(IObjectContainer db)
        {
            Pilot pilot = new Pilot("Rubens Barrichello", 99);
            Car car = new Car("BMW");
            car.Pilot = pilot;
            db.Store(car);
        }
		// end StoreCar

        private static IEmbeddedConfiguration ConfigureCascadeOnUpdate()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.ObjectClass(typeof(Car)).CascadeOnUpdate(true);
            return configuration;
        }
		// end ConfigureCascadeOnUpdate

        private static void TakeManySnapshots(IObjectContainer db)
        {
            IList<Car> result = db.Query<Car>();
            Car car = result[0];
            for (int i=0; i<5; i++)
            {
                car.Snapshot();
            }
            db.Store(car);
        }
		// end TakeManySnapshots

        private static void RetrieveAllSnapshots(IObjectContainer db)
        {
            IList<SensorReadout> result = db.Query<SensorReadout>();
            foreach (var sr in result)
            {
                Console.WriteLine(sr);
            }
        }
		// end RetrieveAllSnapshots

        private static void RetrieveSnapshotsSequentially(IObjectContainer db)
        {
            IList<Car> result = db.Query<Car>();
            Car car = result[0];
            SensorReadout readout = car.GetHistory();
            while (readout != null)
            {
                Console.WriteLine(readout);
                readout = readout.Next;
            }
        }
		// end RetrieveSnapshotsSequentially

        private static void RetrieveSnapshotsSequentiallyImproved(IObjectContainer db)
        {
            IList<Car> result = db.Query<Car>();
            Car car = result[0];
            SensorReadout readout = car.GetHistory();
            while (readout != null)
            {
                db.Activate(readout, 1);
                Console.WriteLine(readout);
                readout = readout.Next;
            }
        }
		// end RetrieveSnapshotsSequentiallyImproved

        private static IEmbeddedConfiguration ConfigureActivationDepth()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.ObjectClass(typeof(TemperatureSensorReadout))
                .CascadeOnActivate(true);
            configuration.Common.ObjectClass(typeof(PressureSensorReadout))
                .CascadeOnActivate(true);

            return configuration;
        }
        // end ConfigureActivationDepth        
    }
}
