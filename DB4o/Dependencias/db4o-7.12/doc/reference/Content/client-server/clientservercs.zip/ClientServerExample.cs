﻿/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
using System.Collections;
using System.Collections.Generic;
using System.IO;

using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.CS;
using Db4objects.Db4o.CS.Config;

namespace Db4odoc.ClientServer
{
	public class ClientServerExample
	{
		private const string Db4oFileName = "reference.db4o";

		public readonly static int ServerPort = 0xdb40;
		
		public readonly static string ServerUser = "user";
		
		public readonly static string ServerPassword = "password";

		public static void Main(string[] args)
		{
			File.Delete(Db4oFileName);
			AccessLocalServer();
			File.Delete(Db4oFileName);
            IObjectContainer db = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), Db4oFileName);
			try
			{
				SetFirstCar(db);
				SetSecondCar(db);
			}
			finally
			{
				db.Close();
			}
            
			IObjectServer server = Db4oClientServer.OpenServer(ConfigureDb4o(), Db4oFileName, 0);
			try
			{
				QueryLocalServer(server);
				DemonstrateLocalReadCommitted(server);
				DemonstrateLocalRollback(server);
			}
			finally
			{
				server.Close();
			}
            
			AccessRemoteServer();
            server = Db4oClientServer.OpenServer(ConfigureDb4o(), Db4oFileName, ServerPort);
			server.GrantAccess(ServerUser, ServerPassword);
			try
			{
				QueryRemoteServer(ServerPort, ServerUser, ServerPassword);
				DemonstrateRemoteReadCommitted(ServerPort, ServerUser, ServerPassword);
				DemonstrateRemoteRollback(ServerPort, ServerUser, ServerPassword);
			}
			finally
			{
				server.Close();
			}
		}
		// end Main
            
		private static void SetFirstCar(IObjectContainer db)
		{
			Pilot pilot = new Pilot("Rubens Barrichello", 99);
			Car car = new Car("BMW");
			car.Pilot = pilot;
			db.Store(car);
		}
		// end SetFirstCar
    
		private static void SetSecondCar(IObjectContainer db)
		{
			Pilot pilot = new Pilot("Michael Schumacher", 100);
			Car car = new Car("Ferrari");
			car.Pilot = pilot;
			db.Store(car);
		}
		// end SetSecondCar

        private static void AccessLocalServer()
		{
            IObjectServer server = Db4oClientServer.OpenServer(Db4oClientServer.NewServerConfiguration(), Db4oFileName, 0);
			try
			{
				IObjectContainer client = server.OpenClient();
				// Do something with this client, or open more clients
				client.Close();
			}
			finally
			{
				server.Close();
			}
		}
		// end AccessLocalServer

        private static void QueryLocalServer(IObjectServer server)
		{
			IObjectContainer client = server.OpenClient();
			ListResult(client.Query<Car>());
			client.Close();
		}
		// end QueryLocalServer

        private static IServerConfiguration ConfigureDb4o()
		{
            IServerConfiguration configuration = Db4oClientServer.NewServerConfiguration();
            configuration.Common.ObjectClass(typeof(Car)).UpdateDepth(3);
            return configuration;
		}
		// end ConfigureDb4o

        private static void DemonstrateLocalReadCommitted(IObjectServer server)
		{
			IObjectContainer client1 =server.OpenClient();
			IObjectContainer client2 =server.OpenClient();
			Pilot pilot = new Pilot("David Coulthard", 98);
			IList result = client1.QueryByExample(new Car("BMW"));
			Car car = (Car)result[0];
			car.Pilot = pilot;
			client1.Store(car);
			ListResult(client1.Query<Car>());
            ListResult(client2.Query<Car>());
			client1.Commit();
            ListResult(client1.Query<Car>());
			ListRefreshedResult(client2, client2.Query<Car>(), 2);
			client1.Close();
			client2.Close();
		}
		// end DemonstrateLocalReadCommitted

        private static void DemonstrateLocalRollback(IObjectServer server)
		{
			IObjectContainer client1 = server.OpenClient();
			IObjectContainer client2 = server.OpenClient();
			IList result = client1.QueryByExample(new Car("BMW"));
			Car car = (Car)result[0];
			car.Pilot = new Pilot("Someone else", 0);
			client1.Store(car);
			ListResult(client1.Query<Car>());
            ListResult(client2.Query<Car>());
			client1.Rollback();
			client1.Ext().Refresh(car, 2);
            ListResult(client1.Query<Car>());
            ListResult(client2.Query<Car>());
			client1.Close();
			client2.Close();
		}
		// end DemonstrateLocalRollback

        private static void AccessRemoteServer()
		{
            IObjectServer server = Db4oClientServer.OpenServer(Db4oClientServer.NewServerConfiguration(), Db4oFileName, ServerPort);
			server.GrantAccess(ServerUser, ServerPassword);
			try
			{
                IObjectContainer client = Db4oClientServer.OpenClient(Db4oClientServer.NewClientConfiguration(), "localhost", ServerPort, ServerUser, ServerPassword);
				// Do something with this client, or open more clients
				client.Close();
			}
			finally
			{
				server.Close();
			}
		}
		// end AccessRemoteServer

        private static void QueryRemoteServer(int port, string user, string password)
		{
            IObjectContainer client = Db4oClientServer.OpenClient(Db4oClientServer.NewClientConfiguration(), "localhost", port, user, password);
            ListResult(client.Query<Car>());
			client.Close();
		}
		// end QueryRemoteServer

        private static void DemonstrateRemoteReadCommitted(int port, string user, string password)
		{
            IObjectContainer client1 = Db4oClientServer.OpenClient(Db4oClientServer.NewClientConfiguration(), "localhost", port, user, password);
            IObjectContainer client2 = Db4oClientServer.OpenClient(Db4oClientServer.NewClientConfiguration(), "localhost", port, user, password);
			Pilot pilot = new Pilot("Jenson Button", 97);
            IList<Car> result = client1.Query<Car>();
            Car car = result[0];
			car.Pilot = pilot;
			client1.Store(car);
			ListResult(client1.Query<Car>());
            ListResult(client2.Query<Car>());
			client1.Commit();
            ListResult(client1.Query<Car>());
            ListResult(client2.Query<Car>());
			client1.Close();
			client2.Close();
		}
		// end DemonstrateRemoteReadCommitted

        private static void DemonstrateRemoteRollback(int port, string user, string password)
		{
            IObjectContainer client1 = Db4oClientServer.OpenClient(Db4oClientServer.NewClientConfiguration(), "localhost", port, user, password);
            IObjectContainer client2 = Db4oClientServer.OpenClient(Db4oClientServer.NewClientConfiguration(), "localhost", port, user, password);
			IList<Car> result = client1.Query<Car>();
			Car car = result[0];
			car.Pilot = new Pilot("Someone else", 0);
			client1.Store(car);
			ListResult(client1.Query<Car>());
            ListResult(client2.Query<Car>());
			client1.Rollback();
			client1.Ext().Refresh(car,2);
            ListResult(client1.Query<Car>());
            ListResult(client2.Query<Car>());
			client1.Close();
			client2.Close();
		}
		// end DemonstrateRemoteRollback

    
        private static void ListResult<T>(IList<T> result)
        {
            System.Console.WriteLine(result.Count);
            foreach (T item in result)
            {
                System.Console.WriteLine(item);
            }
        }
        // end ListResult

        private static void ListRefreshedResult(IObjectContainer container, IList<Car> items, int depth)
		{
			System.Console.WriteLine(items.Count);
			foreach (Car item in items)
			{	
				container.Ext().Refresh(item, depth);
				System.Console.WriteLine(item);
			}
		}
		// end ListRefreshedResult		
	}
}
