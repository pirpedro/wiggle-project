/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */
using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;

using Db4objects.Db4o;
using Db4objects.Db4o.Linq;
using Db4objects.Db4o.Ext;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Query;

namespace Db4objects.Db4odoc.CrossPlatform.Client
{
    class Client
    {
        private const int COUNT = 10;

        private static IObjectContainer _container = null;


        public static void Main(string[] args)
        {
            LinqGroupByQuery();
        }
        // end Main

        private static IObjectContainer Database()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            configuration.AddAlias(new WildcardAlias("com.db4odoc.aliases.*", "Db4objects.Db4odoc.CrossPlatform.Client.*, TestLinqNoClasses"));
            configuration.AddAlias(new TypeAlias("com.db4o.ext.Db4oDatabase", "Db4objects.Db4o.Ext.Db4oDatabase, Db4objects.Db4o"));
            if (_container == null)
            {
                try
                {
                    _container = Db4oFactory.OpenClient(configuration, "localhost", 0xdb40, "db4o", "db4o");
                }
                catch (DatabaseFileLockedException ex)
                {
                    System.Console.WriteLine(ex.Message);
                }
            }
            return _container;
        }

        // end Database

        private static void CloseDatabase()
        {
            if (_container != null)
            {
                _container.Close();
                _container = null;
            }
        }

        // end CloseDatabase

        private static void SavePilots()
        {
            Console.WriteLine("Saving Pilot objects without Pilot class on the server");
            IObjectContainer oc = Database();
            if (oc != null) {
                try
                {
                    for (int i = 0; i < COUNT; i++)
                    {
                        oc.Set(new Pilot("Pilot #" + i, i));
                    }
                    oc.Commit();
                }
                finally
                {
                    CloseDatabase();
                }
            }
        }
        // end SavePilots

        private static void LinqGroupByQuery()
        {
            IObjectContainer container = Database();
            if (container != null)
            {
                try
                {

                    var result = (from Pilot p in container
                                  orderby p.Points descending
                                  select p).GroupBy(value => value.Points, value => new { value.Name, value.Points });
                    foreach (var group in result)
                    {
                        Console.WriteLine("Pilots with {0} points:", group.Key);

                        foreach (var tuple in group)
                            Console.WriteLine("  {0}", tuple);
                    }

                }
                finally
                {
                    CloseDatabase();
                }
            }
        }
        // end LinqGroupByQuery

        
        private static void ListResult<T>(IEnumerable<T> result)
        {
            System.Console.WriteLine(result.Count<T>());
            foreach (T t in result)
            {
                System.Console.WriteLine(t);
            }
        }

        // end ListResult

    }

}


