﻿' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 

Imports System
Imports System.Text
Imports System.IO
Imports System.Collections.Generic
Imports System.Collections
Imports System.Linq

Imports Db4objects.Db4o
Imports Db4objects.Db4o.Linq
Imports Db4objects.Db4o.Ext
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Query

Namespace Db4objects.Db4odoc.CrossPlatform.Client
    Class Client

        Private Const COUNT As Integer = 10

        Private Shared _container As IObjectContainer = Nothing


        Public Shared Sub Main(ByVal args As String())
            LinqGroupByQuery()
        End Sub
        ' end Main

        Private Shared Function Database() As IObjectContainer
            Dim configuration As IConfiguration = Db4oFactory.NewConfiguration()
            configuration.AddAlias(New WildcardAlias("com.db4odoc.aliases.*", "Db4objects.Db4odoc.CrossPlatform.Client.*, TestLinqNoClasses"))
            configuration.AddAlias(New TypeAlias("com.db4o.ext.Db4oDatabase", "Db4objects.Db4o.Ext.Db4oDatabase, Db4objects.Db4o"))
            If _container Is Nothing Then
                Try
                    _container = Db4oFactory.OpenClient(configuration, "localhost", 56128, "db4o", "db4o")
                Catch ex As DatabaseFileLockedException
                    System.Console.WriteLine(ex.Message)
                End Try
            End If
            Return _container
        End Function

        ' end Database

        Private Shared Sub CloseDatabase()
            If _container IsNot Nothing Then
                _container.Close()
                _container = Nothing
            End If
        End Sub

        ' end CloseDatabase

        Private Shared Sub SavePilots()
            Console.WriteLine("Saving Pilot objects without Pilot class on the server")
            Dim oc As IObjectContainer = Database()
            If oc IsNot Nothing Then
                Try
                    For i As Integer = 0 To COUNT - 1
                        oc.Store(New Pilot("Pilot #" + i, i))
                    Next
                    oc.Commit()
                Finally
                    CloseDatabase()
                End Try
            End If
        End Sub
        ' end SavePilots

        Private Shared Sub LinqGroupByQuery()
            Dim container As IObjectContainer = Database()
            If container IsNot Nothing Then
                Try
                    Dim result = From p As Pilot In container _
                                  Order By p.Points Descending _
                                  Select p Group By p.Points, p.Name Into Group Select Name, Points
                    For Each value In result
                        Console.WriteLine("  {0}", value)
                    Next
                Catch ex As Exception
                    System.Console.WriteLine("System Exception: " + ex.Message)
                Finally
                    CloseDatabase()
                End Try
            End If
        End Sub
        ' End LinqGroupByQuery

    End Class
End Namespace
