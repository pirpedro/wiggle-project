/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */
namespace Db4objects.Db4odoc.CrossPlatform.Client
{
    public class Pilot
    {
        private string name;
        private int points;

        public Pilot(string name, int points)
        {
            this.name = name;
            this.points = points;
        }

        public int Points
        {
            get
            {
                return points;
            }
            set
            {
                points = value;
            }
        }

        public void AddPoints(int points)
        {
            this.points += points;
        }

        public string Name
        {
            get
            {
                return name;
            }
        }

        public override string ToString()
        {
            return string.Format("{0}/{1}", name, points);
        }
    }
}