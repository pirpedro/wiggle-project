﻿' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 

Namespace Db4objects.Db4odoc.CrossPlatform.Client
    Public Class Pilot
        Private m_name As String
        Private m_points As Integer

        Public Sub New(ByVal name As String, ByVal points As Integer)
            Me.m_name = name
            Me.m_points = points
        End Sub

        Public Property Points() As Integer
            Get
                Return m_points
            End Get
            Set(ByVal value As Integer)
                m_points = value
            End Set
        End Property

        Public Sub AddPoints(ByVal points As Integer)
            Me.m_points += points
        End Sub

        Public ReadOnly Property Name() As String
            Get
                Return m_name
            End Get
        End Property

        Public Overloads Overrides Function ToString() As String
            Return String.Format("{0}/{1}", m_name, m_points)
        End Function
    End Class
End Namespace
