/* Copyright (C) 2007 Versant Inc. http://www.db4o.com */

package com.db4odoc.batch;

import java.io.IOException;

import com.db4o.ObjectContainer;
import com.db4o.cs.Db4oClientServer;
import com.db4o.cs.config.ClientConfiguration;

public class BatchExample {

	private static final String FILE = "reference.db4o";

	private static final int PORT = 0xdb40;

	private static final String USER = "db4o";

	private static final String PASS = "db4o";

	private static final String HOST = "localhost";

	private static final int NO_OF_OBJECTS = 100000;

	public static void main(String[] args) throws IOException {
		fillUpDb();
	}

	// end main

	private static void fillUpDb()
			throws IOException {
		System.out.println("Testing inserts");
		ClientConfiguration configuration = Db4oClientServer.newClientConfiguration();
		// Uncomment the following line to test CS mode without batching
		//configuration.networking().batchMessages(false);
		// Uncomment the following line to test maximum batch queue size (batch mode should be enabled)
		//configuration.networking().maxBatchQueueSize(1024);
		ObjectContainer container = Db4oClientServer.openClient(
				configuration, HOST, PORT, USER,
				PASS);
		try {
			long t1 = System.currentTimeMillis();
			for (int i = 0; i < NO_OF_OBJECTS; i++) {
				Pilot pilot = new Pilot("pilot #" + i, i);
				container.store(pilot);
			}
			long t2 = System.currentTimeMillis();
			long diff = t2 - t1;
			System.out.println("Operation time: " + diff + " ms.");
		} finally {
			container.close();
		}
	}
	// end fillUpDb

}
