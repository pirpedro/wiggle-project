/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */

using System;

using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.CS;
using Db4objects.Db4o.CS.Config;

namespace Db4odoc.Batch
{
    class BatchExample
    {
        private const string Db4oFileName = "reference.db4o";
        private const int Port = 0xdb40;
        private const string User = "db4o";
        private const string Password = "db4o";
        private const string Host = "localhost";

        private const int NoOfObjects = 1000000;

        public static void Main(string[] args)
        {
            FillUpDb();
            
        }
        // end Main


        private static void FillUpDb()
        {
            IClientConfiguration configuration = Db4oClientServer.NewClientConfiguration();
            // Uncomment the following line to test CS mode without batching
            // configuration.Networking.BatchMessages = false;
            // Uncomment the following line to test maximum batch queue size (batch mode should be enabled)
            // configuration.Networking.MaxBatchQueueSize = 1024;
            IObjectContainer container = Db4oClientServer.OpenClient(configuration, Host, Port, User,
                        Password);
            try
            {
                Console.WriteLine("Testing inserts");
                DateTime dt1 = DateTime.UtcNow;
                for (int i = 0; i < NoOfObjects; i++)
                {
                    Pilot pilot = new Pilot("pilot #" + i, i);
                    container.Store(pilot);
                }
                DateTime dt2 = DateTime.UtcNow;
                TimeSpan diff = dt2 - dt1;
                Console.WriteLine("Operation time: " + diff.TotalMilliseconds + " ms.");
            }
            finally
            {
                container.Close();
            }
        }
        // end FillUpDb

    }
}
