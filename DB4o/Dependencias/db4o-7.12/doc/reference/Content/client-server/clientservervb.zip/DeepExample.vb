' Copyright (C) 2009 Versant Inc. http://www.db4o.com
Imports System
Imports System.IO
Imports Db4odoc.Db4odoc.ClientServer
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config

Namespace ClientServer
    Public Class DeepExample
        Private Const Db4oFileName As String = "reference.db4o"
        Public Shared Sub Main(ByVal args As String())
            File.Delete(Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(Db4oFileName)
            Try
                StoreCar(db)
                db.Close()
                Dim configuration As IEmbeddedConfiguration
                configuration = SetCascadeOnUpdate()
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
                TakeManySnapshots(db)
                db.Close()
                configuration = SetCascadeOnUpdate()
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
                RetrieveAllSnapshots(db)
                db.Close()
                configuration = SetCascadeOnUpdate()
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
                RetrieveSnapshotsSequentially(db)
                RetrieveSnapshotsSequentiallyImproved(db)
                db.Close()
                configuration = SetActivationDepth()
                db = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
                RetrieveSnapshotsSequentially(db)
            Finally
                db.Close()
            End Try
        End Sub
        ' end Main

        Private Shared Sub StoreCar(ByVal db As IObjectContainer)
            Dim pilot As Pilot = New Pilot("Rubens Barrichello", 99)
            Dim car As Car = New Car("BMW")
            car.Pilot = pilot
            db.Store(car)
        End Sub
        ' end StoreCar

        Private Shared Function SetCascadeOnUpdate() As IEmbeddedConfiguration
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.ObjectClass(GetType(Car)).CascadeOnUpdate(True)
            Return configuration
        End Function
        ' end SetCascadeOnUpdate

        Private Shared Sub TakeManySnapshots(ByVal db As IObjectContainer)
            Dim result As IList(Of Car) = db.Query(Of Car)()
            Dim car As Car = result(0)
            Dim i As Integer = 0
            While i < 5
                car.Snapshot()
                System.Math.Max(System.Threading.Interlocked.Increment(i), i - 1)
            End While
            db.Store(car)
        End Sub
        ' end TakeManySnapshots

        Private Shared Sub RetrieveAllSnapshots(ByVal db As IObjectContainer)
            Dim result As IList(Of SensorReadout) = db.Query(Of SensorReadout)()
            For Each sr As SensorReadout In result
                Console.WriteLine(sr.ToString())
            Next
        End Sub
        ' end RetrieveAllSnapshots

        Private Shared Sub RetrieveSnapshotsSequentially(ByVal db As IObjectContainer)
            Dim result As IList(Of Car) = db.Query(Of Car)()
            Dim car As Car = result(0)
            Dim readout As SensorReadout = car.GetHistory()
            While Not readout Is Nothing
                Console.WriteLine(readout)
                readout = readout.[Next]
            End While
        End Sub
        ' end RetrieveSnapshotsSequentially

        Private Shared Sub RetrieveSnapshotsSequentiallyImproved(ByVal db As IObjectContainer)
            Dim result As IList(Of Car) = db.Query(Of Car)()
            Dim car As Car = result(0)
            Dim readout As SensorReadout = car.GetHistory()
            While Not readout Is Nothing
                db.Activate(readout, 1)
                Console.WriteLine(readout)
                readout = readout.Next
            End While
        End Sub
        ' end RetrieveSnapshotsSequentiallyImproved

        Private Shared Function SetActivationDepth() As IEmbeddedConfiguration
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.ObjectClass(GetType(TemperatureSensorReadout)).CascadeOnActivate(True)
            configuration.Common.ObjectClass(GetType(PressureSensorReadout)).CascadeOnActivate(True)
            Return configuration
        End Function
        ' end SetActivationDepth

    End Class
End Namespace