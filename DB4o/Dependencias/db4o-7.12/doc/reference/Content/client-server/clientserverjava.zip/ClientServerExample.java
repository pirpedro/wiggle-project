/* Copyright (C) 2007 Versant Inc. http://www.db4o.com */
package com.db4odoc.clientserver;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectServer;
import com.db4o.cs.Db4oClientServer;
import com.db4o.cs.config.ServerConfiguration;

public class ClientServerExample {
	private final static int PORT = 0xdb40;
	private final static String USER = "user";
	private final static String PASSWORD = "password";
	private final static String DB4O_FILE_NAME = "reference.db4o";

	public static void main(String[] args) throws IOException {
		new File(DB4O_FILE_NAME).delete();
		accessLocalServer();
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);
		try {
			setFirstCar(container);
			setSecondCar(container);
		} finally {
			container.close();
		}
		ServerConfiguration configuration = configureDb4o();
		ObjectServer server = Db4oClientServer.openServer(configuration,
				DB4O_FILE_NAME, 0);
		try {
			queryLocalServer(server);
			demonstrateLocalReadCommitted(server);
			demonstrateLocalRollback(server);
		} finally {
			server.close();
		}
		accessRemoteServer();
		configuration = configureDb4o();
		server = Db4oClientServer.openServer(configuration, DB4O_FILE_NAME,
				PORT);
		server.grantAccess(USER, PASSWORD);
		try {
			queryRemoteServer(PORT, USER, PASSWORD);
			demonstrateRemoteReadCommitted(PORT, USER, PASSWORD);
			demonstrateRemoteRollback(PORT, USER, PASSWORD);
		} finally {
			server.close();
		}
	}

	// end main

	private static void setFirstCar(ObjectContainer container) {
		Pilot pilot = new Pilot("Rubens Barrichello", 99);
		Car car = new Car("BMW");
		car.setPilot(pilot);
		container.store(car);
	}

	// end setFirstCar

	private static void setSecondCar(ObjectContainer container) {
		Pilot pilot = new Pilot("Michael Schumacher", 100);
		Car car = new Car("Ferrari");
		car.setPilot(pilot);
		container.store(car);
	}

	// end setSecondCar

	private static void accessLocalServer() {
		ObjectServer server = Db4oClientServer.openServer(Db4oClientServer
				.newServerConfiguration(), DB4O_FILE_NAME, 0);
		try {
			ObjectContainer client = server.openClient();
			// Do something with this client, or open more clients
			client.close();
		} finally {
			server.close();
		}
	}

	// end accessLocalServer

	private static void queryLocalServer(ObjectServer server) {
		ObjectContainer client = server.openClient();
		listResult(client.queryByExample(new Car(null)));
		client.close();
	}

	// end queryLocalServer

	private static ServerConfiguration configureDb4o() {
		ServerConfiguration configuration = Db4oClientServer
				.newServerConfiguration();
		configuration.common().objectClass(Car.class).updateDepth(3);
		return configuration;
	}

	// end configureDb4o

	private static void demonstrateLocalReadCommitted(ObjectServer server) {
		ObjectContainer client1 = server.openClient();
		ObjectContainer client2 = server.openClient();
		Pilot pilot = new Pilot("David Coulthard", 98);
		List<Car> result = client1.queryByExample(new Car("BMW"));
		Car car = result.get(0);
		car.setPilot(pilot);
		client1.store(car);
		listResult(client1.queryByExample(new Car(null)));
		listResult(client2.queryByExample(new Car(null)));
		client1.commit();
		listResult(client1.queryByExample(Car.class));
		listRefreshedResult(client2, client2.queryByExample(Car.class), 2);
		client1.close();
		client2.close();
	}

	// end demonstrateLocalReadCommitted

	private static void demonstrateLocalRollback(ObjectServer server) {
		ObjectContainer client1 = server.openClient();
		ObjectContainer client2 = server.openClient();
		List<Car> result = client1.queryByExample(new Car("BMW"));
		Car car = result.get(0);
		car.setPilot(new Pilot("Someone else", 0));
		client1.store(car);
		listResult(client1.queryByExample(new Car(null)));
		listResult(client2.queryByExample(new Car(null)));
		client1.rollback();
		client1.ext().refresh(car, 2);
		listResult(client1.queryByExample(new Car(null)));
		listResult(client2.queryByExample(new Car(null)));
		client1.close();
		client2.close();
	}

	// end demonstrateLocalRollback

	private static void accessRemoteServer() throws IOException {
		ObjectServer server = Db4oClientServer.openServer(Db4oClientServer
				.newServerConfiguration(), DB4O_FILE_NAME, PORT);
		server.grantAccess(USER, PASSWORD);
		try {
			ObjectContainer client = Db4oClientServer.openClient(
					Db4oClientServer.newClientConfiguration(), "localhost",
					PORT, USER, PASSWORD);
			// Do something with this client, or open more clients
			client.close();
		} finally {
			server.close();
		}
	}

	// end accessRemoteServer

	private static void queryRemoteServer(int port, String user, String password)
			throws IOException {
		ObjectContainer client = Db4oClientServer.openClient(Db4oClientServer
				.newClientConfiguration(), "localhost", port, user, password);
		listResult(client.queryByExample(new Car(null)));
		client.close();
	}

	// end queryRemoteServer

	private static void demonstrateRemoteReadCommitted(int port, String user,
			String password) throws IOException {
		ObjectContainer client1 = Db4oClientServer.openClient(Db4oClientServer
				.newClientConfiguration(), "localhost", port, user, password);
		ObjectContainer client2 = Db4oClientServer.openClient(Db4oClientServer
				.newClientConfiguration(), "localhost", port, user, password);
		Pilot pilot = new Pilot("Jenson Button", 97);
		List<Car> result = client1.queryByExample(new Car(null));
		Car car = result.get(0);
		car.setPilot(pilot);
		client1.store(car);
		listResult(client1.queryByExample(new Car(null)));
		listResult(client2.queryByExample(new Car(null)));
		client1.commit();
		listResult(client1.queryByExample(new Car(null)));
		listRefreshedResult(client2, client2.queryByExample(Car.class), 2);
		client1.close();
		client2.close();
	}

	// end demonstrateRemoteReadCommitted

	private static void demonstrateRemoteRollback(int port, String user,
			String password) throws IOException {
		ObjectContainer client1 = Db4oClientServer.openClient(Db4oClientServer
				.newClientConfiguration(), "localhost", port, user, password);
		ObjectContainer client2 = Db4oClientServer.openClient(Db4oClientServer
				.newClientConfiguration(), "localhost", port, user, password);
		List<Car> result = client1.queryByExample(new Car(null));
		Car car = result.get(0);
		car.setPilot(new Pilot("Someone else", 0));
		client1.store(car);
		listResult(client1.queryByExample(new Car(null)));
		listResult(client2.queryByExample(new Car(null)));
		client1.rollback();
		client1.ext().refresh(car, 2);
		listResult(client1.queryByExample(new Car(null)));
		listResult(client2.queryByExample(new Car(null)));
		client1.close();
		client2.close();
	}

	// end demonstrateRemoteRollback

	private static<T> void listRefreshedResult(ObjectContainer container,
			List<T> result, int depth) {
		System.out.println(result.size());
		for (T t : result) {
			container.ext().refresh(t, depth);
			System.out.println(t);
		}
	}

	// end listRefreshedResult

	private static<T> void listResult(List<T> result) {
		System.out.println(result.size());
		for (T t: result){
			System.out.println(t);
		}
	}
	// end listResult
}
