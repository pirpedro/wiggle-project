/* Copyright (C) 2007 Versant Inc. http://www.db4o.com */
package com.db4odoc.clientserver;

import java.io.File;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;

public class TransactionExample {

	private final static String DB4O_FILE_NAME = "reference.db4o";

	public static void main(String[] args) {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);
		try {
			storeCarCommit(container);
			container.close();
			container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
			listAllCars(container);
			storeCarRollback(container);
			container.close();
			container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
			listAllCars(container);
			carSnapshotRollback(container);
			carSnapshotRollbackRefresh(container);
		} finally {
			container.close();
		}
	}

	// end main

	private static void storeCarCommit(ObjectContainer container) {
		Pilot pilot = new Pilot("Rubens Barrichello", 99);
		Car car = new Car("BMW");
		car.setPilot(pilot);
		container.store(car);
		container.commit();
	}

	// end storeCarCommit

	private static void listAllCars(ObjectContainer container) {
		List<Car> result = container.queryByExample(Car.class);
		listResult(result);
	}

	// end listAllCars

	private static void storeCarRollback(ObjectContainer container) {
		Pilot pilot = new Pilot("Michael Schumacher", 100);
		Car car = new Car("Ferrari");
		car.setPilot(pilot);
		container.store(car);
		container.rollback();
	}

	// end storeCarRollback

	private static void carSnapshotRollback(ObjectContainer container) {
		List<Car> result = container.queryByExample(new Car("BMW"));
		Car car = result.get(0);
		car.snapshot();
		container.store(car);
		container.rollback();
		System.out.println(car);
	}

	// end carSnapshotRollback

	private static void carSnapshotRollbackRefresh(ObjectContainer container) {
		List<Car> result = container.queryByExample(new Car("BMW"));
		Car car = result.get(0);
		car.snapshot();
		container.store(car);
		container.rollback();
		container.ext().refresh(car, Integer.MAX_VALUE);
		System.out.println(car);
	}

	// end carSnapshotRollbackRefresh

	private static<T> void listResult(List<T> result) {
		System.out.println(result.size());
		for (T t: result){
			System.out.println(t);
		}
	}
	// end listResult
}
