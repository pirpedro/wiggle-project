/* Copyright (C) 2007 Versant Inc. http://www.db4o.com */
package com.db4odoc.clientserver;

import java.io.File;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.config.EmbeddedConfiguration;

public class DeepExample {
	private final static String DB4O_FILE_NAME = "reference.db4o";

	public static void main(String[] args) {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);
		try {
			storeCar(container);
			container.close();
			EmbeddedConfiguration configuration = setCascadeOnUpdate();
			container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
			takeManySnapshots(container);
			container.close();
			configuration = setCascadeOnUpdate();
			container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
			retrieveAllSnapshots(container);
			container.close();
			configuration = setCascadeOnUpdate();
			container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
			retrieveSnapshotsSequentially(container);
			retrieveSnapshotsSequentiallyImproved(container);
			container.close();
			configuration = setActivationDepth();
			container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
			retrieveSnapshotsSequentially(container);
		} finally {
			container.close();
		}
	}

	// end main

	private static void storeCar(ObjectContainer container) {
		Pilot pilot = new Pilot("Rubens Barrichello", 99);
		Car car = new Car("BMW");
		car.setPilot(pilot);
		container.store(car);
	}

	// end storeCar

	private static EmbeddedConfiguration setCascadeOnUpdate() {
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		configuration.common().objectClass(Car.class).cascadeOnUpdate(true);
		return configuration;
	}

	// end setCascadeOnUpdate

	private static void takeManySnapshots(ObjectContainer container) {
		List<Car> result = container.queryByExample(Car.class);
		Car car = result.get(0);
		for (int i = 0; i < 5; i++) {
			car.snapshot();
		}
		container.store(car);
	}

	// end takeManySnapshots

	private static void retrieveAllSnapshots(ObjectContainer container) {
		List<SensorReadout> result = container.queryByExample(SensorReadout.class);
		for (SensorReadout sr : result){
			System.out.println(sr);
		}
	}

	// end retrieveAllSnapshots

	private static void retrieveSnapshotsSequentially(ObjectContainer container) {
		List<Car> result = container.queryByExample(Car.class);
		Car car = result.get(0);
		SensorReadout readout = car.getHistory();
		while (readout != null) {
			System.out.println(readout);
			readout = readout.getNext();
		}
	}

	// end retrieveSnapshotsSequentially

	private static void retrieveSnapshotsSequentiallyImproved(
			ObjectContainer container) {
		List<Car> result = container.queryByExample(Car.class);
		Car car = result.get(0);
		SensorReadout readout = car.getHistory();
		while (readout != null) {
			container.activate(readout, 1);
			System.out.println(readout);
			readout = readout.getNext();
		}
	}

	// end retrieveSnapshotsSequentiallyImproved

	private static EmbeddedConfiguration setActivationDepth() {
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		configuration.common().objectClass(SensorReadout.class)
				.cascadeOnActivate(true);
		return configuration;
	}
	// end setActivationDepth
}
