' Copyright (C) 2009 Versant Inc. http://www.db4o.com
Imports System
Imports Db4objects.Db4o

Namespace Db4odoc.Concurrency

    Public Class PessimisticThread
        Private _server As IObjectServer
        Private _container As IObjectContainer
        Private _id As String

        Public Sub New(ByVal id As String, ByVal server As IObjectServer)
            _id = id
            Me._server = server
            _container = _server.OpenClient
        End Sub
        ' end New

        Private ReadOnly Property Name() As String
            Get
                Return _id
            End Get
        End Property
        ' end Name

        Public Sub Run()
            Try
                Dim result As IList(Of Pilot) = _container.Query(Of Pilot)()
                For Each pilot As Pilot In result
                    ' with pessimistic approach the object is locked as soon 
                    ' as we get it 
                    If Not _container.Ext.SetSemaphore("LOCK_" + _container.Ext.GetID(pilot).ToString(), 0) Then
                        Console.WriteLine("Error. The object is locked")
                    End If
                    Console.WriteLine(Name + "Updating pilot: " + pilot.ToString())
                    pilot.AddPoints(1)
                    _container.Store(pilot)
                    ' The changes should be committed to be 
                    ' visible to the other clients
                    _container.Commit()
                    _container.Ext.ReleaseSemaphore("LOCK_" + _container.Ext.GetID(pilot).ToString())
                    Console.WriteLine(Name + "Updated pilot: " + pilot.ToString())
                    Console.WriteLine()
                Next
            Finally
                _container.Close()
            End Try
        End Sub
        ' end Run

    End Class
End Namespace