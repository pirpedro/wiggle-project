/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.soda;


public class Car {
	Pilot _pilot;
	String _model;
	
	public Car(String model, Pilot pilot) {
		_model = model;
		_pilot = pilot;
	}
	
	public String toString() {
		return _model + "/" + _pilot.toString();
	}
	
}
