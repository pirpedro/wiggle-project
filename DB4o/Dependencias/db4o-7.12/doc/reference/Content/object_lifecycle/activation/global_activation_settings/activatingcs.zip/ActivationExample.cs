/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System;
using System.IO;
using System.Collections;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Types;

namespace Db4objects.Db4odoc.Activating
{

	public class ActivationExample
	{
		private const string Db4oFileName = "reference.db4o";

		public static void Main(string[] args)
		{
			TestActivationDefault();
			TestActivationConfig();
			TestCascadeActivate();
			TestMaxActivate();
			TestMinActivate();
			TestActivateDeactivate();
		}
		// end Main
	
		private static void StoreSensorPanel()
		{
			File.Delete(Db4oFileName);
			IObjectContainer db = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), Db4oFileName);
			try 
			{
				// create a linked list with length 10
				SensorPanel list = new SensorPanel().CreateList(10); 
				// store all elements with one statement, since all elements are new		
				db.Store(list);
			} 
			finally 
			{
				db.Close();
			}
		}
		// end StoreSensorPanel
	
		private static void TestActivationConfig()
		{
			StoreSensorPanel();
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.ActivationDepth = 1;
			IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
			try 
			{
				Console.WriteLine("Object container activation depth = 1");
				IObjectSet result = db.QueryByExample(new SensorPanel(1));
				ListResult(result);
				if (result.Count >0) 
				{
					SensorPanel sensor = (SensorPanel)result[0];
					SensorPanel next = sensor.Next;
					while (next != null)
					{
						Console.WriteLine(next);
						next = next.Next;
					}
				}
			} 
			finally 
			{
				db.Close();
			}
		}
		// end TestActivationConfig

        private static void TestActivationDefault()
		{
			StoreSensorPanel();
            IObjectContainer db = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), Db4oFileName);
			try 
			{
				Console.WriteLine("Default activation depth");
				IObjectSet  result = db.QueryByExample(new SensorPanel(1));
				ListResult(result);
				if (result.Count >0) 
				{
					SensorPanel sensor = (SensorPanel)result[0];
					SensorPanel next = sensor.Next;
					while (next != null)
					{
						Console.WriteLine(next);
						next = next.Next;
					}
				}
			} 
			finally 
			{
				db.Close();
			}
		}
		// end TestActivationDefault

        private static void TestCascadeActivate()
		{
			StoreSensorPanel();
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.ObjectClass(typeof(SensorPanel)).CascadeOnActivate(true);
			IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
			try 
			{
				Console.WriteLine("Cascade activation");
				IObjectSet result = db.QueryByExample(new SensorPanel(1));
				ListResult(result);
				if (result.Count >0) 
				{
					SensorPanel sensor = (SensorPanel)result[0];
					SensorPanel next = sensor.Next;
					while (next != null)
					{
						Console.WriteLine(next);
						next = next.Next;
					}
				}
			} 
			finally 
			{
				db.Close();
			}
		}
		// end TestCascadeActivate

        private static void TestMinActivate()
		{
			StoreSensorPanel();
			// note that the minimum applies for *all* instances in the hierarchy
			// the system ensures that every instantiated List object will have it's 
			// members set to a depth of 1
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.ObjectClass(typeof(SensorPanel)).MinimumActivationDepth(1);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
			try 
			{
				Console.WriteLine("Minimum activation depth = 1");
				IObjectSet result = db.QueryByExample(new SensorPanel(1));
				ListResult(result);
				if (result.Count >0) 
				{
					SensorPanel sensor = (SensorPanel)result[0];
					SensorPanel next = sensor.Next;
					while (next != null)
					{
						Console.WriteLine(next);
						next = next.Next;
					}
				}
			} 
			finally 
			{
				db.Close();
			}
		}
		// end TestMinActivate

        private static void TestMaxActivate() 
		{
			StoreSensorPanel();
			// note that the maximum is applied to the retrieved root object and limits activation
			// further down the hierarchy
			IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.ObjectClass(typeof(SensorPanel)).MaximumActivationDepth(2);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try 
			{
				Console.WriteLine("Maximum activation depth = 2 (default = 5)");
				IObjectSet result = db.QueryByExample(new SensorPanel(1));
				ListResult(result);
				if (result.Count > 0) 
				{
					var sensor = (SensorPanel) result[0];
					SensorPanel next = sensor.Next;
					while (next != null) 
					{
						Console.WriteLine(next);
						next = next.Next;
					}
				}
			} 
			finally 
			{
				db.Close();
			}
		
		}
		// end TestMaxActivate

        private static void TestActivateDeactivate()
		{
			StoreSensorPanel();
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.ActivationDepth = 0;
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try 
			{
				Console.WriteLine("Object container activation depth = 0" );
				IObjectSet result = db.QueryByExample(new SensorPanel(1));
				Console.WriteLine("Sensor1:");
				ListResult(result);
				SensorPanel sensor1 = (SensorPanel)result[0];
				TestActivated(sensor1);
			
				Console.WriteLine("Sensor1 activated:");
				db.Activate(sensor1,4);
				TestActivated(sensor1);
			
				Console.WriteLine("Sensor5 activated:");
				result = db.QueryByExample(new SensorPanel(5));
				SensorPanel sensor5 = (SensorPanel)result[0];
				db.Activate(sensor5,4);
				ListResult(result);
				TestActivated(sensor5);
			
				Console.WriteLine("Sensor1 deactivated:");
				db.Deactivate(sensor1,5);
				TestActivated(sensor1);
			
				//			 	DANGER !!!.
				// If you use Deactivate with a higher value than 1
				// make sure that you know whereto members might branch
				// Deactivating list1 also deactivated list5
				Console.WriteLine("Sensor 5 AFTER DEACTIVATE OF Sensor1.");
				TestActivated(sensor5);
			} 
			finally 
			{
				db.Close();
			}
		}
		// end TestActivateDeactivate

        private static void TestActivated(SensorPanel sensor)
		{
			SensorPanel next = sensor;
			do 
			{
				next = next.Next;
				Console.WriteLine(next);
			} while (next != null);
		}
		// end TestActivated

        private static void ListResult(IObjectSet result)
		{
			Console.WriteLine(result.Count);
			foreach (object item in result)
			{
				Console.WriteLine(item);
			}
		}
		// end ListResult
	}
}
