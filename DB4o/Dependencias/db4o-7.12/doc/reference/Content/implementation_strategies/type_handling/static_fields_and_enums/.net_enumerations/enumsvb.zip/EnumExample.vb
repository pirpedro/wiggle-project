' Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com 

Imports Db4objects.Db4o
Imports System.Collections
Imports System.IO
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Diagnostic
Imports Db4objects.Db4o.Query


Namespace Db4odoc.Enums
    Class EnumExample

        Private Const Db4oFileName As String = "reference.db4o"


        Public Shared Sub Main(ByVal args As String())
            PopulateDatabase()
            Using db As IObjectContainer = OpenDatabase()
                System.Console.WriteLine("Query by example:")
                Dim result1 As IObjectSet = RunQueryByExample(db)
                ListResult(result1)

                System.Console.WriteLine("SODA query:")
                Dim result2 As IObjectSet = RunSODAQuery(db)
                ListResult(result2)

                System.Console.WriteLine("LINQ:")
                Dim result3 As IEnumerable = RunLinqQuery(db)
                ListResult(result3)

                TestUpdate(db)

            End Using
        End Sub
        ' end Main

        Private Shared Sub TestUpdate(ByVal db As IObjectContainer)
            System.Console.WriteLine(String.Format("Enums before update: {0}", GetAllStates(db)))
            Dim result As IEnumerable = RunLinqQuery(db)
            For Each d As Door In result
                d._state = DoorState.Closed
                db.Store(d)
            Next
            System.Console.WriteLine(String.Format("Enums after update: {0}", GetAllStates(db)))
        End Sub
        ' end TestUpdate

        Private Shared Function RunLinqQuery(ByVal db As IObjectContainer) As IEnumerable
            Return db.Query(Function(d As Door) d._state = DoorState.Open)
        End Function
        ' end RunLinqQuery

        Private Shared Function GetAllStates(ByVal db As IObjectContainer) As Integer
            Return db.Query(GetType(DoorState)).Count
        End Function
        ' end GetAllStates

        Private Shared Function RunSODAQuery(ByVal db As IObjectContainer) As IObjectSet
            Dim query As IQuery = db.Query()
            query.Constrain(GetType(Door))
            query.Descend("_state").Constrain(DoorState.Open)

            Return query.Execute()
        End Function
        ' end RunSODAQuery

        Private Shared Sub PopulateDatabase()
            File.Delete(Db4oFileName)
            Using db As IObjectContainer = OpenDatabase()
                Dim openDoor As New Door(DoorState.Open)
                db.Store(openDoor)
                Dim closedDoor As New Door(DoorState.Closed)
                db.Store(closedDoor)
            End Using
        End Sub
        ' end PopulateDatabase

        Private Shared Function OpenDatabase() As IObjectContainer
            Return Db4oFactory.OpenFile(Config(), Db4oFileName)
        End Function
        ' end OpenDatabase

        Private Shared Function Config() As IConfiguration
            Dim configuration As IConfiguration = Db4oFactory.NewConfiguration()
            configuration.OptimizeNativeQueries(True)

            Return configuration
        End Function
        ' end Config

        Public Shared Function RunQueryByExample(ByVal db As IObjectContainer) As IObjectSet
            Return db.QueryByExample(New Door(DoorState.Open))
        End Function
        ' end RunQueryByExample

        Public Shared Sub ListResult(ByVal result As IEnumerable)
            Dim o
            For Each o In result
                System.Console.WriteLine(o.ToString())
            Next
        End Sub
        ' end ListResult

    End Class
End Namespace
