/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using Db4objects.Db4o;
using System.Collections;
using System.IO;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Diagnostic;
using Db4objects.Db4o.Query;


namespace Db4odoc.Enums
{
    class EnumExample
    {

        private const string Db4oFileName = "reference.db4o";


        public static void Main(string[] args)
        {
            PopulateDatabase();
            using (IObjectContainer db = OpenDatabase())
            {
                System.Console.WriteLine("Query by example:");
                IObjectSet result1 = RunQueryByExample(db);
                ListResult(result1);

                System.Console.WriteLine("SODA query:");
                IObjectSet result2 = RunSODAQuery(db);
                ListResult(result2);

                System.Console.WriteLine("LINQ:");
                IEnumerable result3 = RunLinqQuery(db);
                ListResult(result3);

                TestUpdate(db);
                
            }
        }
        // end Main

        private static void TestUpdate(IObjectContainer db)
        {
            System.Console.WriteLine(string.Format("Enums before update: {0}", GetAllStates(db)));
            IEnumerable result = RunLinqQuery(db);
            foreach (Door d in result)
            {
                d._state = DoorState.Closed;
                db.Store(d);
            }
            System.Console.WriteLine(string.Format("Enums after update: {0}", GetAllStates(db)));
        }
        // end TestUpdate

        private static IEnumerable RunLinqQuery(IObjectContainer db)
        {
            return db.Query((Door d) => d._state == DoorState.Open);
        }
        // end RunLinqQuery

        private static int GetAllStates(IObjectContainer db)
        {
            return db.Query(typeof(DoorState)).Count;
        }
        // end GetAllStates

        private static IObjectSet RunSODAQuery(IObjectContainer db)
        {
            IQuery query = db.Query();
            query.Constrain(typeof(Door));
            query.Descend("_state").Constrain(DoorState.Open);

            return query.Execute();
        }
        // end RunSODAQuery

        private static void PopulateDatabase()
        {
            File.Delete(Db4oFileName);
            using (IObjectContainer db = OpenDatabase())
            {
                Door openDoor = new Door(DoorState.Open);
                db.Store(openDoor);
                Door closedDoor = new Door(DoorState.Closed);
                db.Store(closedDoor);
            }
        }
        // end PopulateDatabase

        private static IObjectContainer OpenDatabase()
        {
            return Db4oFactory.OpenFile(Config(), Db4oFileName);
        }
        // end OpenDatabase

        private static IConfiguration Config()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            configuration.OptimizeNativeQueries(true);
            configuration.Diagnostic().AddListener(new MessageBoxDiagnosticListener());

            return configuration;
        }
        // end Config

        public static IObjectSet RunQueryByExample(IObjectContainer db)
        {
            return db.QueryByExample(new Door(DoorState.Open));
        }
        // end RunQueryByExample

        public static void ListResult(IEnumerable result)
        {
            foreach (var o in result)
            {
                System.Console.WriteLine(o.ToString());
            }
        }
        // end ListResult

        internal class MessageBoxDiagnosticListener : IDiagnosticListener
        {
            public void OnDiagnostic(IDiagnostic d)
            {
                if ((d is NativeQueryNotOptimized) || (d is NativeQueryOptimizerNotLoaded))
                {
                    System.Console.WriteLine(d.GetType() + "\r\n" + d, "Info");
                }
            }
        }
    }
}
