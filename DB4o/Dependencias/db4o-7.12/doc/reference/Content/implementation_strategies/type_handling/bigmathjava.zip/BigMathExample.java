/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
package com.db4odoc.BigMath;

import java.io.*;
import java.math.*;
import java.util.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.query.*;

public class BigMathExample {

	private final static String DB4O_FILE_NAME = "reference.db4o";

	public static void main(String[] args) {
		testDefaultConfiguration();
		testBigMathConfiguration();
	}

	private static EmbeddedConfiguration configBigMathSupport() {
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		config.common().add(new BigMathSupport());
		return config;
	}

	// end configBigMathSupport

	private static ObjectContainer database(EmbeddedConfiguration config) {
		ObjectContainer db = Db4oEmbedded.openFile(config, DB4O_FILE_NAME);
		return db;
	}

	// end database

	private static void testDefaultConfiguration() {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer db = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);
		Probability p1 = new Probability("2e-324");
		db.store(p1);
		p1 = new Probability("3e-324");
		db.store(p1);
		p1 = new Probability("4e-324");
		db.store(p1);
		db.close();

		db = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),
				DB4O_FILE_NAME);
		Query q = db.query();
		q.constrain(Probability.class);
		q.descend("value").constrain(new BigDecimal("3e-324")).greater();
		List<Probability> result = q.execute();
		for (Probability p : result) {
			System.out.println(p);
		}
		db.close();
	}

	// end testDefaultConfiguration

	private static void testBigMathConfiguration() {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer db = Db4oEmbedded.openFile(configBigMathSupport(),
				DB4O_FILE_NAME);
		Probability p1 = new Probability("2e-324");
		db.store(p1);
		p1 = new Probability("3e-324");
		db.store(p1);
		p1 = new Probability("4e-324");
		db.store(p1);
		db.close();

		db = Db4oEmbedded.openFile(configBigMathSupport(), DB4O_FILE_NAME);
		Query q = db.query();
		q.constrain(Probability.class);
		q.descend("value").constrain(new BigDecimal("3e-324")).greater();
		List<Probability> result = q.execute();
		for (Probability p : result) {
			System.out.println(p);
		}
		db.close();

	}
	// end testBigMathConfiguration

}
