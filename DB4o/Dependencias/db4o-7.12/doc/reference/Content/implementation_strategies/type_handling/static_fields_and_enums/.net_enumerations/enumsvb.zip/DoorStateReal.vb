' Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com 
Namespace Db4objects.Db4odoc.Enums
    Enum DoorStateReal
        Open = 0
        Closed = 1
    End Enum
End Namespace