/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
package com.db4odoc.BigMath;

import java.math.*;

public class Probability {
	// Using BigDecimal to represent very small probabilities
	BigDecimal value;
	
	public Probability(String sValue){
		this.value = new BigDecimal(sValue);
	}
	
	public String toString(){
		return value.toString();
	}
}
