/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
namespace Db4odoc.Enums
{
	class Door 
	{ 
		public DoorState _state;
		public Door(DoorState state) 
		{
			_state = state;
		}

        public override string ToString()
        {
            switch (_state)
            {
                case DoorState.Open:
                    return "Open";
                case DoorState.Closed:
                    return "Closed";
            }
            return "Unknown";
        }
	}
}
