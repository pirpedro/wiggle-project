/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
namespace Db4odoc.Autoincrement
{
    class TestObject: CountedObject
    {
        string _name;	
	
	    public TestObject(string name) {
		    _name = name;
	    }
    	
	    public override string ToString() {
		    return _name+"/"+_id;
	    }
    }
}
