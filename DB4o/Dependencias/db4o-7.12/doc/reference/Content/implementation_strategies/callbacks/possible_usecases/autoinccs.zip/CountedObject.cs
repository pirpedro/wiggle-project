/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
/*
 * This class is used to mark classes that need to get an autoincremented ID
 */
namespace Db4odoc.Autoincrement
{
    abstract class CountedObject
    {
        protected int _id;

        public int Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }
    }
}
