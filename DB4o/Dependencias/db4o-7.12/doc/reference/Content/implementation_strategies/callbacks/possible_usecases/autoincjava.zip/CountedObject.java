/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
/*
 * This class is used to mark classes that need to get an autoincremented ID
 */
package com.db4odoc.autoincrement;


public abstract class CountedObject {
	int id;
	
	public void setId(int id){
		this.id = id;
	}
	
	public int getId(){
		return id;
	}
}
