/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
/*
 * Singleton class used to keep auotincrement information 
 * and give the next available ID on request
 */
using System;
using Db4objects.Db4o;

namespace Db4odoc.Autoincrement
{
    class IncrementedId
    {
        private int _no;
        private static IncrementedId _ref;

        private IncrementedId()
        {
            _no = 0;
        }
        // end IncrementedId

        public int GetNextID(IObjectContainer db)
        {
            _no++;
            db.Store(this);
            return _no;
        }
        // end increment

        public static IncrementedId GetIdObject(IObjectContainer db)
        {
            // if _ref is not assigned yet:
            if (_ref == null)
            {
                // check if there is a stored instance from the previous 
                // session in the database
                IObjectSet os = db.QueryByExample(typeof(IncrementedId));
                if (os.Count > 0)
                    _ref = (IncrementedId)os.Next();
            }

            if (_ref == null)
            {
                // create new instance and store it
                Console.WriteLine("Id object is created");
                _ref = new IncrementedId();
                db.Store(_ref);
            }
            return _ref;
        }
        // end getIdObject
    }
}

