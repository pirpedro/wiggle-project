' Copyright (C) 2009 Versant Inc. http://www.db4o.com
Namespace CommitCallbacks

    Class Pilot
        Private _name As String

        Public ReadOnly Property Name() As String
            Get
                Return _name
            End Get
        End Property

        Public Sub New(ByVal name As String)
            _name = name
        End Sub
    End Class
End Namespace