' Copyright (C) 2009 Versant Inc. http://www.db4o.com
Imports System
Imports System.IO
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Query
Imports Db4objects.Db4o.Events

Namespace Db4odoc.Callbacks

    Class CallbacksExample
        Private Const Db4oFileName As String = "reference.db4o"
        Private Shared _container As IObjectContainer

        Public Shared Sub Main(ByVal args As String())
            TestCreated()
            TestCascadedDelete()
            TestIntegrityCheck()
        End Sub
        ' end Main

        Private Shared Function OpenContainer() As IObjectContainer
            If _container Is Nothing Then
                _container = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), Db4oFileName)
            End If
            Return _container
        End Function
        ' end OpenContainer

        Private Shared Sub CloseContainer()
            If Not (_container Is Nothing) Then
                _container.Close()
                _container = Nothing
            End If
        End Sub
        ' end CloseContainer

        Private Shared Sub OnCreated(ByVal sender As Object, ByVal args As ObjectEventArgs)
            Dim obj As Object = args.Object
            If TypeOf obj Is Pilot Then
                Console.WriteLine(obj.ToString)
            End If
        End Sub
        ' end OnCreated

        Private Shared Sub TestCreated()
            File.Delete(Db4oFileName)
            Dim container As IObjectContainer = OpenContainer()
            Try
                Dim registry As IEventRegistry = EventRegistryFactory.ForObjectContainer(container)
                ' register an event handler, which will print all the car objects, that have been Created
                AddHandler registry.Created, AddressOf OnCreated
                Dim car As Car = New Car("BMW", New Pilot("Rubens Barrichello"))
                container.Store(car)
            Finally
                CloseContainer()
            End Try
        End Sub
        ' end TestCreated

        Private Shared Sub FillContainer()
            File.Delete(Db4oFileName)
            Dim container As IObjectContainer = OpenContainer()
            Try
                Dim car As Car = New Car("BMW", New Pilot("Rubens Barrichello"))
                container.Store(car)
                car = New Car("Ferrari", New Pilot("Kimi Raikkonen"))
                container.Store(car)
            Finally
                CloseContainer()
            End Try
        End Sub
        ' end FillContainer

        Private Shared Sub OnDeleted(ByVal sender As Object, ByVal args As ObjectEventArgs)
            Dim obj As Object = args.Object
            If TypeOf obj Is Car Then
                OpenContainer.Delete(CType(obj, Car).Pilot)
            End If
        End Sub
        ' end OnDeleted

        Private Shared Sub TestCascadedDelete()
            FillContainer()
            Dim container As IObjectContainer = OpenContainer()
            Try
                ' check the contents of the database
                Dim result As IList = container.QueryByExample(Nothing)
                ListResult(result)
                Dim registry As IEventRegistry = EventRegistryFactory.ForObjectContainer(container)
                ' register an event handler, which will delete the pilot when his car is Deleted 
                AddHandler registry.Deleted, AddressOf OnDeleted
                ' delete all the cars
                Dim cars As IList(Of Car) = container.Query(Of Car)()
                For Each c As Car In cars
                    container.Delete(c)
                Next
                ' check if the database is empty
                result = container.QueryByExample(Nothing)
                ListResult(result)
            Finally
                CloseContainer()
            End Try
        End Sub
        ' end TestCascadedDelete

        Private Shared Sub OnDeleting(ByVal sender As Object, ByVal args As CancellableObjectEventArgs)
            Dim obj As Object = args.Object
            If TypeOf obj Is Pilot Then
                ' search for the cars referencing the pilot object
                Dim container As IObjectContainer = OpenContainer()
                Dim q As IQuery = container.Query
                q.Constrain(GetType(Car))
                q.Descend("_pilot").Constrain(obj)
                Dim result As IList = q.Execute
                If result.Count > 0 Then
                    Console.WriteLine("Object " + CType(obj, Pilot).ToString() + " can't be Deleted as object container has references to it")
                    args.Cancel()
                End If
            End If
        End Sub
        ' end OnDeleting

        Private Shared Sub TestIntegrityCheck()
            FillContainer()
            Dim container As IObjectContainer = OpenContainer()
            Try
                Dim registry As IEventRegistry = EventRegistryFactory.ForObjectContainer(container)
                ' register an event handler, which will stop Deleting a pilot when it is referenced from a car 
                AddHandler registry.Deleting, AddressOf OnDeleting
                ' check the contents of the database
                Dim result As IList = container.QueryByExample(Nothing)
                ListResult(result)
                ' try to delete all the pilots
                Dim pilots As IList(Of Pilot) = container.Query(Of Pilot)()
                For Each p As Pilot In pilots
                    container.Delete(p)
                Next
                ' check if any of the objects were Deleted
                result = container.QueryByExample(Nothing)
                ListResult(result)
            Finally
                CloseContainer()
            End Try
        End Sub
        ' end TestIntegrityCheck

        Private Shared Sub ListResult(Of T)(ByVal result As IList(Of T))
            Console.WriteLine(result.Count)
            For Each o As T In result
                Console.WriteLine(o.ToString())
            Next
        End Sub
        ' end ListResult

        Private Shared Sub ListResult(ByVal result As IList)
            Console.WriteLine(result.Count)
            For Each o In result
                Console.WriteLine(o.ToString())
            Next
        End Sub
        ' end ListResult

    End Class
End Namespace