/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
namespace Db4odoc.Callbacks
{
	public class Pilot
	{
		string _name;
		
		public Pilot(string name)
		{
			_name = name;
		}
        
		public string Name
		{
			get
			{
				return _name;
			}
		}
        
		override public string ToString()
		{
			return _name;
		}
	}
}
