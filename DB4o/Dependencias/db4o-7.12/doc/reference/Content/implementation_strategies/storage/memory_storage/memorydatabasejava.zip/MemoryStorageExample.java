package com.db4odoc.MemoryStorage;

import java.io.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.io.*;

public class MemoryStorageExample {

	private final static String DB4O_URI = "reference.db4o";
	private final static int OBJECT_COUNT = 10000;

	public static void main(String[] args) throws IOException {
		createDatabase(getConfig());
		createDatabase(getInMemoryConfig());
		reuseMemoryBin();
		storeMemoryBin();
		queryDatabase();
	}

	private static EmbeddedConfiguration getInMemoryConfig() {
		MemoryStorage ms = new MemoryStorage();
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		config.file().storage(ms);
		return config;
	}

	// end getInMemoryConfig

	private static EmbeddedConfiguration getConfig() {
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		return config;
	}

	// end getConfig

	private static void createDatabase(EmbeddedConfiguration config) {
		// the following line is only necessary for the database on disk
		new File(DB4O_URI).delete();

		long startTime = System.currentTimeMillis();
		// DB4O_URI will be the name of the database file for the default
		// configuration and the name of a MemoryBin for in-memory database
		ObjectContainer container = Db4oEmbedded.openFile(config, DB4O_URI);
		try {
			Library lib = new Library();
			for (int i = 0; i < OBJECT_COUNT; i++) {
				lib.addBook(new Book("title" + i, lib));
			}
			container.store(lib);
			Book book = (Book) container.queryByExample(
					new Book("title1", null)).get(0);
			System.out.println(book);
		} finally {
			container.close();
		}
		System.out.println(String.format("Time to create a database: %d ms",
				System.currentTimeMillis() - startTime));
	}
	// end createDatabase

	public static void reuseMemoryBin() {
		// Create original storage
		MemoryStorage origStorage = new MemoryStorage();
		EmbeddedConfiguration origConfig = Db4oEmbedded.newConfiguration();
		origConfig.file().storage(origStorage);
		// A new MemoryBin identified by DB4O_URI will be created
		ObjectContainer origDb = Db4oEmbedded.openFile(origConfig, DB4O_URI);
		origDb.store(new Book("Alice in Wonderland"));
		origDb.close();

		// Retrieve original bin by its URI
		MemoryBin origBin = origStorage.bin(DB4O_URI);
		// This bin contains the database data
		byte[] data = origBin.data();

		// Create a new bin, using the data from the original bin
		MemoryBin newBin = new MemoryBin(data, new DoublingGrowthStrategy());
		MemoryStorage newStorage = new MemoryStorage();
		// Assign the new bin to a new MemoryStorage using the same DB4O_URI
		newStorage.bin(DB4O_URI, newBin);
		EmbeddedConfiguration newConfig = Db4oEmbedded.newConfiguration();
		newConfig.file().storage(origStorage);
		// Open object container using the new bin with the original data
		ObjectContainer newDb = Db4oEmbedded.openFile(newConfig, DB4O_URI);
		// test that the data is still there
		Book book = (Book) newDb
				.queryByExample(new Book("Alice in Wonderland")).get(0);
		System.out.println(book);
		newDb.close();
	}

	// end reuseMemoryBin

	public static void storeMemoryBin() throws IOException {
		MemoryStorage origStorage = new MemoryStorage();
		EmbeddedConfiguration origConfig = Db4oEmbedded.newConfiguration();
		origConfig.file().storage(origStorage);
		ObjectContainer origDb = Db4oEmbedded.openFile(origConfig, DB4O_URI);
		origDb.store(new Book("Alice in Wonderland"));
		origDb.close();

		MemoryBin origBin = origStorage.bin(DB4O_URI);
		byte[] data = origBin.data();
		OutputStream out = new FileOutputStream("memory.db4o");
		out.write(data, 0, data.length);
		out.close();

		ObjectContainer newDb = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), "memory.db4o");
		Book book = (Book) newDb
				.queryByExample(new Book("Alice in Wonderland")).get(0);
		System.out.println(book);
		newDb.close();
	}

	// end storeMemoryBin

	private static void queryDatabase() {

		ObjectContainer container = Db4oEmbedded
				.openFile(getConfig(), DB4O_URI);
		try {
			Book book = (Book) container.queryByExample(
					new Book("title1", null)).get(0);
			System.out.println(book);
		} finally {
			container.close();
		}
	}
	// end queryDatabase

}
