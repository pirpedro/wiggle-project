﻿Imports System
Imports System.IO
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.IO

Namespace Db4objects.Db4odoc.MemoryDatabase
    Class MemoryStorageExample
        Private Const Db4oUri As String = "reference.db4o"
        Private Const ObjectCount As Integer = 10000

        Public Shared Sub Main(ByVal args As String())
            CreateDatabase(GetConfig())
            CreateDatabase(GetInMemoryConfig())
            ReuseMemoryBin()
            StoreMemoryBin()
        End Sub

        Private Shared Function GetInMemoryConfig() As IEmbeddedConfiguration
            Dim ms As New MemoryStorage()
            Dim config As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            config.File.Storage = ms
            Return config
        End Function

        ' end GetInMemoryConfig

        Private Shared Function GetConfig() As IEmbeddedConfiguration
            Dim config As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            Return config
        End Function

        ' end GetConfig

        Private Shared Sub CreateDatabase(ByVal config As IEmbeddedConfiguration)
            ' the following line is only necessary for the database on disk
            File.Delete(Db4oUri)

            Dim startTime As Long = DateTime.Now.Ticks
            ' Db4oUri will be the name of the database file for the default
            ' configuration and the name of a MemoryBin for in-memory database
            Dim container As IObjectContainer = Db4oEmbedded.OpenFile(config, Db4oUri)
            Try
                Dim [lib] As New Library()
                For i As Integer = 0 To ObjectCount - 1
                    [lib].AddBook(New Book("title" & i, [lib]))
                Next
                container.Store([lib])
                Dim book As Book = DirectCast(container.QueryByExample(New Book("title1", Nothing))(0), Book)
                System.Console.WriteLine(book)
            Finally
                container.Close()
            End Try
            System.Console.WriteLine([String].Format("Time to create a database: {0} ticks", DateTime.Now.Ticks - startTime))
        End Sub
        ' end CreateDatabase

        Public Shared Sub ReuseMemoryBin()
            ' Create original storage
            Dim origStorage As New MemoryStorage()
            Dim origConfig As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            origConfig.File.Storage = origStorage
            ' A new MemoryBin identified by Db4oUri will be created
            Dim origDb As IObjectContainer = Db4oEmbedded.OpenFile(origConfig, Db4oUri)
            origDb.Store(New Book("Alice in Wonderland"))
            origDb.Close()

            ' Retrieve original bin by its URI
            Dim origBin As MemoryBin = origStorage.Bin(Db4oUri)
            ' This bin contains the database data
            Dim data As Byte() = origBin.Data()

            ' Create a new bin, using the data from the original bin
            Dim newBin As New MemoryBin(data, New DoublingGrowthStrategy())
            Dim newStorage As New MemoryStorage()
            ' Assign the new bin to a new MemoryStorage using the same Db4oUri
            newStorage.Bin(Db4oUri, newBin)
            Dim newConfig As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            newConfig.File.Storage = origStorage
            ' Open object container using the new bin with the original data
            Dim newDb As IObjectContainer = Db4oEmbedded.OpenFile(newConfig, Db4oUri)
            ' test that the data is still there
            Dim book As Book = DirectCast(newDb.QueryByExample(New Book("Alice in Wonderland"))(0), Book)
            System.Console.WriteLine(book)
            newDb.Close()
        End Sub

        ' end ReuseMemoryBin

        Public Shared Sub StoreMemoryBin()
            Dim origStorage As New MemoryStorage()
            Dim origConfig As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            origConfig.File.Storage = origStorage
            Dim origDb As IObjectContainer = Db4oEmbedded.OpenFile(origConfig, Db4oUri)
            origDb.Store(New Book("Alice in Wonderland"))
            origDb.Close()

            Dim origBin As MemoryBin = origStorage.Bin(Db4oUri)
            Dim data As Byte() = origBin.Data()
            Dim fs1 As New FileStream("memory.db4o", FileMode.OpenOrCreate, FileAccess.Write)
            Dim bw As New BinaryWriter(fs1)
            bw.Write(data)
            bw.Close()
            fs1.Close()


            Dim newDb As IObjectContainer = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), "memory.db4o")
            Dim book As Book = DirectCast(newDb.QueryByExample(New Book("Alice in Wonderland"))(0), Book)
            System.Console.WriteLine(book)
            newDb.Close()
        End Sub
    End Class

    ' end StoreMemoryBin

End Namespace
