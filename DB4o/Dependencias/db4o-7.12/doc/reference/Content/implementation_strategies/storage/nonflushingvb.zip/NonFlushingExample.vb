' Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com 

Imports System
Imports System.IO

Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.IO
Imports Db4objects.Db4o.Query

Namespace Db4odoc.Storage

    Public Class NonFlushingExample
        Private Const Db4oFileName As String = "reference.db4o"

        Public Shared Sub Main(ByVal args() As String)
            TestNonFlushingAdapter()
        End Sub
        ' end Main

        Private Shared Sub TestNonFlushingAdapter()

            File.Delete(Db4oFileName)

            Dim config As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            config.File.Storage = New NonFlushingStorage(New FileStorage())
            Dim container As IObjectContainer = Db4oEmbedded.OpenFile(config, Db4oFileName)
            Try
                Dim pilot As Pilot = New Pilot("Rubens Barrichello", 99)
                container.Store(pilot)
                Dim startTime As Long = DateTime.Now.Ticks
                container.Commit()
                System.Console.WriteLine(String.Format("Commit time with NonFlushingStorage: {0} ms", _
                    ((DateTime.Now.Ticks - startTime) / TimeSpan.TicksPerMillisecond).ToString()))
            Finally
                container.Close()
            End Try

            '
            File.Delete(Db4oFileName)
            container = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), Db4oFileName)
            Try
                Dim pilot As Pilot = New Pilot("Rubens Barrichello", 99)
                container.Store(pilot)
                Dim startTime As Long = DateTime.Now.Ticks
                container.Commit()
                System.Console.WriteLine(String.Format("Commit time with default Storage: {0} ms", _
                    ((DateTime.Now.Ticks - startTime) / TimeSpan.TicksPerMillisecond).ToString()))
            Finally
                container.Close()
            End Try
        End Sub
        ' end TestNonFlushingAdapter

    End Class
End Namespace

