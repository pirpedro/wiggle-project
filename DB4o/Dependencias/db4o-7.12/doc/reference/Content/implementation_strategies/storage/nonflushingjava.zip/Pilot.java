/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
package com.db4odoc.Storage;

public class Pilot {
	String name;
	int points;
	
	public Pilot(String name, int points){
		this.name = name;
		this.points = points;
	}
	
	public String toString(){
		return String.format("%s [%d]", name, points);
	}
}
