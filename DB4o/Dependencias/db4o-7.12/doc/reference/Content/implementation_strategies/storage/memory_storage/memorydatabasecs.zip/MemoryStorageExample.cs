﻿using System;
using System.IO;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.IO;

namespace Db4objects.Db4odoc.MemoryDatabase
{
    class MemoryStorageExample
    {
        private const string Db4oUri = "reference.db4o";
        private const int ObjectCount = 10000;

        public static void Main(string[] args)
        {
            CreateDatabase(GetConfig());
            CreateDatabase(GetInMemoryConfig());
            ReuseMemoryBin();
            StoreMemoryBin();
        }

        private static IEmbeddedConfiguration GetInMemoryConfig()
        {
            MemoryStorage ms = new MemoryStorage();
            IEmbeddedConfiguration config = Db4oEmbedded.NewConfiguration();
            config.File.Storage = ms;
            return config;
        }

        // end GetInMemoryConfig

        private static IEmbeddedConfiguration GetConfig()
        {
            IEmbeddedConfiguration config = Db4oEmbedded.NewConfiguration();
            return config;
        }

        // end GetConfig

        private static void CreateDatabase(IEmbeddedConfiguration config)
        {
            // the following line is only necessary for the database on disk
            File.Delete(Db4oUri);

            long startTime = DateTime.Now.Ticks;
            // Db4oUri will be the name of the database file for the default
            // configuration and the name of a MemoryBin for in-memory database
            IObjectContainer container = Db4oEmbedded.OpenFile(config, Db4oUri);
            try
            {
                Library lib = new Library();
                for (int i = 0; i < ObjectCount; i++)
                {
                    lib.AddBook(new Book("title" + i, lib));
                }
                container.Store(lib);
                Book book = (Book)container.QueryByExample(
                        new Book("title1", null))[0];
                System.Console.WriteLine(book);
            }
            finally
            {
                container.Close();
            }
            System.Console.WriteLine(String.Format("Time to create a database: {0} ticks",
                    DateTime.Now.Ticks - startTime));
        }
        // end CreateDatabase

        public static void ReuseMemoryBin()
        {
            // Create original storage
            MemoryStorage origStorage = new MemoryStorage();
            IEmbeddedConfiguration origConfig = Db4oEmbedded.NewConfiguration();
            origConfig.File.Storage = origStorage;
            // A new MemoryBin identified by Db4oUri will be created
            IObjectContainer origDb = Db4oEmbedded.OpenFile(origConfig, Db4oUri);
            origDb.Store(new Book("Alice in Wonderland"));
            origDb.Close();

            // Retrieve original bin by its URI
            MemoryBin origBin = origStorage.Bin(Db4oUri);
            // This bin contains the database data
            byte[] data = origBin.Data();

            // Create a new bin, using the data from the original bin
            MemoryBin newBin = new MemoryBin(data, new DoublingGrowthStrategy());
            MemoryStorage newStorage = new MemoryStorage();
            // Assign the new bin to a new MemoryStorage using the same Db4oUri
            newStorage.Bin(Db4oUri, newBin);
            IEmbeddedConfiguration newConfig = Db4oEmbedded.NewConfiguration();
            newConfig.File.Storage = origStorage;
            // Open object container using the new bin with the original data
            IObjectContainer newDb = Db4oEmbedded.OpenFile(newConfig, Db4oUri);
            // test that the data is still there
            Book book = (Book)newDb
                    .QueryByExample(new Book("Alice in Wonderland"))[0];
            System.Console.WriteLine(book);
            newDb.Close();
        }

        // end ReuseMemoryBin

        public static void StoreMemoryBin()
        {
            MemoryStorage origStorage = new MemoryStorage();
            IEmbeddedConfiguration origConfig = Db4oEmbedded.NewConfiguration();
            origConfig.File.Storage = origStorage;
            IObjectContainer origDb = Db4oEmbedded.OpenFile(origConfig, Db4oUri);
            origDb.Store(new Book("Alice in Wonderland"));
            origDb.Close();

            MemoryBin origBin = origStorage.Bin(Db4oUri);
            byte[] data = origBin.Data();
            FileStream fs1 = new FileStream("memory.db4o", FileMode.OpenOrCreate,
    FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs1);
            bw.Write(data);
            bw.Close();
            fs1.Close();


            IObjectContainer newDb = Db4oEmbedded.OpenFile(Db4oEmbedded
                    .NewConfiguration(), "memory.db4o");
            Book book = (Book)newDb
                    .QueryByExample(new Book("Alice in Wonderland"))[0];
            System.Console.WriteLine(book);
            newDb.Close();
        }

        // end StoreMemoryBin

    }
}
