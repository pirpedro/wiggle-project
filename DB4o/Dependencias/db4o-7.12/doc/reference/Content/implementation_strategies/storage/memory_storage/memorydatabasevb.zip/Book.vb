﻿Imports System

Namespace Db4objects.Db4odoc.MemoryDatabase
    Class Book
        Private library As Library
        Private title As String

        Public Sub New(ByVal title As String)
            Me.title = title
        End Sub

        Public Sub New(ByVal title As String, ByVal library As Library)
            Me.title = title
            Me.library = library
        End Sub

        Public Overloads Overrides Function ToString() As String
            Return title
        End Function
    End Class
End Namespace
