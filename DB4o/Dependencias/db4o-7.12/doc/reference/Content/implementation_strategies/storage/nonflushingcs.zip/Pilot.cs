﻿/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
using System;

namespace Db4odoc.Storage
{

    public class Pilot
    {
        String name;
        int points;

        public Pilot(String name, int points)
        {
            this.name = name;
            this.points = points;
        }

        public override string ToString()
        {
            return String.Format("{0} [{1}]", name, points);
        }
    }
}