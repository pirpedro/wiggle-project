﻿Imports System.Collections.Generic

Namespace Db4objects.Db4odoc.MemoryDatabase
    Class Library
        Private books As New List(Of Book)()


        Public Sub AddBook(ByVal book As Book)
            If Not books.Contains(book) Then
                books.Add(book)
            End If
        End Sub
    End Class
End Namespace
