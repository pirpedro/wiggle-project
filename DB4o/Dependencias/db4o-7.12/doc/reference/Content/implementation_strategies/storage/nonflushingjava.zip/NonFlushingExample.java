/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.Storage;

import java.io.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.io.*;

public class NonFlushingExample  {
	private final static String DB4O_FILE_NAME="reference.db4o";
	
	public static void main(String[] args) {
		testNonFlushingAdapter();
	}
	// end main
	
	private static void testNonFlushingAdapter(){
		new File(DB4O_FILE_NAME).delete();
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		config.file().storage(new NonFlushingStorage(new FileStorage()));
		ObjectContainer container = Db4oEmbedded.openFile(config, DB4O_FILE_NAME);
		try {
			Pilot pilot = new Pilot("Rubens Barrichello", 99);
			container.store(pilot);
			long startTime = System.currentTimeMillis();
			container.commit();
			System.out.println("Commit time with NonFlushingStorage: " + 
					(System.currentTimeMillis() - startTime) + " ms.");
		} finally {
			container.close();
		}
		
		//
		new File(DB4O_FILE_NAME).delete();
		container = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(), DB4O_FILE_NAME);
		try {
			Pilot pilot = new Pilot("Rubens Barrichello", 99);
			container.store(pilot);
			long startTime = System.currentTimeMillis();
			container.commit();
			System.out.println("Commit time with default Storage: " + 
					(System.currentTimeMillis() - startTime) + " ms.");
		} finally {
			container.close();
		}
	}
	// end testNonFlushingAdapter
	
	}
