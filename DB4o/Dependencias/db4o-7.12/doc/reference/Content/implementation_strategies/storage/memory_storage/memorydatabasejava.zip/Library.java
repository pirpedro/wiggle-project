package com.db4odoc.MemoryStorage;

import java.util.*;

public class Library {
	ArrayList<Book> books = new ArrayList<Book>();
	
	
	public void addBook(Book book){
		if (!books.contains(book)){
			books.add(book);
		}
	}
}
