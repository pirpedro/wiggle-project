﻿using System;

namespace Db4objects.Db4odoc.MemoryDatabase
{
    class Book
    {
        	Library library;
	String title;
	
	public Book(String title){
		this.title = title;
	}
	
	public Book(String title, Library library){
		this.title = title;
		this.library = library;
	}
	
	public override String ToString(){
		return title;
	}
    }
}
