package com.db4odoc.MemoryStorage;

public class Book {
	Library library;
	String title;
	
	public Book(String title){
		this.title = title;
	}
	
	public Book(String title, Library library){
		this.title = title;
		this.library = library;
	}
	
	@Override
	public String toString(){
		return title;
	}
}
