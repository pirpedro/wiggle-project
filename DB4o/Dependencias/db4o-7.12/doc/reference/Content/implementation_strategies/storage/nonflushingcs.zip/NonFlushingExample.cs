/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System;
using System.IO;

using Db4objects.Db4o;
using Db4objects.Db4o.IO;
using Db4objects.Db4o.Config;

namespace Db4odoc.Storage
{
    public class NonFlushingExample
    {
        private const string Db4oFileName = "reference.db4o";

        public static void Main(string[] args)
        {
            TestNonFlushingAdapter();
        }
        // end Main

        private static void TestNonFlushingAdapter()
        {
            File.Delete(Db4oFileName);
            
            IEmbeddedConfiguration config = Db4oEmbedded.NewConfiguration();
            config.File.Storage = new NonFlushingStorage(new FileStorage());
            IObjectContainer container = Db4oEmbedded.OpenFile(config, Db4oFileName);
            try
            {
                Pilot pilot = new Pilot("Rubens Barrichello", 99);
                container.Store(pilot);
                long startTime = DateTime.Now.Ticks;
                container.Commit();
                System.Console.WriteLine("Commit time with NonFlushingStorage: " +
                        (DateTime.Now.Ticks - startTime)/TimeSpan.TicksPerMillisecond + " ms");
            }
            finally
            {
                container.Close();
            }

            //
            File.Delete(Db4oFileName);
            container = Db4oEmbedded.OpenFile(Db4oEmbedded.NewConfiguration(), Db4oFileName);
            try
            {
                Pilot pilot = new Pilot("Rubens Barrichello", 99);
                container.Store(pilot);
                long startTime = DateTime.Now.Ticks;
                container.Commit();
                System.Console.WriteLine("Commit time with default Storage: " +
                        (DateTime.Now.Ticks - startTime)/ TimeSpan.TicksPerMillisecond + " ms");
            }
            finally
            {
                container.Close();
            }
        }
        // end TestNonFlushingAdapter


    }
}