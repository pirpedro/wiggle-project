﻿using System.Collections.Generic;

namespace Db4objects.Db4odoc.MemoryDatabase
{
    class Library
    {
        List<Book> books = new List<Book>();


        public void AddBook(Book book)
        {
            if (!books.Contains(book))
            {
                books.Add(book);
            }
        }
    }
}
