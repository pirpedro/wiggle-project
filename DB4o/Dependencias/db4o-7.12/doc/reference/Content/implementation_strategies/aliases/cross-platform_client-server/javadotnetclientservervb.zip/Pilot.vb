﻿' Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com 

Imports System

Class Pilot
    Private name As [String]

    Public Sub New(ByVal name As [String])
        Me.name = name
    End Sub

    Public Function getName() As [String]
        Return name
    End Function

    Public Sub setName(ByVal pilotName As [String])
        Me.name = pilotName
    End Sub

    Public Overloads Overrides Function ToString() As [String]
        Return name
    End Function
End Class