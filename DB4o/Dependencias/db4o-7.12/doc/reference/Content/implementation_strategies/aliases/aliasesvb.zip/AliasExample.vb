' Copyright (C) 2004 - 2007 Versant Inc. http://www.db4o.com 
Imports System
Imports System.IO
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config

Namespace Aliases
    Class AliasExample
        Private Const Db4oFileName As String = "reference.db4o"
        Private Shared tAlias As TypeAlias

        Public Shared Sub Main (ByVal args As String())
            Dim configuration As IEmbeddedConfiguration = ConfigureClassAlias()
            SaveDrivers (configuration)
            GetPilots()
            SavePilots()
            configuration = ConfigureAlias()
            GetObjectsWithAlias (configuration)
        End Sub

' end Main

        Private Shared Function ConfigureClassAlias() As IEmbeddedConfiguration
            ' create a new alias
            tAlias = New TypeAlias ("Db4odoc.Aliases.Pilot, Db4odoc", "Db4odoc.Aliases.Driver, Db4odoc")
            ' add the alias to the db4o configuration 
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.AddAlias (tAlias)
            ' check how does the alias resolve
            Console.WriteLine ( _
                               "Stored name for Db4odoc.Aliases.Driver: " + _
                               tAlias.ResolveRuntimeName ("Db4odoc.Aliases.Driver, Db4objects.Db4odoc"))
            Console.WriteLine ( _
                               "Runtime name for Db4odoc.Aliases.Pilot: " + _
                               tAlias.ResolveStoredName ("Db4odoc.Aliases.Pilot, Db4objects.Db4odoc"))
            Return configuration
        End Function

' end ConfigureClassAlias

        Private Shared Sub SaveDrivers (ByVal configuration As IEmbeddedConfiguration)
            File.Delete (Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile (configuration, Db4oFileName)
            Try
                Dim driver As Driver = New Driver ("David Barrichello", 99)
                db.Store (driver)
                driver = New Driver ("Kimi Raikkonen", 100)
                db.Store (driver)
            Finally
                db.Close()
            End Try
        End Sub

' end SaveDrivers

        Private Shared Sub SavePilots()
            File.Delete (Db4oFileName)
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile (configuration, Db4oFileName)
            Try
                Dim pilot As Pilot = New Pilot ("David Barrichello", 99)
                db.Store (pilot)
                pilot = New Pilot ("Kimi Raikkonen", 100)
                db.Store (pilot)
            Finally
                db.Close()
            End Try
        End Sub

' end SavePilots

        Private Shared Sub GetPilots()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile (Configuration, Db4oFileName)
            Try
                Dim result As IObjectSet = db.QueryByExample (GetType (Pilot))
                ListResult (result)
            Finally
                db.Close()
            End Try
        End Sub

' end GetPilots

        Private Shared Sub GetObjectsWithAlias (ByVal configuration As IEmbeddedConfiguration)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile (configuration, Db4oFileName)
            Try
                Dim result As IObjectSet = db.Query (GetType (NewAlias.Pilot))
                ListResult (result)
            Finally
                db.Close()
            End Try
        End Sub

' end GetObjectsWithAlias

        Private Shared Sub ListResult (ByVal result As IObjectSet)
            Console.WriteLine (result.Count)
            While result.HasNext
                Console.WriteLine (result.Next)
            End While
        End Sub

' end ListResult

        Private Shared Function ConfigureAlias() As IEmbeddedConfiguration
            Dim wAlias As WildcardAlias = New WildcardAlias ("Db4odoc.Aliases.*", "Db4odoc.Aliases.NewAlias.*")
            ' Add the Alias to the configuration
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.AddAlias (wAlias)
            Console.WriteLine ( _
                               "Stored name for Db4odoc.Aliases.NewAlias.Pilot: " + _
                               wAlias.ResolveRuntimeName ("Db4odoc.Aliases.NewAlias.Pilot"))
            Console.WriteLine ( _
                               "Runtime name for Db4odoc.Aliases.Pilot: " + _
                               wAlias.ResolveStoredName ("Db4odoc.Aliases.Pilot"))
            Return configuration
        End Function

' end ConfigureAlias
    End Class
End Namespace