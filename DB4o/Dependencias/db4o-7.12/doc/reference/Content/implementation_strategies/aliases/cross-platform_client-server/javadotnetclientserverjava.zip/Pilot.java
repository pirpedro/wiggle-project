/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */

package com.db4odoc.JavaDotNetClientServer;


public class Pilot {
	private String name;
    
    public Pilot(String name) {
        this.name=name;
    }

    public String getName() {
        return name;
    }
    
    public void setName(String name){
    	this.name = name;
    }

    public String toString() {
        return name;
    }
}

