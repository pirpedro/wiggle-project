/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
package com.db4odoc.JavaDotNetClientServer;

import com.db4o.*;
import com.db4o.cs.*;
import com.db4o.cs.config.*;
import com.db4o.messaging.*;

public class Server implements ServerInfo, MessageRecipient {
	  
	  /**
	   * setting the value to true denotes that the server should be closed
	   */
	  private boolean stop = false;
	  
	  /**
	   * starts a db4o server using the configuration from
	   * {@link ServerInfo}.
	   */
	  public static void main(String[] arguments) {
	    new Server().runServer();
	  } 
	  // end main
	  
	  /**
	   * opens the ObjectServer, and waits forever until close() is called
	   * or a StopServer message is being received.
	   */
	  public void runServer(){
			    synchronized(this){
	    	ServerConfiguration c = Db4oClientServer.newServerConfiguration();
	    	
	      ObjectServer db4oServer = Db4oClientServer.openServer(c, FILE, PORT);
	      db4oServer.grantAccess(USER, PASS);
	      
	      // Using the messaging functionality to redirect all
	      // messages to this.processMessage
	      db4oServer.ext().configure().clientServer().setMessageRecipient(this);
	      
	      // to identify the thread in a debugger
	      Thread.currentThread().setName(this.getClass().getName());
	      
	      // We only need low priority since the db4o server has
	      // it's own thread.
	      Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
	      try {
	          if(! stop){
	            // wait forever for notify() from close()
	            this.wait(Long.MAX_VALUE);   
	          }
	      } catch (Exception e) {
	        e.printStackTrace();
	      }
	      db4oServer.close();
	    }
	  }
	  // end runServer
	  
	  /**
	   * messaging callback
	   * @see com.db4o.messaging.MessageRecipient#processMessage(ObjectContainer, Object)
	   */
	  public void processMessage(MessageContext context, Object message) {
	    if(message instanceof StopServer){
	      close();
	    }
	  }
	  // end processMessage
	  
	  /**
	   * closes this server.
	   */
	  public void close(){
	    synchronized(this){
	      stop = true;
	      this.notify();
	    }
	  }
	  // end close

}
