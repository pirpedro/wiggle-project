/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
package com.db4odoc.JavaDotNetClientServer;

import java.util.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.cs.*;
import com.db4o.cs.config.*;

public class Client {

	public static final String host = "localhost";

	public static final String fileName = "reference.db4o";

	public static final int port = 0xdb40;

	public static final String user = "db4o";

	public static final String password = "db4o";

	public static void main(String[] args) {
		ObjectContainer db = Db4oClientServer.openClient(getConfig(), host,
				port, user, password);
		db.store(new Car("Ferrari", new Pilot("Michael Schumacher")));
		db.store(new Car("BMW", new Pilot("Rubens Barrichello")));
		db.close();

		db = Db4oClientServer.openClient(getConfig(), host, port, user,
				password);
		List<Car> cars = db.queryByExample(Car.class);
		for (Car car : cars) {
			System.out.println(car);
		}
		db.close();
	}
	// end main

	private static ClientConfiguration getConfig() {
		ClientConfiguration config = Db4oClientServer.newClientConfiguration();
		config.common().add(new DotnetSupport(true));
		config.common().addAlias(
				new WildcardAlias(
						"JavaDotnetClientServer.*, JavaDotnetClientServer",
						"com.db4odoc.JavaDotNetClientServer.*"));
		return config;
	}
	// end getConfig
}
