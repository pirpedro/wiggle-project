/* Copyright (C) 2004 - 2009 Versant Inc. http://www.db4o.com */

package com.db4odoc.aliases;

import java.io.*;

import com.db4o.*;
import com.db4o.config.*;

public class AliasExample {
	private static final String DB4O_FILE_NAME = "reference.db4o";
	private static TypeAlias tAlias;

	public static void main(String args[]) {
		EmbeddedConfiguration configuration = configureClassAlias();
		saveDrivers(configuration);
		getPilots();
		savePilots();
		configuration = configureAlias();
		getObjectsWithAlias(configuration);
	}

	// end main

	private static EmbeddedConfiguration configureClassAlias() {
		// create a new alias
		tAlias = new TypeAlias("com.db4odoc.aliases.Pilot",
				"com.db4odoc.aliases.Driver");
		// add the alias to the db4o configuration
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		configuration.common().addAlias(tAlias);
		// check how does the alias resolve
		System.out.println("Stored name for com.db4odoc.aliases.Driver: "
				+ tAlias.resolveRuntimeName("com.db4odoc.aliases.Driver"));
		System.out.println("Runtime name for com.db4odoc.aliases.Pilot: "
				+ tAlias.resolveStoredName("com.db4odoc.aliases.Pilot"));
		return configuration;
	}

	// end configureClassAlias


	private static void saveDrivers(EmbeddedConfiguration configuration) {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4oEmbedded.openFile(configuration,
				DB4O_FILE_NAME);
		try {
			Driver driver = new Driver("David Barrichello", 99);
			container.store(driver);
			driver = new Driver("Kimi Raikkonen", 100);
			container.store(driver);
		} finally {
			container.close();
		}
	}

	// end saveDrivers

	private static void savePilots() {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);
		try {
			Pilot pilot = new Pilot("David Barrichello", 99);
			container.store(pilot);
			pilot = new Pilot("Kimi Raikkonen", 100);
			container.store(pilot);
		} finally {
			container.close();
		}
	}

	// end savePilots

	private static void getPilots() {
		ObjectContainer container = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);

		try {
			ObjectSet<com.db4odoc.aliases.Pilot> result = container
					.query(com.db4odoc.aliases.Pilot.class);
			listResult(result);
		} finally {
			container.close();
		}
	}

	// end getPilots

	private static void getObjectsWithAlias(EmbeddedConfiguration configuration) {
		ObjectContainer container = Db4oEmbedded.openFile(configuration,
				DB4O_FILE_NAME);
		try {
			ObjectSet<com.db4odoc.aliases.newalias.Pilot> result = container
					.query(com.db4odoc.aliases.newalias.Pilot.class);
			listResult(result);
		} finally {
			container.close();
		}
	}

	// end getObjectsWithAlias

	private static <T> void listResult(ObjectSet<T> result) {
		System.out.println(result.size());
		while (result.hasNext()) {
			System.out.println(result.next());
		}
	}

	// end listResult

	private static EmbeddedConfiguration configureAlias() {
		// com.db4odoc.aliases.* - package for the classes saved in the database
		// com.db4odoc.aliases.newalias.* - runtime package
		WildcardAlias wAlias = new WildcardAlias("com.db4odoc.aliases.*",
				"com.db4odoc.aliases.newalias.*");
		// add the alias to the configuration
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		configuration.common().addAlias(wAlias);
		System.out
				.println("Stored name for com.db4odoc.aliases.newalias.Pilot: "
						+ wAlias
								.resolveRuntimeName("com.db4odoc.aliases.newalias.Pilot"));
		System.out.println("Runtime name for com.db4odoc.aliases.Pilot: "
				+ wAlias.resolveStoredName("com.db4odoc.aliases.Pilot"));
		return configuration;
	}
	// end configureAlias
}
