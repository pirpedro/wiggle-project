' Copyright (C) 2004 - 2007 Versant Inc. http://www.db4o.com 
Imports System
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config


'This example shows how to use the same db4o database between 
'Java and .NET application. Pilot objects are originally saved in Java,
'then they are read and modified in .NET application and read again 
'in Java
 
Namespace Aliases

    Class InterLanguageExample
        Private Const Db4oFileName As String = "reference.db4o"

        Public Shared Sub Main(ByVal args As String())
            GetObjects(ConfigureAlias())
        End Sub
        ' end Main

        Public Shared Function ConfigureAlias() As IEmbeddedConfiguration
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.Add(New JavaSupport())
            configuration.Common.AddAlias(New WildcardAlias("com.db4odoc.aliases.*", "Db4odoc.Aliases.*, Db4odoc"))
            Return configuration
        End Function
        ' end ConfigureAlias

        Public Shared Sub GetObjects(ByVal configuration As IEmbeddedConfiguration)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim result As IList(Of Pilot) = db.Query(Of Pilot)()
                Dim i As Integer
                For i = 0 To result.Count - 1
                    Dim p As Pilot = result(i)
                    p.PilotName = "Modified " + p.PilotName
                    db.Store(p)
                Next
                ListResult(result)
            Finally
                db.Close()
            End Try
        End Sub
        ' end GetObjects

        Public Shared Sub ListResult(ByVal result As IList(Of Pilot))
            Console.WriteLine(result.Count)
            For Each item As Object In result
                Console.WriteLine(item)
            Next
        End Sub
        ' end ListResult
    End Class
End Namespace