/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */

package com.db4odoc.JavaDotNetClientServer;

public class Car {
    private String model;
    private Pilot pilot;
    
    public Car(String model, Pilot pilot) {
        this.model=model;
        this.pilot=pilot;
    }

    public Pilot getPilot() {
        return pilot;
    }

    public String getModel() {
        return model;
    }

    public String toString() {
        return model+"["+pilot+"]";
    }
}
