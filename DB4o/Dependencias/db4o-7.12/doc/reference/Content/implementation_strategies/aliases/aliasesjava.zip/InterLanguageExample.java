/* Copyright (C) 2004 - 2009 Versant Inc. http://www.db4o.com */

package com.db4odoc.aliases;

import java.io.*;

import com.db4o.*;

/**
 * This example shows how to use the same db4o database between Java and .NET
 * application. Pilot objects are originally saved in Java, then they are read
 * and modified in .NET application and read again in Java
 * 
 */
public class InterLanguageExample {

	private static final String DB4O_FILE_NAME = "reference.db4o";

	public static void main(String[] args) {
		saveObjects();
		// use .NET version to retrieve and modify the objects
		// and read from Java again. Note, as the objects were set
		// originally in Java, you do not need to use alias.
		//readObjects();
	}

	// end main

	private static void saveObjects() {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);
		try {
			Pilot pilot = new Pilot("David Barrichello", 99);
			container.store(pilot);
			pilot = new Pilot("Michael Schumacher", 100);
			container.store(pilot);
		} finally {
			container.close();
		}
	}

	// end saveObjects

	private static void readObjects() {
		ObjectContainer container = Db4oEmbedded.openFile(Db4oEmbedded
				.newConfiguration(), DB4O_FILE_NAME);
		try {
			ObjectSet<Pilot> result = container.queryByExample(new Pilot(null, 0));
			listResult(result);
		} finally {
			container.close();
		}
	}

	// end readObjects

	private static <T>void listResult(ObjectSet<T> result) {
		System.out.println(result.size());
		while (result.hasNext()) {
			System.out.println(result.next());
		}
	}
	// end listResult
}
