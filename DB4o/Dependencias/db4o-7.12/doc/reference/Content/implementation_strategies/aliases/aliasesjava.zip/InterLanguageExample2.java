/* Copyright (C) 2004 - 2009 Versant Inc. http://www.db4o.com */
/**
 * This example shows how to use the same db4o database between 
 * Java and .NET application. Pilot objects are originally saved in .NET,
 * then they are read and modified in Java application and read again 
 * in .NET
 *
 */

package com.db4odoc.aliases;

import java.util.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.query.*;

public class InterLanguageExample2 {
	private static final String DB4O_FILE_NAME = "reference.db4o";
	
	public static void main(String[] args) {
		getObjects(configureAlias());
	}

	// end main

	private static EmbeddedConfiguration configureAlias() {
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		configuration.common().addAlias(new WildcardAlias(
				"Db4odoc.Aliases.*, Db4odoc",
				"com.db4odoc.aliases.*"));
		configuration.common().add(new DotnetSupport(false));		
		return configuration;
	}

	// end configureAlias

	private static void getObjects(EmbeddedConfiguration configuration) {
		ObjectContainer db = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
		try {
			List<Pilot> result = db.query(new Predicate<Pilot>() {
				public boolean match(Pilot pilot) {
					return true;
				}
			});
			for (int i = 0; i < result.size(); i++) {
				Pilot pilot = result.get(i);
				pilot.setName("Modified " + pilot.getName());
				db.store(pilot);
			}
			listResult(result);
		} finally {
			db.close();
		}
	}

	// end getObjects

	private static void listResult(List<Pilot> result) {
		System.out.println(result.size());
		for (int i = 0; i < result.size(); i++) {
			System.out.println(result.get(i));
		}
	}
	// end listResult


}
