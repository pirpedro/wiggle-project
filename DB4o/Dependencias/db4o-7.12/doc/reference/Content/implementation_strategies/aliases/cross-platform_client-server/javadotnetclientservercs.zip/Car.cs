﻿/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
using System;

namespace JavaDotnetClientServer
{
    class Car
    {
        private String model;
        private Pilot pilot;

        public Car(String carModel, Pilot carPilot)
        {
            this.model = carModel;
            this.pilot = carPilot;
        }

        public Pilot Pilot
        {
            get { return pilot; }
        }

        public string Model
        {
            get { return model; }
        }


        public override String ToString()
        {
            return Model + "[" + Pilot + "]";
        }
    }
}
