﻿' Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com 

Imports System
Imports System.Threading
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Messaging


Class StartServer
    Inherits ServerInfo
    Implements IMessageRecipient
    Private [stop] As Boolean = False

    ''' <summary>
    ''' starts a db4o server using the configuration from
    ''' ServerInfo.
    ''' </summary>
    Public Shared Sub Main(ByVal arguments As String())
        Dim server As StartServer = New StartServer()
        server.RunServer()
    End Sub
    ' end Main

    ''' <summary>
    ''' opens the IObjectServer, and waits forever until Close() is called
    ''' or a StopServer message is being received.
    ''' </summary>
    Public Sub RunServer()
        SyncLock Me
            ' Using the messaging functionality to redirect all
            ' messages to this.processMessage
            Dim configuration As IConfiguration = Db4oFactory.NewConfiguration()
            configuration.ClientServer().SetMessageRecipient(Me)

            Dim db4oServer As IObjectServer = Db4oFactory.OpenServer(configuration, FileName, Port)
            db4oServer.GrantAccess(User, Password)

            Try
                If Not [stop] Then
                    ' wait forever until Close will change stop variable
                    Monitor.Wait(Me)
                End If
            Catch e As Exception
                Console.WriteLine(e.ToString())
            End Try
            db4oServer.Close()
        End SyncLock
    End Sub
    ' end RunServer

    ''' <summary>
    ''' messaging callback
    ''' see com.db4o.messaging.MessageRecipient#ProcessMessage()
    ''' </summary>
    Public Sub ProcessMessage(ByVal context As IMessageContext, ByVal message As Object) Implements IMessageRecipient.ProcessMessage
        If TypeOf message Is StopServer Then
            Close()
        End If
    End Sub
    ' end ProcessMessage

    ''' <summary>
    ''' closes this server.
    ''' </summary>
    Public Sub Close()
        SyncLock Me
            [stop] = True
            Monitor.PulseAll(Me)
        End SyncLock
    End Sub
    ' end Close

End Class