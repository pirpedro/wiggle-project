﻿' Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com 

Imports System

Class Car
    Private model As String
    Private pilot As Pilot

    Public Sub New(ByVal carModel As String, ByVal carPilot As Pilot)
        Me.model = carModel
        Me.pilot = carPilot
    End Sub




    Public Overloads Overrides Function ToString() As String
        Return String.Format("{0} [{1}]", model, pilot)
    End Function
End Class