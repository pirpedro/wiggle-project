﻿' Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com 

Imports System
Imports System.Collections.Generic

Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.CS
Imports Db4objects.Db4o.CS.Config


Class Client
    Public Shared ReadOnly host As String = "localhost"
    Public Shared ReadOnly fileName As String = "reference.db4o"
    Public Shared ReadOnly port As Integer = &HDB40
    Public Shared ReadOnly user As String = "db4o"
    Public Shared ReadOnly password As String = "db4o"

    Public Shared Sub Main(ByVal args As String())
        Dim db As IObjectContainer = Db4oClientServer.OpenClient(GetConfig(), host, port, user, password)
        db.Store(New Car("Ferrari", New Pilot("Michael Schumacher")))
        db.Store(New Car("BMW", New Pilot("Rubens Barrichello")))
        db.Close()

        db = Db4oClientServer.OpenClient(GetConfig(), host, port, user, password)
        Dim cars As IList(Of Car) = db.Query(Of Car)()
        For Each car As Car In cars
            System.Console.WriteLine(car)
        Next
        db.Close()
    End Sub
    ' end Main

    Private Shared Function GetConfig() As IClientConfiguration
        Dim config As IClientConfiguration = Db4oClientServer.NewClientConfiguration()
        config.Common.AddAlias(New WildcardAlias("com.db4odoc.JavaDotNetClientServer.*", "JavaDotnetClientServer.*, JavaDotnetClientServer"))
        config.Common.Add(New JavaSupport())
        Return config
    End Function
    ' end GetConfig


End Class