/* Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com */
using System;
using System.Collections.Generic;

using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.CS;
using Db4objects.Db4o.CS.Config;


namespace JavaDotnetClientServer
{
    class Client
    {
        public static readonly string host = "localhost";
        public static readonly string fileName = "reference.db4o";
        public static readonly int port = 0xdb40;
        public static readonly string user = "db4o";
        public static readonly string password = "db4o";

        public static void Main(string[] args)
        {
            IObjectContainer db = Db4oClientServer.OpenClient(GetConfig(), host,
                port, user, password);
            db.Store(new Car("Ferrari", new Pilot("Michael Schumacher")));
            db.Store(new Car("BMW", new Pilot("Rubens Barrichello")));
            db.Close();

            db = Db4oClientServer.OpenClient(GetConfig(), host, port, user,
                    password);
            IList<Car> cars = db.Query<Car>();
            foreach (Car car in cars)
            {
                System.Console.WriteLine(car);
            }
            db.Close();
        }
        // end Main

        private static IClientConfiguration GetConfig()
        {
            IClientConfiguration config = Db4oClientServer.NewClientConfiguration();
            config.Common.AddAlias(new WildcardAlias("com.db4odoc.JavaDotNetClientServer.*", 
                "JavaDotnetClientServer.*, JavaDotnetClientServer"));
            config.Common.Add(new JavaSupport());
            return config;
        }
        // end GetConfig

    }
}


