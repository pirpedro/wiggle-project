/* Copyright (C) 2004 - 2009 Versant Inc. http://www.db4o.com */
using System;
using System.Collections.Generic;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;

/**
 * This example shows how to use the same db4o database between 
 * Java and .NET application. Pilot objects are originally saved in Java,
 * then they are read and modified in .NET application and read again 
 * in Java
 *
 */

namespace Db4odoc.Aliases
{
    internal class InterLanguageExample
    {
        private const string Db4oFileName = "reference.db4o";

        public static void Main(string[] args)
        {
            GetObjects(ConfigureAlias());
        }

        // end Main

        private static IEmbeddedConfiguration ConfigureAlias()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.AddAlias(new WildcardAlias("com.db4odoc.aliases.*", "Db4odoc.Aliases.*, Db4odoc"));
            configuration.Common.Add(new JavaSupport());
            return configuration;
        }

        // end ConfigureAlias

        private static void GetObjects(IEmbeddedConfiguration configuration)
        {
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                IList<Pilot> result = db.Query<Pilot>(delegate(Pilot pilot) { return pilot.Points%2 == 0; });
                for (int i = 0; i < result.Count; i++)
                {
                    Pilot pilot = result[i];
                    pilot.Name = "Modified " + pilot.Name;
                    db.Store(pilot);
                }
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }

        // end GetObjects

        private static void ListResult<T>(IList<T> result)
        {
            Console.WriteLine(result.Count);
            for (int i = 0; i < result.Count; i++)
            {
                Console.WriteLine(result[i]);
            }
        }

        // end ListResult

        private static void ListResult(IObjectSet result)
        {
            Console.WriteLine(result.Count);
            for (int i = 0; i < result.Count; i++)
            {
                Console.WriteLine(result[i]);
            }
        }

        // end ListResult
    }
}