package com.db4odoc.typehandler.translators;

public class TransientItem {
	int id;
	
	public TransientItem(int id){
		this.id = id;
	}
	
	public String toString(){
		return String.valueOf(id);
	}
}
