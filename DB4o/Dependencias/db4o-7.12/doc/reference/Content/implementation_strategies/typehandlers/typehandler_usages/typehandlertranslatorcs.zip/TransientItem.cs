using System;
using System.Collections.Generic;
using System.Text;

namespace Db4objects.Db4odoc.Typehandler.Translators
{

    public class TransientItem
    {
        int id;

        public TransientItem(int id)
        {
            this.id = id;
        }

        public override String ToString()
        {
            return id.ToString();
        }
    }

}
