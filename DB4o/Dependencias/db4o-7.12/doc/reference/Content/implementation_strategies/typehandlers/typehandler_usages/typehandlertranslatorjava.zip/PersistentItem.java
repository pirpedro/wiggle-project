package com.db4odoc.typehandler.translators;

public class PersistentItem {
	String id;
	TransientItem item;
	
	public PersistentItem (String id, TransientItem item){
		this.id = id;
		this.item = item;
	}
	
	public String toString(){
		return id + ": " + item.toString();
	}
}
