/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
package com.db4odoc.typehandler.translators;

import java.io.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.query.*;
import com.db4o.reflect.*;
import com.db4o.reflect.generic.*;
import com.db4o.reflect.jdk.*;
import com.db4o.typehandlers.*;

public class TranslatorExample {
	private final static String DB4O_FILE_NAME = "reference.db4o";

	public static void main(String[] args) {
		//tryStoreWithoutCallConstructors();
		//tryStoreWithCallConstructors();
		storeWithTypehandler();
		ignoreFieldsTypehandlerExample();
	}

	// end main

	private static void tryStoreWithoutCallConstructors() {
		Configuration configuration = Db4o.newConfiguration();
		configuration.exceptionsOnNotStorable(false);
		configuration.objectClass(NotStorable.class)
				.callConstructor(false);
		tryStoreAndRetrieve(configuration);
	}

	// end tryStoreWithoutCallConstructors

	private static void tryStoreWithCallConstructors() {
		Configuration configuration = Db4o.newConfiguration();
		configuration.exceptionsOnNotStorable(true);
		configuration.objectClass(NotStorable.class)
				.callConstructor(true);
		tryStoreAndRetrieve(configuration);
	}

	// end tryStoreWithCallConstructors

	private static void storeWithTypehandler() {
		Configuration configuration = Db4o.newConfiguration();
		// add a custom typehandler support
        TypeHandlerPredicate predicate = new TypeHandlerPredicate() {
            public boolean match(ReflectClass classReflector) {
            	GenericReflector reflector = new GenericReflector(
            			null, new JdkReflector(Thread.currentThread().getContextClassLoader()));
    			ReflectClass claxx = reflector.forName(NotStorable.class.getName()); 
    			boolean res = claxx.equals(classReflector);  
                return res;
            }
        };
        
        configuration.registerTypeHandler(predicate, new NotStorableTypehandler());
        tryStoreAndRetrieve(configuration);
	}

	// end storeWithTypehandler

	private static void tryStoreAndRetrieve(Configuration configuration) {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4o.openFile(configuration, DB4O_FILE_NAME);
		try {
			NotStorable notStorable = new NotStorable(42, "Test");
			System.out.println("ORIGINAL: " + notStorable);
			container.store(notStorable);
		} catch (Exception exc) {
			System.out.println(exc.toString());
			return;
		} finally {
			container.close();
		}
		container = Db4o.openFile(configuration, DB4O_FILE_NAME);
		try {
			ObjectSet result = container.queryByExample(NotStorable.class);
			while (result.hasNext()) {
				NotStorable notStorable = (NotStorable) result.next();
				System.out.println("RETRIEVED: " + notStorable);
			}
		} finally {
			container.close();
		}
	}
	// end tryStoreAndRetrieve
	
	private static Configuration ignoreFieldsConfiguration() {
		Configuration configuration = Db4o.newConfiguration();
		// add a custom typehandler support
        TypeHandlerPredicate predicate = new TypeHandlerPredicate() {
            public boolean match(ReflectClass classReflector) {
            	GenericReflector reflector = new GenericReflector(
            			null, new JdkReflector(Thread.currentThread().getContextClassLoader()));
    			ReflectClass claxx = reflector.forName(TransientItem.class.getName()); 
    			boolean res = claxx.equals(classReflector);  
                return res;
            }
        };
        
        configuration.registerTypeHandler(predicate, new IgnoreFieldsTypeHandler());
        return configuration; 
	}

	// end ignoreFieldsConfiguration
	
	private static void ignoreFieldsTypehandlerExample() {
		new File(DB4O_FILE_NAME).delete();
		Configuration configuration = ignoreFieldsConfiguration();
		ObjectContainer container = Db4o.openFile(configuration, DB4O_FILE_NAME);
		try {
			PersistentItem persistentItem = new PersistentItem("1", new TransientItem(11));
			System.out.println("ORIGINAL: " + persistentItem);
			container.store(persistentItem);
		} catch (Exception exc) {
			System.out.println(exc.toString());
			return;
		} finally {
			container.close();
		}
		container = Db4o.openFile(configuration, DB4O_FILE_NAME);
		try {
			Query query = container.query();
			query.constrain(PersistentItem.class);
			ObjectSet result = query.execute();
			while (result.hasNext()) {
				PersistentItem persistentItem = (PersistentItem) result.next();
				System.out.println("RETRIEVED: " + persistentItem);
			}
		} finally {
			container.close();
		}
	}
	// end ignoreFieldsTypehandlerExample
}