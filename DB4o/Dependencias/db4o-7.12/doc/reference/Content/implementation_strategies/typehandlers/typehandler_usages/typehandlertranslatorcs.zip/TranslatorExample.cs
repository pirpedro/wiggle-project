﻿/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System;
using System.IO;
using System.Globalization;

using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Internal;
using Db4objects.Db4o.Query;
using Db4objects.Db4o.Reflect;
using Db4objects.Db4o.Reflect.Generic;
using Db4objects.Db4o.Reflect.Net;
using Db4objects.Db4o.Typehandlers;
using Db4oTool.Core;
using Sharpen.Lang;

namespace Db4objects.Db4odoc.Typehandler.Translators
{
    public class TranslatorExample
    {
        private const string Db4oFileName = "reference.db4o";

        public static void Main(String[] args)
        {
            StoreWithTypehandler();
            IgnoreFieldsTypehandlerExample();
        }

        // end Main

        private sealed class _TypeHandlerPredicate : ITypeHandlerPredicate
        {
            public bool Match(IReflectClass classReflector)
            {
                GenericReflector reflector = new GenericReflector(null, Platform4.ReflectorForType
                (typeof(TranslatorExample)));
                IReflectClass claxx = reflector.ForClass(typeof(LocalizedItemList));
                bool res = claxx.Equals(classReflector);
                return res;
            }
        }
        // end _TypeHandlerPredicate

        private static void StoreWithTypehandler()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            // add a custom typehandler support
            ITypeHandlerPredicate predicate = new _TypeHandlerPredicate();

            configuration.RegisterTypeHandler(predicate, new CultureInfoTypehandler());
            TryStoreAndRetrieve(configuration);
        }

        // end StoreWithTypehandler

        private static void TryStoreAndRetrieve(IConfiguration configuration)
        {
            File.Delete(Db4oFileName);
            IObjectContainer container = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
            {
                LocalizedItemList list = new LocalizedItemList(CultureInfo.CurrentCulture, new string[] { "test1", "test2" });
                System.Console.WriteLine("ORIGINAL: " + list);
                container.Store(list);
            }
            catch (Exception exc)
            {
                System.Console.WriteLine(exc.ToString());
                return;
            }
            finally
            {
                container.Close();
            }
            container = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
            {
                IObjectSet result = container.QueryByExample(typeof(LocalizedItemList));
                while (result.HasNext())
                {
                    LocalizedItemList list = (LocalizedItemList)result.Next();
                    System.Console.WriteLine("RETRIEVED: " + list);
                }
            }
            finally
            {
                container.Close();
            }
        }
        // end TryStoreAndRetrieve

        private sealed class TransientHandlerPredicate : ITypeHandlerPredicate
        {
            public bool Match(IReflectClass classReflector)
            {
                GenericReflector reflector = new GenericReflector(null, Platform4.ReflectorForType
                (typeof(TranslatorExample)));
                IReflectClass claxx = reflector.ForClass(typeof(TransientItem));
                bool res = claxx.Equals(classReflector);
                return res;
            }
        }

        private static IConfiguration IgnoreFieldsConfiguration()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            // add a custom typehandler support
            ITypeHandlerPredicate predicate = new TransientHandlerPredicate();

            configuration.RegisterTypeHandler(predicate, new IgnoreFieldsTypeHandler());
            return configuration;
        }

        // end ignoreFieldsConfiguration

        private static void IgnoreFieldsTypehandlerExample()
        {
            File.Delete(Db4oFileName);
            IConfiguration configuration = IgnoreFieldsConfiguration();
            IObjectContainer container = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
            {
                PersistentItem persistentItem = new PersistentItem("1", new TransientItem(11));
                System.Console.WriteLine("ORIGINAL: " + persistentItem);
                container.Store(persistentItem);
            }
            catch (Exception exc)
            {
                System.Console.WriteLine(exc.ToString());
                return;
            }
            finally
            {
                container.Close();
            }
            container = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
            {
                IQuery query = container.Query();
                query.Constrain(typeof(PersistentItem));
                IObjectSet result = query.Execute();
                while (result.HasNext())
                {
                    PersistentItem persistentItem = (PersistentItem)result.Next();
                    System.Console.WriteLine("RETRIEVED: " + persistentItem);
                }
            }
            finally
            {
                container.Close();
            }
        }
        // end IgnoreFieldsTypehandlerExample
    }
}