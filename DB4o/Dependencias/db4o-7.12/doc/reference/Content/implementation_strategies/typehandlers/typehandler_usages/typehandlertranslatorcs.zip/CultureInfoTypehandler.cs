/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System.Globalization;

using Db4objects.Db4o.Internal.Handlers;
using Db4objects.Db4o.Internal.Marshall;
using Db4objects.Db4o.Marshall;
using Db4objects.Db4o.Typehandlers;


namespace Db4objects.Db4odoc.Typehandler.Translators
{
    public class CultureInfoTypehandler : FirstClassObjectHandler, ITypeHandler4, IFirstClassHandler, IVariableLengthTypeHandler
    {
        private class Storable
        {
            private string[] items;

            public Storable(string[] items)
            {
                this.Items = items;
            }

            public string[] Items
            {
                get { return items; }
                set { items = value; }
            }
        }

        public void Write(IWriteContext context, object obj)
        {
            LocalizedItemList list = (LocalizedItemList)obj;
            Storable storable = new Storable(list.Items);

            context.WriteObject(storable);
        }

        public object Read(IReadContext context)
        {
            UnmarshallingContext _context = (UnmarshallingContext)context;
            LocalizedItemList list = (LocalizedItemList) _context.PersistentObject();
            Storable storable = (Storable)context.ReadObject();
            list = new LocalizedItemList(CultureInfo.CurrentCulture, storable.Items);
            return list;
        }

    }
}