/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System;
using System.IO;

using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Config.Encoding;

namespace Db4objects.Db4odoc.StringEncoding
{
    public class StringEncoderExample
    {
        private static readonly string Db4oFileName = "reference.db4o";

        public static void Main(string[] args)
        {
            File.Delete(Db4oFileName);
            IConfiguration config = Configure();
            IObjectContainer container = Db4oFactory.OpenFile(config, Db4oFileName);
            container.Store(new Item("test"));
            container.Close();

            container = Db4oFactory.OpenFile(config, Db4oFileName);
            IObjectSet result = container.QueryByExample(new Item("test"));
            foreach (Item item in result)
            {
                System.Console.WriteLine(item);
            }
            container.Close();
        }
        // end Main

        private class StringEncodingEncrypted : IStringEncoding
        {
            public byte[] Encode(string str)
            {
                str = Encryption.Encrypt(str);
                int length = str.Length;
                char[] chars = new char[length];
                chars = str.ToCharArray(0, length);
                byte[] bytes = new byte[length * 2];
                int count = 0;
                for (int i = 0; i < length; i++)
                {
                    bytes[count++] = (byte)(chars[i] & 0xff);
                    bytes[count++] = (byte)(chars[i] >> 8);
                }
                return bytes;
            }

            public String Decode(byte[] bytes, int start, int length)
            {
                int stringLength = length / 2;
                char[] chars = new char[stringLength];
                int j = start;
                for (int ii = 0; ii < stringLength; ii++)
                {
                    chars[ii] = (char)((bytes[j++] & 0xff) | ((bytes[j++] & 0xff) << 8));
                    //j+=2;
                }
                return Encryption.Decrypt(new String(chars, 0, stringLength));
            }
        }
        // end StringEncodingEncrypted

        protected static IConfiguration Configure()
        {
            IConfiguration config = Db4oFactory.NewConfiguration();
            config.StringEncoding(new StringEncodingEncrypted());
            return config;
        }
        // end Configure

        private static class Encryption
        {

            public static string Encrypt(string s)
            {
                char[] array = s.ToCharArray();
                for (int i = 0; i < array.Length; i++)
                {
                    array[i]++;
                }
                return new String(array);
            }

            public static String Decrypt(String s)
            {
                char[] array = s.ToCharArray();
                for (int i = 0; i < array.Length; i++)
                {
                    array[i]--;
                }
                return new String(array);
            }
        }
        // end Encryption
    }
}
