/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System;

namespace Db4objects.Db4odoc.StringEncoding
{
    class Item
    {
        private String id;

        public Item(string id)
        {
            this.id = id;
        }

        public override string ToString()
        {
            return id;
        }
    }
}
