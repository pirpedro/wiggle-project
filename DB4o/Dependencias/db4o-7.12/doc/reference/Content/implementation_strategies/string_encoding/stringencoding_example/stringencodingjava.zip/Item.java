package com.db4odoc.stringencoding;

public class Item {
	String id;
	
	public Item(String id){
		this.id = id;
	}
	
	public String toString(){
		return id;
	}
	
}
