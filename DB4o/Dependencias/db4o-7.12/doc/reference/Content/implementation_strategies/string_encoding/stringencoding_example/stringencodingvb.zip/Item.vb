' Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com 

Imports System

Namespace Db4objects.Db4odoc.StringEncoding
    Class Item
        Private id As String

        Public Sub New(ByVal id As String)
            Me.id = id
        End Sub

        Public Overloads Overrides Function ToString() As String
            Return id
        End Function
    End Class
End Namespace
