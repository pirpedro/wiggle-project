' Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com 

Imports System
Imports System.IO

Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Config.Encoding

Namespace Db4objects.Db4odoc.StringEncoding
    Public Class StringEncoderExample
        Private Shared ReadOnly Db4oFileName As String = "reference.db4o"

        Public Shared Sub Main(ByVal args As String())
            File.Delete(Db4oFileName)
            Dim config As IConfiguration = Configure()
            Dim container As IObjectContainer = Db4oFactory.OpenFile(config, Db4oFileName)
            container.Store(New Item("test"))
            container.Close()

            container = Db4oFactory.OpenFile(config, Db4oFileName)
            Dim result As IObjectSet = container.QueryByExample(New Item("test"))
            For Each item As Item In result
                System.Console.WriteLine(item)
            Next
            container.Close()
        End Sub
        ' end Main

        Private Class StringEncodingEncrypted
            Implements IStringEncoding

            Public Function Encode(ByVal str As String) As Byte() Implements IStringEncoding.Encode
                str = Encryption.Encrypt(str)
                Dim length As Integer = str.Length
                Dim chars As Char() = New Char(length) {}
                chars = str.ToCharArray(0, length)
                Dim bytes As Byte() = New Byte(length * 2 - 1) {}
                Dim count As Integer = 0
                For i As Integer = 0 To length - 1
                    bytes(count) = CByte(Microsoft.VisualBasic.AscW(chars(i)) And &HFF)
                    count = count + 1
                    bytes(count) = CByte(Microsoft.VisualBasic.AscW(chars(i)) >> 8)
                    count = count + 1
                Next
                Return bytes
            End Function

            Public Function Decode(ByVal bytes As Byte(), ByVal start As Integer, ByVal length As Integer) As String Implements IStringEncoding.Decode
                Dim stringLength As Integer = length / 2
                Dim chars As Char() = New Char(stringLength) {}
                Dim j As Integer = start
                For ii As Integer = 0 To stringLength - 1
                    chars(ii) = Microsoft.VisualBasic.ChrW(((bytes(j) And &HFF) Or ((bytes(j + 1) And &HFF) << 8)))
                    j = j + 2
                Next
                Return Encryption.Decrypt(New String(chars, 0, stringLength))
            End Function
        End Class
        ' end StringEncodingEncrypted

        Protected Shared Function Configure() As IConfiguration
            Dim config As IConfiguration = Db4oFactory.NewConfiguration()
            config.StringEncoding(New StringEncodingEncrypted())
            Return config
        End Function
        ' end Configure

        Private Class Encryption

            Public Shared Function Encrypt(ByVal s As String) As String
                Dim array As Char() = s.ToCharArray()
                For i As Integer = 0 To array.Length - 1
                    array(i) = Microsoft.VisualBasic.ChrW(Microsoft.VisualBasic.AscW(array(i)) + 1)
                Next
                Return New String(array)
            End Function

            Public Shared Function Decrypt(ByVal s As String) As String
                Dim array As Char() = s.ToCharArray()
                For i As Integer = 0 To array.Length - 1
                    array(i) = Microsoft.VisualBasic.ChrW(Microsoft.VisualBasic.AscW(array(i)) - 1)
                Next
                Return New String(array)
            End Function
        End Class
        ' end Encryption

    End Class

End Namespace
