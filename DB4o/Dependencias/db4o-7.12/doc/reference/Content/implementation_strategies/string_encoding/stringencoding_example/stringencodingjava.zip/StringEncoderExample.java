package com.db4odoc.stringencoding;

import java.io.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.config.encoding.*;

public class StringEncoderExample {

	private static final String DB4O_FILE_NAME = "reference.db4o";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new File(DB4O_FILE_NAME).delete();
		Configuration config = configure();
		ObjectContainer container = Db4o.openFile(config, DB4O_FILE_NAME);
		container.store(new Item("test"));
		container.close();
		
		container = Db4o.openFile(config, DB4O_FILE_NAME);
		ObjectSet result = container.queryByExample(new Item("test"));
		while (result.hasNext()){
			System.out.println(result.next());
		}
			
		container.close();
	}
	// end main

	protected static Configuration configure() {
		Configuration config = Db4o.newConfiguration();
		config.stringEncoding(new StringEncoding() {
			public byte[] encode(String str) {
				str = Encryption.encrypt(str);
				int length = str.length();
			    char[] chars = new char[length];
			    str.getChars(0, length, chars, 0);
			    byte[] bytes = new byte[length * 2];
			    int count = 0;
			    for (int i = 0; i < length; i ++){
			    	bytes[count++] = (byte) (chars[i] & 0xff);
			    	bytes[count++] = (byte) (chars[i] >> 8);
				}
				return bytes;
			}
		
			public String decode(byte[] bytes, int start, int length) {
			    int stringLength =  length / 2;
			    char[] chars = new char[stringLength];
			    int j = start;
			    for(int ii = 0; ii < stringLength; ii++){
			        chars[ii] = (char)((bytes[j++]& 0xff) | ((bytes[j++]& 0xff) << 8));
			        //j+=2;
			    }
			    return Encryption.decrypt(new String(chars,0,stringLength));
			}
	
		});
		return config;
	}
	// end configure

	private static class Encryption {

		public static String encrypt(String s)
		{
			char[] array = s.toCharArray();
			for (int i = 0; i < array.length; i++)
			{
				array[i]++;
			}
			return new String(array);
		}

		public static String decrypt(String s) {
			char[] array = s.toCharArray();
			for (int i = 0; i < array.length; i++)
			{
				array[i]--;
			}
			return new String(array);
		}
	}
	// end Encryption
}
