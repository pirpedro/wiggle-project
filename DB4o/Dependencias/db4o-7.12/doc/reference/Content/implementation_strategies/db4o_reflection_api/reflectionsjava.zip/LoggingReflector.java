/* Copyright (C) 2004   db4objects Inc.   http://www.db4o.com */

package com.db4odoc.reflections;

import com.db4o.internal.Platform4;
import com.db4o.reflect.ReflectArray;
import com.db4o.reflect.ReflectClass;
import com.db4o.reflect.Reflector;
import com.db4o.reflect.ReflectorConfiguration;
import com.db4o.reflect.jdk.ClassLoaderJdkLoader;
import com.db4o.reflect.jdk.JavaReflectClass;
import com.db4o.reflect.jdk.JdkClass;
import com.db4o.reflect.jdk.JdkLoader;
import com.db4o.reflect.jdk.JdkReflector;

/**
 * db4o wrapper for JDK reflector functionality
 * 
 * @see com.db4o.ext.ExtObjectContainer#reflector()
 * @see com.db4o.reflect.generic.GenericReflector
 * 
 * @sharpen.ignore
 */
public class LoggingReflector implements Reflector {

	private final JdkLoader _classLoader;
	protected Reflector _parent;
	private ReflectArray _array;
	private ReflectorConfiguration _config;

	/**
	 * Constructor
	 * 
	 * @param classLoader
	 *            class loader
	 */
	public LoggingReflector(ClassLoader classLoader) {
		this(new ClassLoaderJdkLoader(classLoader));
	}

	/**
	 * Constructor
	 * 
	 * @param classLoader
	 *            class loader
	 */
	public LoggingReflector(JdkLoader classLoader) {
		this(classLoader, null);
	}

	private LoggingReflector(JdkLoader classLoader,
			ReflectorConfiguration config) {
		_classLoader = classLoader;
		_config = config;
	}

	/**
	 * ReflectArray factory
	 * 
	 * @return ReflectArray instance
	 */
	public ReflectArray array() {
		if (_array == null) {
			_array = new LoggingArray(parent());
		}
		return _array;
	}

	/**
	 * Creates a copy of the object
	 * 
	 * @param obj
	 *            object to copy
	 * @return object copy
	 */
	public Object deepClone(Object obj) {
		return new LoggingReflector(_classLoader, _config);
	}

	/**
	 * Returns ReflectClass for the specified class
	 * 
	 * @param clazz
	 *            class
	 * @return ReflectClass for the specified class
	 */
	public ReflectClass forClass(Class clazz) {
		ReflectClass rc = createClass(clazz);
		System.out.println("forClass: " + clazz + " -> "
				+ (rc == null ? "" : rc.getName()));

		return rc;
	}

	/**
	 * Returns ReflectClass for the specified class name
	 * 
	 * @param className
	 *            class name
	 * @return ReflectClass for the specified class name
	 */
	public ReflectClass forName(String className) {
		Class clazz = _classLoader.loadClass(className);
		ReflectClass rc = createClass(clazz);
		System.out.println("forName: " + className + " -> "
				+ (rc == null ? "" : rc.getName()));
		return rc;

	}

	/**
	 * creates a Class reflector when passed a class. This method is protected
	 * to allow overriding in cusom reflectors that override JdkReflector.
	 * 
	 * @param clazz
	 *            the class
	 * @return the class reflector
	 */
	protected JdkClass createClass(Class clazz) {
		if (clazz == null) {
			return null;
		}
		JdkReflector jdkReflector = new JdkReflector(this.getClass()
				.getClassLoader());
		jdkReflector.configuration(_config);

		JdkClass rc = new JdkClass(parent(), jdkReflector, clazz);
		return rc;
	}

	/**
	 * Returns ReflectClass for the specified class object
	 * 
	 * @param a_object
	 *            class object
	 * @return ReflectClass for the specified class object
	 */
	public ReflectClass forObject(Object a_object) {
		if (a_object == null) {
			return null;
		}
		ReflectClass rc = parent().forClass(a_object.getClass());
		System.out.println("forObject:" + a_object + " -> "
				+ (rc == null ? "" : rc.getName()));
		return rc;
	}

	/**
	 * Method stub. Returns false.
	 */
	public boolean isCollection(ReflectClass candidate) {
		return false;
	}

	/**
	 * Method stub. Returns false.
	 */
	public boolean methodCallsSupported() {
		return true;
	}

	/**
	 * Sets parent reflector
	 * 
	 * @param reflector
	 *            parent reflector
	 */
	public void setParent(Reflector reflector) {
		_parent = reflector;
	}

	/**
	 * Creates ReflectClass[] array from the Class[] array using the reflector
	 * specified
	 * 
	 * @param reflector
	 *            reflector to use
	 * @param clazz
	 *            class
	 * @return ReflectClass[] array
	 */
	public static ReflectClass[] toMeta(Reflector reflector, Class[] clazz) {
		ReflectClass[] claxx = null;
		if (clazz != null) {
			claxx = new ReflectClass[clazz.length];
			for (int i = 0; i < clazz.length; i++) {
				if (clazz[i] != null) {
					claxx[i] = reflector.forClass(clazz[i]);
				}
			}
		}
		return claxx;
	}

	/**
	 * Creates Class[] array from the ReflectClass[] array
	 * 
	 * @param claxx
	 *            ReflectClass array
	 * @return Class[] array
	 */
	static Class[] toNative(ReflectClass[] claxx) {
		Class[] clazz = null;
		if (claxx != null) {
			clazz = new Class[claxx.length];
			for (int i = 0; i < claxx.length; i++) {
				clazz[i] = toNative(claxx[i]);
			}
		}
		return clazz;
	}

	/**
	 * Translates a ReflectClass into a native Class
	 * 
	 * @param claxx
	 *            ReflectClass to translate
	 * @return Class
	 */
	public static Class toNative(ReflectClass claxx) {
		if (claxx == null) {
			return null;
		}
		System.out.println("toNative: " + claxx.getName());
		if (claxx instanceof JavaReflectClass) {
			return ((JavaReflectClass) claxx).getJavaClass();
		}
		ReflectClass d = claxx.getDelegate();
		if (d == claxx) {
			return null;
		}
		return toNative(d);
	}

	public void configuration(ReflectorConfiguration config) {
		_config = config;
	}

	public ReflectorConfiguration configuration() {
		return _config;
	}

	Object nullValue(ReflectClass clazz) {
		return Platform4.nullValue(toNative(clazz));
	}

	private Reflector parent() {
		if (_parent == null) {
			return this;
		}
		return _parent;
	}

}
