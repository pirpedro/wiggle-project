/* Copyright (C) 2007   db4objects Inc.   http://www.db4o.com */
using System;

using Db4objects.Db4o.Internal;
using Db4objects.Db4o.Reflect;
using Db4objects.Db4o.Reflect.Net;

namespace Db4objects.Db4odoc.Reflections
{
    public class LoggingReflector : Db4objects.Db4o.Reflect.IReflector
    {
        protected Db4objects.Db4o.Reflect.IReflector _parent;

        private Db4objects.Db4o.Reflect.IReflectArray _array;

        private Db4objects.Db4o.Reflect.IReflectorConfiguration _config;

        public virtual Db4objects.Db4o.Reflect.IReflectArray Array()
        {
            if (_array == null)
            {
                _array = new Db4objects.Db4o.Reflect.Net.NetArray(Parent());
            }
            return _array;
        }

        public virtual object DeepClone(object obj)
        {
            return new NetReflector();
        }

        public virtual Db4objects.Db4o.Reflect.IReflectClass ForClass(System.Type forType)
        {
            Db4objects.Db4o.Reflect.IReflectClass rc = null;
            System.Type underlyingType = GetUnderlyingType(forType);
            if (underlyingType.IsPrimitive && !Db4objects.Db4o.Internal.NullableArrayHandling.UseOldNetHandling())
            {
                rc = CreateClass(forType);
            }
            rc = CreateClass(underlyingType);
            Console.WriteLine("ForClass: " + forType + " -> " + (rc == null ? "" : rc.GetName()));
            return rc;
        }

        protected virtual Db4objects.Db4o.Reflect.IReflectClass CreateClass(Type type)
        {
            if (type == null)
            {
                return null;
            }
            NetReflector netReflector = new NetReflector();
            netReflector.Configuration(_config);
            return new Db4objects.Db4o.Reflect.Net.NetClass(Parent(), netReflector, type);
        }

        private static Type GetUnderlyingType(Type type)
        {
            if (type == null)
            {
                return null;
            }
            Type underlyingType = Nullable.GetUnderlyingType(type);
            if (underlyingType != null)
            {
                return underlyingType;
            }
            return type;
        }

        public virtual Db4objects.Db4o.Reflect.IReflectClass ForName(string className)
        {
            Db4objects.Db4o.Reflect.IReflectClass rc = null; 
            try
            {
                Type type = ReflectPlatform.ForName(className);
                if (type == null) return null;
                rc = ForClass(type);
                Console.WriteLine("ForName: " + className + " -> " + (rc == null ? "" : rc.GetName()));
            }
            catch
            {
            }
            return rc;
        }

        public virtual Db4objects.Db4o.Reflect.IReflectClass ForObject(object a_object)
        {
            if (a_object == null)
            {
                return null;
            }
            Db4objects.Db4o.Reflect.IReflectClass rc = Parent().ForClass(a_object.GetType());
            Console.WriteLine("ForObject:" + a_object + " -> " + (rc == null ? "" : rc.GetName()));
            return rc;
        }

        public virtual bool IsCollection(Db4objects.Db4o.Reflect.IReflectClass candidate)
        {
            bool result = false;
            if (candidate.IsArray())
            {
                result = false;
            }
            NetClass netClass = candidate as NetClass;
            if (null == netClass)
            {
                result = false;
            }
            result = typeof(System.Collections.ICollection).IsAssignableFrom(netClass.GetNetType());
            Console.WriteLine("Type " + candidate.GetName() + " is Collection " + result);
            return result;
        }

        public virtual bool MethodCallsSupported()
        {
            return true;
        }

        public static Db4objects.Db4o.Reflect.IReflectClass[] ToMeta(
            Db4objects.Db4o.Reflect.IReflector reflector,
            System.Type[] clazz)
        {
            Db4objects.Db4o.Reflect.IReflectClass[] claxx = null;
            if (clazz != null)
            {
                claxx = new Db4objects.Db4o.Reflect.IReflectClass[clazz.Length];
                for (int i = 0; i < clazz.Length; i++)
                {
                    if (clazz[i] != null)
                    {
                        claxx[i] = reflector.ForClass(clazz[i]);
                    }
                }
            }
            return claxx;
        }

        public static System.Type[] ToNative(Db4objects.Db4o.Reflect.IReflectClass[] claxx)
        {
            System.Type[] clazz = null;
            if (claxx != null)
            {
                clazz = new System.Type[claxx.Length];
                for (int i = 0; i < claxx.Length; i++)
                {
                    if (claxx[i] != null)
                    {
                        IReflectClass reflectClass = claxx[i];
                        System.Console.WriteLine("ToNative: " + reflectClass.ToString());
                        clazz[i] = ToNative(reflectClass);
                    }
                }
            }
            return clazz;
        }

        public static Type ToNative(IReflectClass reflectClass)
        {
            System.Console.WriteLine("ToNative: " + reflectClass.ToString());
            return ((Db4objects.Db4o.Reflect.Net.NetClass)reflectClass.GetDelegate()).GetNetType();
        }

        public virtual void SetParent(IReflector reflector)
        {
            _parent = reflector;
        }

        public virtual void Configuration(Db4objects.Db4o.Reflect.IReflectorConfiguration config)
        {
            _config = config;
        }

        public virtual Db4objects.Db4o.Reflect.IReflectorConfiguration Configuration()
        {
            return _config;
        }

        public virtual object NullValue(IReflectClass clazz)
        {
            return Platform4.NullValue(ToNative(clazz));
        }

        private IReflector Parent()
        {
            if (_parent == null)
            {
                return this;
            }

            return _parent;
        }

    }
}
