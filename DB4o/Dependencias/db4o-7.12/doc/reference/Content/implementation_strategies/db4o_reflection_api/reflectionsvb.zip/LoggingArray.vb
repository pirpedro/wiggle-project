' Copyright (C) 2005   db4objects Inc.   http://www.db4o.com 

Imports System
Imports Db4objects.Db4o.Reflect
Imports Db4objects.Db4o.Reflect.Net

Namespace Db4objects.Db4odoc.Reflections
    Public Class LoggingArray
        Inherits Db4objects.Db4o.Reflect.Core.AbstractReflectArray
        Public Sub New(ByVal reflector As IReflector)
            MyBase.New(reflector)
        End Sub

        Private Shared Function GetNetType(ByVal clazz As IReflectClass) As Type
            Return DirectCast(clazz, NetClass).GetNetType()
        End Function

        Public Overloads Overrides Sub Analyze(ByVal obj As Object, ByVal info As ArrayInfo)
            info.Nullable(IsNullableType(obj.[GetType]()))
        End Sub

        Private Function IsNullableType(ByVal type As Type) As Boolean
            If type.IsArray Then
                Return IsNullableType(type.GetElementType())
            End If

            Dim underlyingType As Type = Nullable.GetUnderlyingType(type)
            Return underlyingType IsNot Nothing
        End Function

        Public Overloads Overrides Function NewInstance(ByVal componentType As IReflectClass, ByVal info As ArrayInfo) As Object
            Dim type As Type = GetNetType(componentType)
            If info.Nullable() Then
                type = NullableType(type)
            End If
            Dim multiDimensionalInfo As MultidimensionalArrayInfo = TryCast(info, MultidimensionalArrayInfo)
            If multiDimensionalInfo Is Nothing Then
                Return System.Array.CreateInstance(type, info.ElementCount())
            End If
            Dim dimensions As Integer() = multiDimensionalInfo.Dimensions()
            If dimensions.Length = 1 Then
                Return UnfoldArrayCreation(type, dimensions, 0)
            End If
            Return UnfoldArrayCreation(GetArrayType(type, dimensions.Length - 1), dimensions, 0)
        End Function

        Private Function NullableType(ByVal type As Type) As Type
            Return GetType(Nullable(Of )).MakeGenericType(New Type() {type})
        End Function

        Public Overloads Overrides Function NewInstance(ByVal componentType As IReflectClass, ByVal dimensions As Integer()) As Object
            Dim type As Type = GetNetType(componentType)
            If dimensions.Length = 1 Then
                Return UnfoldArrayCreation(type, dimensions, 0)
            End If

            Return UnfoldArrayCreation(GetArrayType(type, dimensions.Length - 1), dimensions, 0)
        End Function

        Private Shared Function UnfoldArrayCreation(ByVal type As Type, ByVal dimensions As Integer(), ByVal dimensionIndex As Integer) As Object
            Dim length As Integer = dimensions(dimensionIndex)
            Dim array As Array = Array.CreateInstance(type, length)
            If dimensionIndex = dimensions.Length - 1 Then
                Return array
            End If
            For i As Integer = 0 To length - 1
                Dim value As Object = UnfoldArrayCreation(type.GetElementType(), dimensions, dimensionIndex + 1)
                array.SetValue(value, i)
            Next
            Return array
        End Function

        Private Shared Function GetArrayType(ByVal type As Type, ByVal dimensions As Integer) As System.Type
            If dimensions < 1 Then
                Throw New ArgumentOutOfRangeException("dimensions")
            End If

            Dim arrayType As Type = MakeArrayType(type)
            For i As Integer = 1 To dimensions - 1
                arrayType = MakeArrayType(arrayType)
            Next
            Return arrayType
        End Function

        Private Shared Function MakeArrayType(ByVal type As Type) As Type
            Return Sharpen.Lang.ArrayTypeReference.MakeArrayType(type, 1)
        End Function

        Public Overloads Overrides Function NewInstance(ByVal componentType As IReflectClass, ByVal length As Integer) As Object
            Return System.Array.CreateInstance(GetNetType(componentType), length)
        End Function
    End Class
End Namespace

