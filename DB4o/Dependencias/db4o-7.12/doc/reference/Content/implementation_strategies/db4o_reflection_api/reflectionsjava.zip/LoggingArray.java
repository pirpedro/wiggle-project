/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.reflections;

import java.lang.reflect.Array;

import com.db4o.reflect.ArrayInfo;
import com.db4o.reflect.MultidimensionalArrayInfo;
import com.db4o.reflect.ReflectClass;
import com.db4o.reflect.Reflector;
import com.db4o.reflect.core.AbstractReflectArray;
import com.db4o.reflect.jdk.JdkReflector;

/**
 * @sharpen.ignore
 */
public class LoggingArray extends AbstractReflectArray {

	LoggingArray(Reflector reflector){
        super(reflector);
    }
    
    public void analyze(Object obj, ArrayInfo info) {
        // do nothing
        // possible further processing here:  
        // Analyze component type, length, dimensions, primitive ... 
    }
    
    public Object newInstance(ReflectClass componentType, int length) {
        return Array.newInstance(JdkReflector.toNative(componentType), length);
    }

    public Object newInstance(ReflectClass componentType, int[] dimensions) {
        Class native1 = JdkReflector.toNative(componentType);
        return Array.newInstance(native1, dimensions);
    }

    public Object newInstance(ReflectClass componentType, ArrayInfo info) {
        Class clazz = JdkReflector.toNative(componentType);
        if(info instanceof MultidimensionalArrayInfo){
            return Array.newInstance(clazz, ((MultidimensionalArrayInfo)info).dimensions());
        }
        return Array.newInstance(clazz, info.elementCount());
    }

}
