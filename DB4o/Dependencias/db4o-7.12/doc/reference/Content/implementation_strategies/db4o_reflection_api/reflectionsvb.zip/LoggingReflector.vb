' Copyright (C) 2007   db4objects Inc.   http://www.db4o.com 

Imports System

Imports Db4objects.Db4o.Internal
Imports Db4objects.Db4o.Reflect
Imports Db4objects.Db4o.Reflect.Net

Namespace Db4objects.Db4odoc.Reflections
    Public Class LoggingReflector
        Implements Db4objects.Db4o.Reflect.IReflector
        Protected _parent As Db4objects.Db4o.Reflect.IReflector

        Private _array As Db4objects.Db4o.Reflect.IReflectArray

        Private _config As Db4objects.Db4o.Reflect.IReflectorConfiguration

        Public Overridable Function Array() As Db4objects.Db4o.Reflect.IReflectArray Implements IReflector.Array
            If _array Is Nothing Then
                _array = New Db4objects.Db4o.Reflect.Net.NetArray(Parent())
            End If
            Return _array
        End Function

        Public Overridable Function DeepClone(ByVal obj As Object) As Object Implements IReflector.DeepClone
            Return New NetReflector()
        End Function

        Public Overridable Function ForClass(ByVal forType As System.Type) As Db4objects.Db4o.Reflect.IReflectClass Implements IReflector.ForClass
            Dim rc As Db4objects.Db4o.Reflect.IReflectClass = Nothing
            Dim underlyingType As System.Type = GetUnderlyingType(forType)
            If underlyingType.IsPrimitive AndAlso Not Db4objects.Db4o.Internal.NullableArrayHandling.UseOldNetHandling() Then
                rc = CreateClass(forType)
            End If
            rc = CreateClass(underlyingType)
            Console.WriteLine("ForClass: " + forType.ToString() + " -> " + (IIf(rc Is Nothing, "", rc.GetName())))
            Return rc
        End Function

        Protected Overridable Function CreateClass(ByVal type As Type) As Db4objects.Db4o.Reflect.IReflectClass
            If type Is Nothing Then
                Return Nothing
            End If
            Dim netReflector As New NetReflector()
            netReflector.Configuration(_config)
            Return New Db4objects.Db4o.Reflect.Net.NetClass(Parent(), netReflector, type)
        End Function

        Private Shared Function GetUnderlyingType(ByVal type As Type) As Type
            If type Is Nothing Then
                Return Nothing
            End If
            Dim underlyingType As Type = Nullable.GetUnderlyingType(type)
            If underlyingType IsNot Nothing Then
                Return underlyingType
            End If
            Return type
        End Function

        Public Overridable Function ForName(ByVal className As String) As Db4objects.Db4o.Reflect.IReflectClass Implements IReflector.ForName
            Dim rc As Db4objects.Db4o.Reflect.IReflectClass = Nothing
            Try
                Dim type As Type = ReflectPlatform.ForName(className)
                If type Is Nothing Then
                    Return Nothing
                End If
                rc = ForClass(type)
                Console.WriteLine("ForName: " + className + " -> " + (IIf(rc Is Nothing, "", rc.GetName())))
            Catch
            End Try
            Return rc
        End Function

        Public Overridable Function ForObject(ByVal a_object As Object) As Db4objects.Db4o.Reflect.IReflectClass Implements IReflector.ForObject
            If a_object Is Nothing Then
                Return Nothing
            End If
            Dim rc As Db4objects.Db4o.Reflect.IReflectClass = Parent().ForClass(a_object.[GetType]())
            Console.WriteLine("ForObject:" + a_object.ToString() + " -> " + (IIf(rc Is Nothing, "", rc.GetName())))
            Return rc
        End Function

        Public Overridable Function IsCollection(ByVal candidate As Db4objects.Db4o.Reflect.IReflectClass) As Boolean Implements IReflector.IsCollection
            Dim result As Boolean = False
            If candidate.IsArray() Then
                result = False
            End If
            Dim netClass As NetClass = TryCast(candidate, NetClass)
            If netClass Is Nothing Then
                result = False
            End If
            result = GetType(System.Collections.ICollection).IsAssignableFrom(netClass.GetNetType())
            Console.WriteLine("Type " + candidate.GetName() + " is Collection " + result.ToString())
            Return result
        End Function

        Public Overridable Function MethodCallsSupported() As Boolean
            Return True
        End Function

        Public Shared Function ToMeta(ByVal reflector As Db4objects.Db4o.Reflect.IReflector, ByVal clazz As System.Type()) As Db4objects.Db4o.Reflect.IReflectClass()
            Dim claxx As Db4objects.Db4o.Reflect.IReflectClass() = Nothing
            If clazz IsNot Nothing Then
                claxx = New Db4objects.Db4o.Reflect.IReflectClass(clazz.Length - 1) {}
                For i As Integer = 0 To clazz.Length - 1
                    If clazz(i) IsNot Nothing Then
                        claxx(i) = reflector.ForClass(clazz(i))
                    End If
                Next
            End If
            Return claxx
        End Function

        Public Shared Function ToNative(ByVal claxx As Db4objects.Db4o.Reflect.IReflectClass()) As System.Type()
            Dim clazz As System.Type() = Nothing
            If claxx IsNot Nothing Then
                clazz = New System.Type(claxx.Length - 1) {}
                For i As Integer = 0 To claxx.Length - 1
                    If claxx(i) IsNot Nothing Then
                        Dim reflectClass As IReflectClass = claxx(i)
                        System.Console.WriteLine("ToNative: " + claxx(i).GetName())
                        clazz(i) = ToNative(reflectClass)
                    End If
                Next
            End If
            Return clazz
        End Function

        Public Shared Function ToNative(ByVal reflectClass As IReflectClass) As Type
            System.Console.WriteLine("ToNative: " + reflectClass.GetName())
            Return DirectCast(reflectClass.GetDelegate(), Db4objects.Db4o.Reflect.Net.NetClass).GetNetType()
        End Function

        Public Overridable Sub SetParent(ByVal reflector As IReflector) Implements IReflector.SetParent
            _parent = reflector
        End Sub

        Public Overridable Sub Configuration(ByVal config As Db4objects.Db4o.Reflect.IReflectorConfiguration) Implements IReflector.Configuration
            _config = config
        End Sub

        Public Overridable Function Configuration() As Db4objects.Db4o.Reflect.IReflectorConfiguration
            Return _config
        End Function

        Public Overridable Function NullValue(ByVal clazz As IReflectClass) As Object
            Return Platform4.NullValue(ToNative(clazz))
        End Function

        Private Function Parent() As IReflector
            If _parent Is Nothing Then
                Return Me
            End If

            Return _parent
        End Function

    End Class
End Namespace
