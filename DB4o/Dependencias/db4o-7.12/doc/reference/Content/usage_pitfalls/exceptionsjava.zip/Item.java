package com.db4odoc.exceptionsonnotstorable;

public class Item {
	public String name;
	
	public String getName(){
		return name;
	}

	public Item(String name){
		this.name = name;
	}
	
	public String toString(){
		return name;
	}
}
