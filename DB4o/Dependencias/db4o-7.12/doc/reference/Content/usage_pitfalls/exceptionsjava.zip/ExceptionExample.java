package com.db4odoc.exceptionsonnotstorable;

import java.util.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.query.*;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

	private final ObjectContainer _db;
	// more (non-persistable) state

	public ExceptionExample(String hostName, int port, String userName, String password) {
		Configuration config = Db4o.newConfiguration();
		_db = Db4o.openClient(config, hostName, port, userName, password);
	}

	public List<Item> retrieveItems() {
		ObjectSet<Item> result = _db.query(new Predicate<Item>() {
			public boolean match(Item item) {
				return true;
			}
		}, new Comparator<Item>() {
			public int compare(Item one, Item two) {
				return one.getName().compareTo(two.getName());
			}
		});
		return new ArrayList<Item>(result);
	}

}
