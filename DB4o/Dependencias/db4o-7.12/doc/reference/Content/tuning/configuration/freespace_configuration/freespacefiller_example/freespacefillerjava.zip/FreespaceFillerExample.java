package com.db4odoc.freespacefiller;

import java.io.*;
import java.util.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.io.*;

public class FreespaceFillerExample {

	private final static String DB4O_FILE_NAME = "reference.db4o";
	private final static int OBJECT_COUNT = 10000;

	public static void main(String[] args) throws IOException {
		createDatabase(getConfig());
		deleteObjects(getConfig());
		//deleteObjects(Db4oEmbedded.newConfiguration());
	}
	// end main

	private static EmbeddedConfiguration getConfig() {
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		config.file().freespace().freespaceFiller(new FreespaceFiller(){

			@Override
			public void fill(BlockAwareBinWindow io) throws IOException {
				Random r = new Random();
				byte[] data = new byte[io.length()];
				r.nextBytes(data);
				io.write(0, data);
			}
			
		});
		return config;
	}

	// end getConfig

	private static class Item 
	{
		String name;
		String description;
		
		public Item(String name, String description){
			this.name = name;
			this.description = description;
		}
		
		@Override
		public String toString(){
			return String.format("%s, %s", name, description);
		}
	}
	// end Item
	
	private static void createDatabase(EmbeddedConfiguration config) {
		new File(DB4O_FILE_NAME).delete();

		ObjectContainer container = Db4oEmbedded.openFile(config, DB4O_FILE_NAME);
		try {
			Item item;
			for (int i = 0; i < OBJECT_COUNT; i++) {
				item = new Item("Title" + i, "Just a description");
				container.store(item);
			}
		} finally {
			container.close();
		}
	}
	// end createDatabase

	private static void deleteObjects(EmbeddedConfiguration config){
		ObjectContainer container = Db4oEmbedded.openFile(config, DB4O_FILE_NAME);
		try {
			List<Item> result = container.queryByExample(Item.class);
			for (Item item :result){
				container.delete(item);
			}
		} finally {
			container.close();
		}
	}
	// end deleteObjects
}
