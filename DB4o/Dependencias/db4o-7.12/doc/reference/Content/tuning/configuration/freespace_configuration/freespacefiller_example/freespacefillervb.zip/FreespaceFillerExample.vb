Imports System
Imports System.Collections.Generic
Imports System.IO
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.IO

Namespace Db4objects.Db4odoc.FreespaceFiller
    Public Class FreespaceFillerExample

        Private Shared ReadOnly Db4oFileName As [String] = "reference.db4o"
        Private Shared ReadOnly ObjectCount As Integer = 10000

        Public Shared Sub Main(ByVal args As String())
            'DeleteObjects(GetConfig());
            'DeleteObjects(Db4oEmbedded.NewConfiguration());
            CreateDatabase(GetConfig())
        End Sub
        ' end Main

        Private Class RandomFreespaceFiller
            Implements IFreespaceFiller

            Public Sub Fill(ByVal io As BlockAwareBinWindow) Implements IFreespaceFiller.Fill
                Dim r As New Random()
                Dim data As Byte() = New Byte(io.Length() - 1) {}
                r.NextBytes(data)
                io.Write(0, data)
            End Sub

        End Class
        'end RandomFreespaceFiller

        Private Shared Function GetConfig() As IEmbeddedConfiguration
            Dim config As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            config.File.Freespace.FreespaceFiller(New RandomFreespaceFiller())
            Return config
        End Function

        ' end GetConfig

        Private Class Item
            Private name As [String]
            Private description As [String]

            Public Sub New(ByVal name As [String], ByVal description As [String])
                Me.name = name
                Me.description = description
            End Sub

            Public Function toString() As [String]
                Return [String].Format("{0}, {1}", name, description)
            End Function
        End Class
        ' end Item

        Private Shared Sub CreateDatabase(ByVal config As IEmbeddedConfiguration)
            File.Delete(Db4oFileName)

            Dim container As IObjectContainer = Db4oEmbedded.OpenFile(config, Db4oFileName)
            Try
                Dim item As Item
                For i As Integer = 0 To ObjectCount - 1
                    item = New Item("Title" & i, "Just a description")
                    container.Store(item)
                Next
            Finally
                container.Close()
            End Try
        End Sub
        ' end CreateDatabase

        Private Shared Sub DeleteObjects(ByVal config As IEmbeddedConfiguration)
            Dim container As IObjectContainer = Db4oEmbedded.OpenFile(config, Db4oFileName)
            Try
                Dim result As IList(Of Item) = container.Query(Of Item)()
                For Each item As Item In result
                    container.Delete(item)
                Next
            Finally
                container.Close()
            End Try
        End Sub
        ' end DeleteObjects
    End Class

End Namespace
