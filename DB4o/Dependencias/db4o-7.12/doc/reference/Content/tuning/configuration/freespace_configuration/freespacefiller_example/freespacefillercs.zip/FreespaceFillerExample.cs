﻿using System;
using System.Collections.Generic;
using System.IO;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.IO;

namespace Db4objects.Db4odoc.FreespaceFiller
{
    public class FreespaceFillerExample {

	private readonly static String Db4oFileName = "reference.db4o";
	private readonly static int ObjectCount = 10000;

	public static void Main(string[] args) {
		CreateDatabase(GetConfig());
		//DeleteObjects(GetConfig());
		//DeleteObjects(Db4oEmbedded.NewConfiguration());
	}
	// end Main

        private class RandomFreespaceFiller: IFreespaceFiller
        {
            public void Fill(BlockAwareBinWindow io)
            {
                Random r = new Random();
				byte[] data = new byte[io.Length()];
				r.NextBytes(data);
				io.Write(0, data);
            }
        }
	// end RandomFreespaceFiller

	private static IEmbeddedConfiguration GetConfig() {
		IEmbeddedConfiguration config = Db4oEmbedded.NewConfiguration();
		config.File.Freespace.FreespaceFiller(new RandomFreespaceFiller());
		return config;
	}

	// end GetConfig

	private class Item 
	{
		String name;
		String description;
		
		public Item(String name, String description){
			this.name = name;
			this.description = description;
		}
		
		public String toString(){
			return String.Format("{0}, {1}", name, description);
		}
	}
	// end Item
	
	private static void CreateDatabase(IEmbeddedConfiguration config) {
		File.Delete(Db4oFileName);

		IObjectContainer container = Db4oEmbedded.OpenFile(config, Db4oFileName);
		try {
			Item item;
			for (int i = 0; i < ObjectCount; i++) {
				item = new Item("Title" + i, "Just a description");
				container.Store(item);
			}
		} finally {
			container.Close();
		}
	}
	// end CreateDatabase

	private static void DeleteObjects(IEmbeddedConfiguration config){
		IObjectContainer container = Db4oEmbedded.OpenFile(config, Db4oFileName);
		try {
		    IList<Item> result = container.Query<Item>();
			foreach (Item item in result){
				container.Delete(item);
			}
		} finally {
			container.Close();
		}
	}
	// end DeleteObjects
}

}
