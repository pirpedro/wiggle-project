' Copyright (C) 2009 Versant Inc. http://www.db4o.com
Namespace Db4odoc.Debugging
    Public Class Car
        Private _model As String


        Public Sub New(ByVal model As String)
            _model = model
        End Sub

        Public Overloads Overrides Function ToString() As String
            Return _model
        End Function

    End Class
End Namespace
