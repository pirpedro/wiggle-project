' Copyright (C) 2009 Versant Inc. http://www.db4o.com
Imports System
Imports System.IO
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Query

Namespace Db4odoc.Debugging
    Public Class DebugExample
        Private Const Db4oFileName As String = "reference.db4o"

        Public Shared Sub Main(ByVal args() As String)
            SetCars()
            SetCarsWithFileOutput()
        End Sub
        ' end Main

        Private Shared Sub SetCars()
            ' Set the debug message levet to the maximum
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.MessageLevel = 3
            ' Do some db4o operations
            File.Delete(Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim car1 As Car = New Car("BMW")
                db.Store(car1)
                Dim car2 As Car = New Car("Ferrari")
                db.Store(car2)
                db.Deactivate(car1, 2)
                
                Dim results As IList(Of Car) = db.Query(Of Car)()
                ListResult(results)
            Finally
                db.Close()
            End Try
        End Sub
        ' end SetCars

        Private Shared Sub SetCarsWithFileOutput()
            ' Create StreamWriter for a file
            Dim f As FileInfo = New FileInfo("Debug.txt")
            Dim debugWriter As StreamWriter = f.CreateText()

            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()

            ' Redirect debug output to the specified writer
            configuration.Common.OutStream = debugWriter

            ' Set the debug message levet to the maximum
            configuration.Common.MessageLevel = 3
            ' Do some db4o operations
            File.Delete(Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim car1 As Car = New Car("BMW")
                db.Store(car1)
                Dim car2 As Car = New Car("Ferrari")
                db.Store(car2)
                db.Deactivate(car1, 2)
             
                Dim results As IList(Of Car) = db.Query(Of Car)()
                ListResult(results)
            Finally
                db.Close()
                debugWriter.Close()
            End Try

        End Sub
        ' end SetCarsWithFileOutput

        Private Shared Sub ListResult(Of T)(ByVal result As IList(Of T))
            Console.WriteLine(result.Count)
            For Each item As T In result
                Console.WriteLine(item)
            Next
        End Sub
        ' end ListResult
    End Class
End Namespace

