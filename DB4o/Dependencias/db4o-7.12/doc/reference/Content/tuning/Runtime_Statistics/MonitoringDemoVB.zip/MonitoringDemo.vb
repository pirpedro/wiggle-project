﻿' Copyright (C) 2004 - 2008  Versant Inc.  http://www.db4o.com

Imports Db4objects.Db4o
Imports Db4objects.Db4o.CS
Imports Db4objects.Db4o.CS.Config
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Foundation.IO
Imports Db4objects.Db4o.Query
Imports Db4objects.Db4o.Monitoring



Namespace Db4odoc.Monitoring

    Public Class MonitoringDemo

        Private Const ClientServer As Boolean = True

        Private Shared ReadOnly DatabaseFileName As String = "mydb.db4o"

        Private Const PermanentObjectCount As Integer = 10000

        Private Const TemporaryObjectCount As Integer = 1000

        Private Const QueryCount As Integer = 10

        Private _server As IObjectServer

        Public Class Item

            Public name As String

            Public Sub New(ByVal name As String)
                Me.name = name
            End Sub
        End Class


        Public Shared Sub Main(ByVal args As String())
            Dim demo As MonitoringDemo = New MonitoringDemo()
            demo.Run()
        End Sub

        Public Sub Run()

            System.Console.WriteLine("MonitoringDemo will run forever to allow you to see JMX/Perfmon statistics.")
            System.Console.WriteLine("Cancel running with CTRL + C")
            File4.Delete(DatabaseFileName)
            Dim objectContainer As IObjectContainer = OpenContainer()
            StorePermanentObjects(objectContainer)
            Try
                While (True)
                    StoreTemporaryObjects(objectContainer)
                    ExecuteQueries(objectContainer)
                    DeleteTemporaryObjects(objectContainer)
                End While
            Finally
                Close(objectContainer)
            End Try
        End Sub

        Private Sub Close(ByVal objectContainer As IObjectContainer)
            objectContainer.Close()
            If (_server IsNot Nothing) Then
                _server.Close()
                _server = Nothing
            End If
        End Sub

        Private Function OpenContainer() As IObjectContainer

            Dim user As String = "db4o"
            Dim password As String = "db4o"
            Dim port As Integer = &HDB40
            Dim serverConfig As IServerConfiguration = CType(Configure(Db4oClientServer.NewServerConfiguration()), IServerConfiguration)
            _server = Db4oClientServer.OpenServer(serverConfig, DatabaseFileName, port)
            _server.GrantAccess(user, password)
            Dim clientConfig As IClientConfiguration = CType(Configure(Db4oClientServer.NewClientConfiguration()), IClientConfiguration)
            Return Db4oClientServer.OpenClient(clientConfig, "localhost", port, user, password)
        End Function


        Private Sub ExecuteQueries(ByVal objectContainer As IObjectContainer)
            For i As Integer = 0 To QueryCount
                ExecuteSodaQuery(objectContainer)
                ExecuteOptimizedNativeQuery(objectContainer)
                ExecuteUnOptimizedNativeQuery(objectContainer)
            Next
        End Sub

        Private Sub ExecuteSodaQuery(ByVal objectContainer As IObjectContainer)

            Dim Query As IQuery = objectContainer.Query()
            Query.Constrain(GetType(MonitoringDemo.Item))
            Query.Descend("name").Constrain("1")
            Query.Execute()
        End Sub


        Private Sub ExecuteOptimizedNativeQuery(ByVal objectContainer As IObjectContainer)

            objectContainer.Query(New NamePredicate())
        End Sub

        Private Class NamePredicate
            Inherits Predicate
            Public Function Match(ByVal candidate As MonitoringDemo.Item) As Boolean
                Return candidate.name.Equals("name1")
            End Function
        End Class

      
        Private Sub ExecuteUnOptimizedNativeQuery(ByVal objectContainer As IObjectContainer)
            objectContainer.Query(New CharPredicate())
        End Sub

        Private Class CharPredicate
            Inherits Predicate
            Public Function Match(ByVal candidate As MonitoringDemo.Item) As Boolean
                Return (candidate.name(0) = "q")
            End Function
        End Class
  
        Private Sub DeleteTemporaryObjects(ByVal objectContainer As IObjectContainer)

            Dim Query As IQuery = objectContainer.Query()
            Query.Constrain(GetType(MonitoringDemo.Item))
            Query.Descend("name").Constrain("temp")
            Dim objectSet As IObjectSet = Query.Execute()
            While (objectSet.HasNext())
                objectContainer.Delete((objectSet.Next()))
            End While
            objectContainer.Commit()
        End Sub

        Private Sub StoreTemporaryObjects(ByVal objectContainer As IObjectContainer)

            For i As Integer = 0 To TemporaryObjectCount - 1
                objectContainer.Store(New MonitoringDemo.Item("temp"))
            Next
            objectContainer.Commit()
        End Sub

        Private Sub StorePermanentObjects(ByVal objectContainer As IObjectContainer)
            For i As Integer = 0 To PermanentObjectCount - 1
                objectContainer.Store(New MonitoringDemo.Item(String.Empty + i.ToString()))
            Next
            objectContainer.Commit()
        End Sub

        Private Function Configure(ByVal config As ICommonConfigurationProvider) As ICommonConfigurationProvider
            config.Common.ObjectClass(GetType(MonitoringDemo.Item)).ObjectField("name").Indexed(True)
            config.Common.Add(New IOMonitoringSupport())
            config.Common.Add(New QueryMonitoringSupport())
            config.Common.Add(New NativeQueryMonitoringSupport())
            config.Common.Add(New ReferenceSystemMonitoringSupport())
            config.Common.Add(New FreespaceMonitoringSupport())
            config.Common.Add(New Global.Db4objects.Db4o.Monitoring.CS.NetworkingMonitoringSupport())
            config.Common.Add(New ObjectMonitoringSupport())

            Return config
        End Function
    End Class

End Namespace
