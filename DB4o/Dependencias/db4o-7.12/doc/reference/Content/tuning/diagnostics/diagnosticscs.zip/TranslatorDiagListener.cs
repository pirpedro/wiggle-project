/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */

using Db4objects.Db4o.Diagnostic;

namespace Db4objects.Db4odoc.Diagnostics
{
	public class TranslatorDiagListener: IDiagnosticListener
	{
       	public void OnDiagnostic(IDiagnostic d) 
		{
            if (d.GetType().Equals(typeof(DescendIntoTranslator)))
			{
				System.Console.WriteLine(d.ToString());
			}
		}
	}
}