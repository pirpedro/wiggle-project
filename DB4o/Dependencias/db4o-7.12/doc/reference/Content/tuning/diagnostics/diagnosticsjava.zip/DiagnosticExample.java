/* Copyright (C) 2004 - 2009 Versant Inc. http://www.db4o.com */
package com.db4odoc.diagnostics;

import java.io.File;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.diagnostic.DiagnosticToConsole;
import com.db4o.query.Query;


public class DiagnosticExample{
	private final static String DB4O_FILE_NAME="reference.db4o";
	
	public static void main(String[] args){
		testEmpty();
        testArbitrary();  
        testIndexDiagnostics();
        testTranslatorDiagnostics();
	}
	// end main
	
	private static void testEmpty() {
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		configuration.common().diagnostic().addListener(new DiagnosticToConsole());
        new File(DB4O_FILE_NAME).delete();
        ObjectContainer container=Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
        try {
        	setEmptyObject(container);
        }
        finally {
            container.close();
        }
    }
    // end testEmpty
    
    private static void setEmptyObject(ObjectContainer container){
    	Empty empty = new Empty();
        container.store(empty);
    }
    // end setEmptyObject
    	
    private static void testArbitrary() {
    	EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
    	configuration.common().diagnostic().addListener(new DiagnosticToConsole());
    	new File(DB4O_FILE_NAME).delete();
        ObjectContainer container=Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
        try {
        	Pilot pilot = new Pilot("Rubens Barrichello",99);
        	container.store(pilot);
        	queryPilot(container);
        }
        finally {
            container.close();
        }
    }
    // end testArbitrary
	
    private static void queryPilot(ObjectContainer container){
    	int[]  i = new int[]{19,100};
    	List result = container.query(new ArbitraryQuery(i));
    	listResult(result);
    }
    // end queryPilot
    
    private static void testIndexDiagnostics() {
    	new File(DB4O_FILE_NAME).delete();
    	
    	EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
    	configuration.common().diagnostic().addListener(new IndexDiagListener());
    	configuration.common().updateDepth(3);
        
        ObjectContainer container=Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
        try {
        	Pilot pilot1 = new Pilot("Rubens Barrichello",99);
        	container.store(pilot1);
        	Pilot pilot2 = new Pilot("Michael Schumacher",100);
        	container.store(pilot2);
        	queryPilot(container);
        	setEmptyObject(container);
        	Query query = container.query();
        	query.constrain(Pilot.class);
			query.descend("points").constrain(new Integer(99));
			List result = query.execute();
			listResult(result);
        }
        finally {
            container.close();
        }
    }
    // end testIndexDiagnostics
     
    private static void testTranslatorDiagnostics() {
    	storeTranslatedCars();
    	retrieveTranslatedCars();
    	retrieveTranslatedCarsNQ();
    	retrieveTranslatedCarsNQUnopt();
    	retrieveTranslatedCarsSODAEv();
    }
    // end testTranslatorDiagnostics
    
    private static void storeTranslatedCars() {
    	new File(DB4O_FILE_NAME).delete();
    	
    	EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
    	configuration.common().objectClass(Car.class).translate(new CarTranslator());
    	configuration.common().objectClass(Car.class).callConstructor(true);
    	
		ObjectContainer container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
		try {
			Car car1 = new Car("BMW");
			System.out.println("ORIGINAL: " + car1);
			container.store(car1);
			Car car2 = new Car("Ferrari");
			System.out.println("ORIGINAL: " + car2);
			container.store(car2);
		} catch (Exception exc) {
			System.out.println(exc.toString());
			return;
		} finally {
			container.close();
		}
	}
    // end storeTranslatedCars

    private static void retrieveTranslatedCars() {
    	EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
    	configuration.common().diagnostic().addListener(new TranslatorDiagListener());
    	configuration.common().objectClass(Car.class).translate(new CarTranslator());
    	configuration.common().objectClass(Car.class).callConstructor(true);
    	ObjectContainer container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
		try {
			List result = container.query(Car.class);
			listResult(result);
		} finally {
			container.close();
		}
	}
    // end retrieveTranslatedCars

    private static void retrieveTranslatedCarsNQ() {
    	EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
    	configuration.common().diagnostic().addListener(new TranslatorDiagListener());
    	configuration.common().objectClass(Car.class).translate(new CarTranslator());
    	configuration.common().objectClass(Car.class).callConstructor(true);
    	ObjectContainer container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
		try {
			List  result = container.query(new NewCarModel());
			listResult(result);
		} finally {
			container.close();
		}
	}
    // end retrieveTranslatedCarsNQ
    
    private static void retrieveTranslatedCarsNQUnopt() {
    	EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
    	configuration.common().optimizeNativeQueries(false);
    	configuration.common().diagnostic().addListener(new TranslatorDiagListener());
    	configuration.common().objectClass(Car.class).translate(new CarTranslator());
    	configuration.common().objectClass(Car.class).callConstructor(true);
    	ObjectContainer container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
		try {
			List  result = container.query(new NewCarModel());
			listResult(result);
		} finally {
			container.close();
		}
	}
    // end retrieveTranslatedCarsNQUnopt

    private static void retrieveTranslatedCarsSODAEv() {
    	EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
    	configuration.common().diagnostic().addListener(new TranslatorDiagListener());
    	configuration.common().objectClass(Car.class).translate(new CarTranslator());
    	configuration.common().objectClass(Car.class).callConstructor(true);
    	ObjectContainer container = Db4oEmbedded.openFile(configuration, DB4O_FILE_NAME);
		try {
			Query query = container.query();
			query.constrain(Car.class);
			query.constrain(new CarEvaluation());
			List result = query.execute();
			listResult(result);
		} finally {
			container.close();
		}
	}
    // end retrieveTranslatedCarsSODAEv
    
    private static void listResult(List result) {
        System.out.println(result.size());
        for (Object o: result){
            System.out.println(o);
        }
    }
    // end listResult
}
