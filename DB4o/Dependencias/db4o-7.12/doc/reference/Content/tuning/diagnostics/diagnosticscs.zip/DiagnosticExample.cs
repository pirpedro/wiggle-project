/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */

using System.Collections;
using System.Collections.Generic;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Query;
using Db4objects.Db4o.Diagnostic;
using System;
using System.IO;

namespace Db4objects.Db4odoc.Diagnostics
{
    public class DiagnosticExample
    {
        public readonly static string Db4oFileName = "reference.db4o";

        public static void Main(string[] args)
        {
            TestEmpty();
            TestArbitrary();
            TestIndexDiagnostics();
            TestTranslatorDiagnostics();
        }
        // end Main

        public static void TestEmpty()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.Diagnostic.AddListener(new DiagnosticToConsole());
            File.Delete(Db4oFileName);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                SetEmptyObject(db);
            }
            finally
            {
                db.Close();
            }
        }
        // end TestEmpty

        private static void SetEmptyObject(IObjectContainer db)
        {
            Empty empty = new Empty();
            db.Store(empty);
        }
        // end SetEmptyObject

        public static void TestArbitrary()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.Diagnostic.AddListener(new DiagnosticToConsole());
            File.Delete(Db4oFileName);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                Pilot pilot = new Pilot("Rubens Barrichello", 99);
                db.Store(pilot);
                QueryPilot(db);
            }
            finally
            {
                db.Close();
            }
        }
        // end TestArbitrary

        private static void QueryPilot(IObjectContainer db)
        {
            int[] i = new int[] { 19, 100 };
            IList result = db.Query(new ArbitraryQuery(i));
            ListResult(result);
        }
        // end QueryPilot

        public static void TestIndexDiagnostics()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.Diagnostic.AddListener(new IndexDiagListener());
            configuration.Common.UpdateDepth = 3;
            File.Delete(Db4oFileName);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                Pilot pilot1 = new Pilot("Rubens Barrichello", 99);
                db.Store(pilot1);
                Pilot pilot2 = new Pilot("Michael Schumacher", 100);
                db.Store(pilot2);
                QueryPilot(db);
                SetEmptyObject(db);
                IQuery query = db.Query();
                query.Constrain(typeof(Pilot));
                query.Descend("_points").Constrain("99");
                IList result = query.Execute();
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end TestIndexDiagnostics

        public static void TestTranslatorDiagnostics()
        {
            StoreTranslatedCars();
            RetrieveTranslatedCars();
            RetrieveTranslatedCarsNQ();
            RetrieveTranslatedCarsNQUnopt();
            RetrieveTranslatedCarsSODAEv();
        }
        // end TestTranslatorDiagnostics

        public static void StoreTranslatedCars()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.Diagnostic.AddListener(new DiagnosticToConsole());
            configuration.Common.ObjectClass(typeof(Car)).Translate(new CarTranslator());
            configuration.Common.ObjectClass(typeof(Car)).CallConstructor(true);
            File.Delete(Db4oFileName);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                Car car1 = new Car("BMW");
                System.Diagnostics.Trace.WriteLine("ORIGINAL: " + car1);
                db.Store(car1);
                Car car2 = new Car("Ferrari");
                System.Diagnostics.Trace.WriteLine("ORIGINAL: " + car2);
                db.Store(car2);
            }
            catch (Exception exc)
            {
                System.Diagnostics.Trace.WriteLine(exc.Message);
                return;
            }
            finally
            {
                db.Close();
            }
        }
        // end StoreTranslatedCars

        public static void RetrieveTranslatedCars()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.Diagnostic.AddListener(new TranslatorDiagListener());
            configuration.Common.ObjectClass(typeof(Car)).Translate(new CarTranslator());
            configuration.Common.ObjectClass(typeof(Car)).CallConstructor(true);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                IQuery query = db.Query();
                query.Constrain(typeof(Car));
                IList result = query.Execute();
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end RetrieveTranslatedCars

        public static void RetrieveTranslatedCarsNQ()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.Diagnostic.AddListener(new TranslatorDiagListener());
            configuration.Common.ObjectClass(typeof(Car)).Translate(new CarTranslator());
            configuration.Common.ObjectClass(typeof(Car)).CallConstructor(true);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                IList result = db.Query(new NewCarModel());
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end RetrieveTranslatedCarsNQ

        public static void RetrieveTranslatedCarsNQUnopt()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.OptimizeNativeQueries = false;
            configuration.Common.Diagnostic.AddListener(new DiagnosticToConsole());
            configuration.Common.ObjectClass(typeof(Car)).Translate(new CarTranslator());
            configuration.Common.ObjectClass(typeof(Car)).CallConstructor(true);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                IList result = db.Query(new NewCarModel());
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end RetrieveTranslatedCarsNQUnopt

        public static void RetrieveTranslatedCarsSODAEv()
        {
            IEmbeddedConfiguration configuration = Db4oEmbedded.NewConfiguration();
            configuration.Common.Diagnostic.AddListener(new TranslatorDiagListener());

            configuration.Common.ObjectClass(typeof(Car)).Translate(new CarTranslator());
            configuration.Common.ObjectClass(typeof(Car)).CallConstructor(true);
            IObjectContainer db = Db4oEmbedded.OpenFile(configuration, Db4oFileName);
            try
            {
                IQuery query = db.Query();
                query.Constrain(typeof(Car));
                query.Constrain(new CarEvaluation());
                IList result = query.Execute();
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end RetrieveTranslatedCarsSODAEv

        public static void ListResult<T>(IList<T> result)
        {
            Console.WriteLine(result.Count);
            foreach (T item in result)
            {
                Console.WriteLine(item);
            }
        }
        // end ListResult

        public static void ListResult(IList result)
        {
            Console.WriteLine(result.Count);
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }
        }
        // end ListResult

    }
}
