' Copyright (C) 2009 Versant Inc. http://www.db4o.com

Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Query
Imports Db4objects.Db4o.Diagnostic
Imports System
Imports System.IO

Namespace Db4odoc.Diagnostics
    Public Class DiagnosticExample
        Public Shared ReadOnly Db4oFileName As String = "reference.db4o"

        Public Shared Sub Main(ByVal args As String())
            TestEmpty()
            TestArbitrary()
            TestIndexDiagnostics()
            TestTranslatorDiagnostics()
        End Sub
        ' end Main

        Public Shared Sub TestEmpty()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.Diagnostic().AddListener(New DiagnosticToTrace())
            File.Delete(Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                SetEmptyObject(db)
            Finally
                db.Close()
            End Try
        End Sub
        ' end TestEmpty

        Private Shared Sub SetEmptyObject(ByVal db As IObjectContainer)
            Dim empty As Empty = New Empty()
            db.Store(empty)
        End Sub
        ' end SetEmptyObject

        Public Shared Sub TestArbitrary()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.Diagnostic().AddListener(New DiagnosticToConsole())
            File.Delete(Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim pilot As Pilot = New Pilot("Rubens Barrichello", 99)
                db.Store(pilot)
                QueryPilot(db)
            Finally
                db.Close()
            End Try
        End Sub
        ' end TestArbitrary

        Private Shared Sub QueryPilot(ByVal db As IObjectContainer)
            Dim i() As Integer = New Integer() {19, 100}

            Dim result As IList = db.Query(New ArbitraryQuery(i))
            ListResult(result)
        End Sub
        ' end QueryPilot

        Public Shared Sub TestIndexDiagnostics()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.Diagnostic().AddListener(New IndexDiagListener())
            configuration.Common.UpdateDepth = 3
            File.Delete(Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim pilot1 As Pilot = New Pilot("Rubens Barrichello", 99)
                db.Store(pilot1)
                Dim pilot2 As Pilot = New Pilot("Michael Schumacher", 100)
                db.Store(pilot2)
                QueryPilot(db)
                SetEmptyObject(db)
                Dim query As IQuery = db.Query()
                query.Constrain(GetType(Pilot))
                query.Descend("_points").Constrain("99")
                Dim result As IList = query.Execute()
                ListResult(result)
            Finally
                db.Close()
            End Try
        End Sub
        ' end TestIndexDiagnostics

        Public Shared Sub TestTranslatorDiagnostics()
            StoreTranslatedCars()
            RetrieveTranslatedCars()
            RetrieveTranslatedCarsNQ()
            RetrieveTranslatedCarsNQUnopt()
            RetrieveTranslatedCarsSODAEv()
        End Sub
        ' end TestTranslatorDiagnostics

        Public Shared Sub StoreTranslatedCars()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.ObjectClass(GetType(Car)).Translate(New CarTranslator())
            configuration.Common.ObjectClass(GetType(Car)).CallConstructor(True)
            File.Delete(Db4oFileName)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim car1 As Car = New Car("BMW")
                System.Diagnostics.Trace.WriteLine("ORIGINAL: " + car1.ToString())
                db.Store(car1)
                Dim car2 As Car = New Car("Ferrari")
                System.Diagnostics.Trace.WriteLine("ORIGINAL: " + car2.ToString())
                db.Store(car2)
            Catch exc As Exception
                System.Diagnostics.Trace.WriteLine(exc.Message)
                Return
            Finally
                db.Close()
            End Try
        End Sub
        ' end StoreTranslatedCars

        Public Shared Sub RetrieveTranslatedCars()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.Diagnostic().AddListener(New TranslatorDiagListener())
            configuration.Common.ObjectClass(GetType(Car)).Translate(New CarTranslator())
            configuration.Common.ObjectClass(GetType(Car)).CallConstructor(True)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim query As IQuery = db.Query()
                query.Constrain(GetType(Car))
                Dim result As IList = query.Execute()
                ListResult(result)
            Finally
                db.Close()
            End Try
        End Sub
        ' end RetrieveTranslatedCars

        Public Shared Sub RetrieveTranslatedCarsNQ()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.Diagnostic().AddListener(New TranslatorDiagListener())
            configuration.Common.ObjectClass(GetType(Car)).Translate(New CarTranslator())
            configuration.Common.ObjectClass(GetType(Car)).CallConstructor(True)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim result As IList = db.Query(New NewCarModel())
                ListResult(result)
            Finally
                db.Close()
            End Try
        End Sub
        ' end RetrieveTranslatedCarsNQ

        Public Shared Sub RetrieveTranslatedCarsNQUnopt()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.OptimizeNativeQueries = False
            configuration.Common.Diagnostic.AddListener(New TranslatorDiagListener())
            configuration.Common.ObjectClass(GetType(Car)).Translate(New CarTranslator())
            configuration.Common.ObjectClass(GetType(Car)).CallConstructor(True)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim result As IList = db.Query(New NewCarModel())
                ListResult(result)
            Finally
                db.Close()
            End Try
        End Sub
        ' end RetrieveTranslatedCarsNQUnopt

        Public Shared Sub RetrieveTranslatedCarsSODAEv()
            Dim configuration As IEmbeddedConfiguration = Db4oEmbedded.NewConfiguration()
            configuration.Common.Diagnostic().AddListener(New TranslatorDiagListener())
            configuration .Common .ObjectClass(GetType(Car)).Translate(New CarTranslator())
            configuration.Common.ObjectClass(GetType(Car)).CallConstructor(True)
            Dim db As IObjectContainer = Db4oEmbedded.OpenFile(configuration, Db4oFileName)
            Try
                Dim query As IQuery = db.Query()
                query.Constrain(GetType(Car))
                query.Constrain(New CarEvaluation())
                Dim result As IList = query.Execute()
                ListResult(result)
            Finally
                db.Close()
            End Try
        End Sub
        ' end RetrieveTranslatedCarsSODAEv

        Public Shared Sub ListResult(ByVal result As IList)
            Console.WriteLine(result.Count)
            For Each item As Object In result
                Console.WriteLine(item)
            Next
        End Sub
        ' end ListResult
    End Class
End Namespace
