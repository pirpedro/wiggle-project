' Copyright (C) 2009 Versant Inc. http://www.db4o.com
Imports System

Namespace Db4odoc.Diagnostics
    Public Class Empty
        Public Sub New()
        End Sub

        Public Function CurrentTime() As String
            Dim dt As DateTime = DateTime.Now
            Dim time As String = dt.ToString("d")
            Return time
        End Function

        Public Overrides Function ToString() As String
            Return CurrentTime()
        End Function
    End Class
End Namespace
