/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */
using Db4objects.Db4o.Query;

namespace Db4objects.Db4odoc.Diagnostics
{

	public class CarEvaluation:IEvaluation 
	{
		public void Evaluate(ICandidate candidate)
		{
			Car car=(Car)candidate.GetObject();
			candidate.Include(car.Model.EndsWith("2002"));
		}
	}
}