' Copyright (C) 2009 Versant Inc. http://www.db4o.com

Imports Db4objects.Db4o.Diagnostic

Namespace Db4odoc.Diagnostics
    Public Class IndexDiagListener

        Implements IDiagnosticListener
        Public Sub OnDiagnostic(ByVal d As IDiagnostic) Implements IDiagnosticListener.OnDiagnostic
            If TypeOf d Is LoadedFromClassIndex Then
                System.Console.WriteLine(d)
            End If
        End Sub
    End Class
End Namespace
