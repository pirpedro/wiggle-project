/* Copyright (C) 2009 Versant Inc. http://www.db4o.com */

namespace Db4objects.Db4odoc.Diagnostics
{

    public class NewCarModel : Db4objects.Db4o.Query.Predicate 
	{
		public bool Match(Car car) 
		{
			return car.Model.EndsWith("2002");
		}
	}
}