' Copyright (C) 2009 Versant Inc. http://www.db4o.com

Imports Db4objects.Db4o.Query

Namespace Db4odoc.Diagnostics

    Public Class NewCarModel
        Inherits Predicate
        Public Function Match(ByVal car As Car) As Boolean
            Return car.Model.EndsWith("2002")
        End Function
    End Class
End Namespace
