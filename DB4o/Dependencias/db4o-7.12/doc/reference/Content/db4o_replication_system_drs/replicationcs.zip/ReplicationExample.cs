using System;

using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Query;

using Db4objects.Drs;

namespace Db4objects.Db4odoc.Replication
{
    public class ReplicationExample
    {
        private const string DtFileName = "reference.db4o";
        private const string HhFileName = "handheld.db4o";

        public static void Main(string[] srgs)
        {
            Replicate();
            ReplicateBiDirectional();
            ReplicatePilots();
        }

        public static IConfiguration ConfigureReplication()
        {
            IConfiguration db4oConfig = Db4oFactory.NewConfiguration();
            db4oConfig.GenerateUUIDs(ConfigScope.Globally);
            db4oConfig.GenerateVersionNumbers(ConfigScope.Globally);
            return db4oConfig;
        }
        // end configureReplication

        public static IConfiguration ConfigureReplicationPilot()
        {
            IConfiguration db4oConfig = Db4oFactory.NewConfiguration();
            db4oConfig.ObjectClass(typeof(Pilot)).GenerateUUIDs(true);
            db4oConfig.ObjectClass(typeof(Pilot)).GenerateVersionNumbers(true);
            return db4oConfig;
        }
        // end configureReplicationPilot

        public static IConfiguration ConfigureForExisting()
        {
            IConfiguration db4oConfig = Db4oFactory.NewConfiguration();
            db4oConfig.ObjectClass(typeof(Pilot)).EnableReplication(true);
            Db4objects.Db4o.Defragment.Defragment.Defrag(DtFileName);
            return db4oConfig;
        }
        // end configureForExisting

        public static void Replicate()
        {
            IObjectContainer desktop = Db4oFactory.OpenFile(ConfigureReplication(), DtFileName);
            IObjectContainer handheld = Db4oFactory.OpenFile(ConfigureReplication(), HhFileName);
            IReplicationSession replication = Db4objects.Drs.Replication.Begin(handheld, desktop);
            
            /*
             * There is no need to replicate all the objects each time. 
             * ObjectsChangedSinceLastReplication methods gives us 
             * a list of modified objects
             */
            IObjectSet changed = replication.ProviderA().ObjectsChangedSinceLastReplication();
            //Iterate through changed objects, replicate them
            while (changed.HasNext())
            {
                replication.Replicate(changed .Next ());
            }
            replication.Commit();
            handheld.Close();
            desktop.Close();
        }
        // end replicate	

        public static void ReplicatePilots()
        {
            IObjectContainer desktop = Db4oFactory.OpenFile(ConfigureReplicationPilot(), DtFileName);
            IObjectContainer handheld = Db4oFactory.OpenFile(ConfigureReplicationPilot(), HhFileName);
            IReplicationSession replication = Db4objects.Drs.Replication.Begin(handheld, desktop);
            IObjectSet changed = replication.ProviderB().ObjectsChangedSinceLastReplication();
            //Iterate changed objects, replicate them
            while (changed.HasNext())
            {
                object p = changed .Next();
                if ( p is Pilot)
                {
                    if (((Pilot)p).Name.StartsWith("S"))
                    {
                        replication.Replicate(p);
                    }
                }
            }
            replication.Commit();
            handheld.Close();
            desktop.Close();
        }
        // end ReplicatePilots

        public static void ReplicateBiDirectional()
        {
            IObjectContainer desktop = Db4oFactory.OpenFile(ConfigureReplication(), DtFileName);
            IObjectContainer handheld = Db4oFactory.OpenFile(ConfigureReplication(), HhFileName);
            IReplicationSession replication = Db4objects.Drs.Replication.Begin(handheld, desktop);
            IObjectSet changed = replication.ProviderA().ObjectsChangedSinceLastReplication();
            while (changed.HasNext())
            {
                replication.Replicate(changed.Next());
            }

            // Add one more loop for bi-directional replication
            changed = replication.ProviderB().ObjectsChangedSinceLastReplication();
            while (changed.HasNext())
            {
                replication.Replicate(changed.Next());
            }
            replication.Commit();
            handheld.Close();
            desktop.Close();
        }
        // end ReplicateBiDirectional
    }

}
