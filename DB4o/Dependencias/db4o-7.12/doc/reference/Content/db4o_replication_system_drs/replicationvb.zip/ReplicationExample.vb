Imports System
Imports Db4objects.Db4o
Imports Db4objects.Db4o.Config
Imports Db4objects.Db4o.Query
Imports Db4objects.Drs


Namespace Db4objects.Db4odoc.Replicating
    Public Class ReplicationExample
        Public Shared ReadOnly DtFileName As String = "reference.db4o"
        Public Shared ReadOnly HhFileName As String = "handheld.db4o"

        Public Shared Sub Main(ByVal args As String())
            Replicate()
            ReplicateBiDirectional()
            ReplicatePilots()
        End Sub

        Public Shared Function ConfigureReplication() As IConfiguration
            Dim db4oConfig As IConfiguration = Db4oFactory.NewConfiguration()
            db4oConfig.GenerateUUIDs(ConfigScope.Globally)
            db4oConfig.GenerateVersionNumbers(ConfigScope.Globally)
            Return db4oConfig
        End Function
        ' end configureReplication

        Public Shared Function ConfigureReplicationPilot() As IConfiguration
            Dim db4oConfig As IConfiguration = Db4oFactory.NewConfiguration()
            db4oConfig.ObjectClass(GetType(Pilot)).GenerateUUIDs(True)
            db4oConfig.ObjectClass(GetType(Pilot)).GenerateVersionNumbers(True)
            Return db4oConfig
        End Function
        ' end configureReplicationPilot

        Public Shared Function ConfigureForExisting() As IConfiguration
            Dim db4oConfig As IConfiguration = Db4oFactory.NewConfiguration()
            db4oConfig.ObjectClass(GetType(Pilot)).EnableReplication(True)
            Defragment.Defragment.Defrag(DtFileName)
            Return db4oConfig
        End Function
        ' end configureForExisting

        Public Shared Sub Replicate()
            Dim desktop As IObjectContainer = Db4oFactory.OpenFile(ConfigureReplication(), DtFileName)
            Dim handheld As IObjectContainer = Db4oFactory.OpenFile(ConfigureReplication(), HhFileName)
            Dim replic As IReplicationSession = Replication.Begin(handheld, desktop) '
            ' There is no need to replicate all the objects each time. 
            ' ObjectsChangedSinceLastReplication methods gives us 
            ' a list of modified objects
            Dim changed As IObjectSet = replic.ProviderA().ObjectsChangedSinceLastReplication()
            'Iterate through the changed objects, replicate them
            While changed.HasNext()
                replic.Replicate(changed.Next())
            End While
            replic.Commit()
            handheld.Close()
            desktop.Close()
        End Sub
        ' end replicate	

        Public Shared Sub ReplicatePilots()
            Dim desktop As IObjectContainer = Db4oFactory.OpenFile(ConfigureReplicationPilot(), DtFileName)
            Dim handheld As IObjectContainer = Db4oFactory.OpenFile(ConfigureReplicationPilot(), HhFileName)
            Dim replic As IReplicationSession = Replication.Begin(handheld, desktop) '
            ' There is no need to replicate all the objects each time. 
            ' ObjectsChangedSinceLastReplication methods gives us 
            ' a list of modified objects
            Dim changed As IObjectSet = replic.ProviderB().ObjectsChangedSinceLastReplication()
            ' Iterate through the changed objects,
            ' check if the name starts with "S" and replicate only those items
            While changed.HasNext()
                Dim p As Object = changed.Next
                If (p Is GetType(Pilot)) Then
                    If (CType(p, Pilot)).Name.StartsWith("S") Then
                        replic.Replicate(p)
                    End If
                End If
            End While
            replic.Commit()
            handheld.Close()
            desktop.Close()
        End Sub
        ' end ReplicatePilots

        Public Shared Sub ReplicateBiDirectional()
            Dim desktop As IObjectContainer = Db4oFactory.OpenFile(ConfigureReplication(), DtFileName)
            Dim handheld As IObjectContainer = Db4oFactory.OpenFile(ConfigureReplication(), HhFileName)
            Dim replic As IReplicationSession = Replication.Begin(handheld, desktop) '
            Dim changed As IObjectSet = replic.ProviderA().ObjectsChangedSinceLastReplication()
            'Iterate changed objects, replicate them
            While changed.HasNext()
                replic.Replicate(changed.Next())
            End While

            changed = replic.ProviderB().ObjectsChangedSinceLastReplication()
            ' Add one more loop for bi-directional replication
            While changed.HasNext()
                replic.Replicate(changed.Next())
            End While
            replic.Commit()
            handheld.Close()
            desktop.Close()
        End Sub
        ' end ReplicateBiDirectional
    End Class
End Namespace
