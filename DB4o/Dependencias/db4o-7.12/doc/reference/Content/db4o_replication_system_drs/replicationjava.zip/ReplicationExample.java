/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.replication;

import java.io.*;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.drs.*;


public class ReplicationExample {
	
	private final static String DTFILENAME="reference.db4o";
	private final static String HHFILENAME="handheld.db4o";
	
	public static void main(String[] args){
		replicate();
		replicateBiDirectional();
		replicatePilots();
	}
		
	public static Configuration configureReplication(){
		Configuration db4oConfig = Db4o.newConfiguration();
		db4oConfig.generateUUIDs(ConfigScope.GLOBALLY); 
		db4oConfig.generateVersionNumbers(ConfigScope.GLOBALLY);
		return db4oConfig;
	}
	// end configureReplication
	
	public static Configuration configureReplicationPilot(){
		Configuration db4oConfig = Db4o.newConfiguration();
		db4oConfig.objectClass(Pilot.class).generateUUIDs(true); 
		db4oConfig.objectClass(Pilot.class).generateVersionNumbers(true);
		return db4oConfig;
	}
	// end configureReplicationPilot
	
	public static Configuration configureForExisting(){
		Configuration db4oConfig = Db4o.newConfiguration();
		db4oConfig.objectClass(Pilot.class).enableReplication(true); 
		try {
			com.db4o.defragment.Defragment.defrag("sample.db4o");
		} catch (IOException ex){
			System.out .println(ex.toString());
		}
		return db4oConfig;
	}
	// end configureForExisting
	
	public static void replicate(){
		ObjectContainer desktop=Db4o.openFile(configureReplication(), DTFILENAME);
		ObjectContainer handheld=Db4o.openFile(configureReplication(), HHFILENAME);
        //		 Setup a replication session
		ReplicationSession replication = Replication.begin(handheld, desktop);
		
		/*
		 * There is no need to replicate all the objects each time. 
		 * objectsChangedSinceLastReplication methods gives us 
		 * a list of modified objects
		 */
		ObjectSet changed =	replication.providerA().objectsChangedSinceLastReplication();
		
		while (changed.hasNext()) {
			replication.replicate(changed.next());
		}
		
		replication.commit();
		handheld.close();
		desktop.close();
	} 
	// end replicate
	
	public static void replicatePilots(){
		ObjectContainer desktop=Db4o.openFile(configureReplicationPilot(),DTFILENAME);
		ObjectContainer handheld=Db4o.openFile(configureReplicationPilot(),HHFILENAME);
		ReplicationSession replication = Replication.begin(handheld, desktop);
		ObjectSet changed =	replication.providerB().objectsChangedSinceLastReplication();
		
		/* Iterate through the changed objects,
		 * check if the name starts with "S" and replicate only those items
		 */
		while (changed.hasNext()) {
			if (changed instanceof Pilot) {
				if (((Pilot)changed).getName().startsWith("S")){
					replication.replicate(changed.next());
				}
			}
		}
		
		replication.commit();
		handheld.close();
		desktop.close();
	} 
	// end replicatePilots	
	
	public static void replicateBiDirectional(){
		ObjectContainer desktop=Db4o.openFile(configureReplication(), DTFILENAME);
		ObjectContainer handheld=Db4o.openFile(configureReplication(), HHFILENAME);
		ReplicationSession replication = Replication.begin(handheld, desktop);
		ObjectSet changed =	replication.providerA().objectsChangedSinceLastReplication();
		while (changed.hasNext()) {
					replication.replicate(changed.next());
		}
		// Add one more loop for bi-directional replication
		changed = replication.providerB().objectsChangedSinceLastReplication();
		while(changed.hasNext()) {    
			replication.replicate(changed.next());
		}
		
		replication.commit();
		handheld.close();
		desktop.close();
	} 
	// end replicateBiDirectional
}
