/* Copyright (C) 2004 - 2009 Versant Inc. http://www.db4o.com */

package com.db4odoc.identity;

import java.io.File;
import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.query.Query;

public class IdentityExample {
	private final static String DB4O_FILE_NAME="reference.db4o";

	public static void main(String[] args) {
		storeObjects();
		checkUniqueness();
		checkReferenceCache();
		checkReferenceCacheWithPurge();
		testBind();
		
		testCopyingWithPurge();
	}
	// end main

	private static void storeObjects(){
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
		try {
			Car car = new Car("BMW", new Pilot("Rubens Barrichello"));
			container.store(car);
			car = new Car("Ferrari", new Pilot("Michael Schumacher"));
			container.store(car);
		} finally {
			container.close();
		}
	}
	// end storeObjects
	
	private static void checkUniqueness(){
		storeObjects();
		ObjectContainer container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
		try {
			List<Car> cars = container.query(Car.class);
			Car car = (Car)cars.get(0);
			String pilotName = car.getPilot().getName();
			List<Pilot> pilots = container.queryByExample(new Pilot(pilotName));
			Pilot pilot = (Pilot)pilots.get(0);
			System.out.println("Retrieved objects are identical: " + (pilot == car.getPilot()));
		} finally {
			container.close();
		}
	}
	// end checkUniqueness
	
	private static void checkReferenceCache(){
		storeObjects();
		ObjectContainer container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
		try {
			List<Pilot> pilots = container.query(Pilot.class);
			Pilot pilot = (Pilot)pilots.get(0);
			String pilotName = pilot.getName();
			pilot.setName("new name");
			System.out.println("Retrieving pilot by name: " + pilotName);
			List<Pilot> pilots1 = container.queryByExample(new Pilot(pilotName));
			listResult(pilots1);
		} finally {
			container.close();
		}
	}
	// end checkReferenceCache
	
	private static void checkReferenceCacheWithPurge(){
		storeObjects();
		ObjectContainer container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
		try {
			List<Pilot> pilots = container.query(Pilot.class);
			Pilot pilot = (Pilot)pilots.get(0);
			String pilotName = pilot.getName();
			pilot.setName("new name");
			System.out.println("Retrieving pilot by name: " + pilotName);
			long pilotID = container.ext().getID(pilot);
			if (container.ext().isCached(pilotID)){
				container.ext().purge(pilot);
			}
			List<Pilot> pilots1 = container.queryByExample(new Pilot(pilotName));
			listResult(pilots1);
		} finally {
			container.close();
		}
	}
	// end checkReferenceCacheWithPurge
	
	private static void testCopyingWithPurge(){
		storeObjects();
		ObjectContainer container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
		try {
			List<Pilot> pilots = container.query(Pilot.class);
			Pilot pilot = (Pilot)pilots.get(0);
			container.ext().purge(pilot);
			container.store(pilot);
			pilots = container.query(Pilot.class);
			listResult(pilots);
		} finally {
			container.close();
		}
	}
	// end testCopyingWithPurge
	
	private static void testBind(){
		storeObjects();
		ObjectContainer container = Db4oEmbedded.openFile(DB4O_FILE_NAME);
		try {
			Query q = container.query();
			q.constrain(Car.class);
			q.descend("model").constrain("Ferrari");
			List<Car> result = q.execute();
			Car car1 = (Car)result.get(0);
			long IdCar1 = container.ext().getID(car1);
			Car car2 = new Car("BMW", new Pilot("Rubens Barrichello"));
			container.ext().bind(car2,IdCar1);
			container.store(car2);

			result = container.query(Car.class);
			listResult(result);
		} finally {
			container.close();
		}
	}
	// end testBind
	
	private static<T> void listResult(List<T> result) {
        System.out.println(result.size());
        for (T obj: result){
            System.out.println(obj);
        }
    }
    // end listResult
}
