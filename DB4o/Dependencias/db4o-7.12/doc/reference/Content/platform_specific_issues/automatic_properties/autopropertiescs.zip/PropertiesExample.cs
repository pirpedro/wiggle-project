/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using Db4objects.Db4o;
using Db4objects.Db4o.Config;
using Db4objects.Db4o.Query;
using Db4objects.Db4o.Diagnostic;
using Db4objects.Db4o.Linq;

namespace Db4objects.Db4odoc.AutoProperties
{	
	public class PropertiesExample
	{
		private const string Db4oFileName = "reference.db4o";

        public static void Main(string[] args)
        {
            FillUpDB();
            TestSODAFieldNames();
        }
        // end Main
	
		
        private static void FillUpDB()
        {
			File.Delete(Db4oFileName);
			IObjectContainer db=Db4oFactory.OpenFile(Db4oFileName);
			try {
        		for (int i=0; i<10000;i++){
    				AddCar(db,i);
    			}
			}
			finally {
				db.Close();
			}
		}
		// end FillUpDB

        private static void TestSODAFieldNames()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            string pilotFieldName = "<Pilot>k__BackingField";
            string pointsFieldName = "<Points>k__BackingField";
            configuration.MessageLevel(1);
            configuration.ObjectClass(typeof(Car)).ObjectField(pilotFieldName).Indexed(true);
            configuration.ObjectClass(typeof(Pilot)).ObjectField(pointsFieldName).Indexed(true);
            configuration.MessageLevel(1);
            configuration.Diagnostic().AddListener(new DiagnosticToConsole());
            IObjectContainer db = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
            {
                IQuery query = db.Query();
                query.Constrain(typeof(Car));
                query.Descend(pilotFieldName).Descend(pointsFieldName).Constrain("99");

                IObjectSet result = query.Execute();
                Console.WriteLine("Test SODA");
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
		}
        // end TestSODAFieldNames

        private static void TestSODA()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            configuration.ObjectClass(typeof(Car)).ObjectField("Pilot").Indexed(true);
            configuration.ObjectClass(typeof(Pilot)).ObjectField("Points").Indexed(true);
            configuration.Diagnostic().AddListener(new DiagnosticToConsole());
            IObjectContainer db = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
             {
                IQuery query = db.Query();
                query.Constrain(typeof(Car));
                query.Descend("Pilot").Descend("Points").Constrain("99");

                IObjectSet  result = query.Execute();
                Console.WriteLine("Test SODA");
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end TestSODA

        private static void TestLinq()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            configuration.Diagnostic().AddListener(new DiagnosticToTrace());
            IObjectContainer db = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
            {
                IEnumerable<Car> result = from Car c in db
                                            where c.Model.Equals("BMW") 
                                            select c;

                Console.WriteLine("Test LINQ:");
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end TestLinq

        private static void TestQBE()
        {
            IConfiguration configuration = Db4oFactory.NewConfiguration();
            configuration.Diagnostic().AddListener(new DiagnosticToTrace());
            IObjectContainer db = Db4oFactory.OpenFile(configuration, Db4oFileName);
            try
            {
                IObjectSet result = db.QueryByExample(new Car("BMW", new Pilot("Tester",1)));
                Console.WriteLine("Test QBE");
                ListResult(result);
            }
            finally
            {
                db.Close();
            }
        }
        // end TestQBE
	    
        private static void AddCar(IObjectContainer db, int points)
		{
			Car car = new Car("BMW");
			car.Pilot= new Pilot("Tester", points);
			db.Set(car);
		}
		// end AddCar

        private static void ListResult(IObjectSet result)
		{
			Console.WriteLine(result.Count);
		}
		// end ListResult

        private static void ListResult<T>(IList<T> result)
        {
            Console.WriteLine(result.Count);
        }
        // end ListResult

        private static void ListResult<T>(IEnumerable<T> result)
        {
            System.Console.WriteLine(result.Count<T>());
        }

        // end ListResult



	}
}