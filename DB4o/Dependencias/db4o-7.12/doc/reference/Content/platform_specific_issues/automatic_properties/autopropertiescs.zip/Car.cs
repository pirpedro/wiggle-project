namespace Db4objects.Db4odoc.AutoProperties
{
	public class Car
	{
        
		public Car(string model)
		{
			Model = model;
			Pilot = null;
		}

        public Car(string model, Pilot pilot)
        {
            Model = model;
            Pilot = pilot;
        }
        
        public Pilot Pilot
		{
			get; set;
		}
        
		public string Model         
		{
			get; set;
		}
        
		override public string ToString()
		{
			return string.Format("{0}[{1}]", Model, Pilot);
		}
	}
}
