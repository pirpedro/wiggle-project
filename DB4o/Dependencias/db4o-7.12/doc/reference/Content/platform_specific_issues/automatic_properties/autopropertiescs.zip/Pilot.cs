namespace Db4objects.Db4odoc.AutoProperties
{
	public class Pilot
	{
		
		public Pilot(string name, int points)
		{
			Name = name;
			Points = points;
		}
        
		public int Points
		{
			get; set;
		}
        
		public void AddPoints(int points)
		{
			Points += points;
		}
        
		public string Name
		{
			get; set;
		}
        
		override public string ToString()
		{
			return string.Format("{0}/{1}", Name, Points);
		}
	}
}
